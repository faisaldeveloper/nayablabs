<?php

/**
 * This is the model class for table "account_ledger".
 *
 * The followings are the available columns in table 'account_ledger':
 * @property integer $id
 * @property integer $dr_account
 * @property integer $cr_account
 * @property double $amount
 * @property string $trans_date
 */
class AccountLedger extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return AccountLedger the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'account_ledger';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
    //array('doadmission, dodischarge','match','pattern'=>'/^(([0-2][0-9]|3[0-1])\-(0[1-9]|1[0-2])\-([1-2][0|1|2|9][0-9][0-9]))+$/','message'=>'{attribute} has Invalid Date'),
//array('model', 'match', 'pattern'=>'/^\w+[\w+\\.]*$/', 'message'=>'{attribute} should only contain word characters and dots.'),
//array('controller', 'match', 'pattern'=>'/^\w+[\w+\\/]*$/', 'message'=>'{attribute} should only contain word characters and slashes.'),
//array('baseControllerClass', 'match', 'pattern'=>'/^[a-zA-Z_]\w*$/', 'message'=>'{attribute} should only contain word characters.'),
//array('username', 'unique'),
//array('password', 'CCompositeUniqueKeyValidator', 'keyColumns' => 'password, branch_id'),

	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('amount, trans_date', 'required'),
			array('dr_account, cr_account','required','on'=>'jv'),
			array('dr_account, cr_account','required','on'=>'bpv'),
			array('dr_account, cr_account','required','on'=>'brv'),
			array('dr_account','required','on'=>'cpv'),
			array('cr_account','required','on'=>'crv'),
			array('dr_account, cr_account', 'numerical', 'integerOnly'=>true),
			array('amount', 'numerical'),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, dr_account, cr_account, amount, voucher_id,trans_date', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		'voucher' => array(self::BELONGS_TO, 'AccountVoucher', 'voucher_id'),
		'draccount' => array(self::BELONGS_TO, 'AccountChartOfAccount', 'dr_account'),
		'craccount' => array(self::BELONGS_TO, 'AccountChartOfAccount', 'cr_account'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'dr_account' => 'Dr Account',
			'cr_account' => 'Cr Account',
			'amount' => 'Amount',
			'trans_date' => 'Trans Date',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('t.id',$this->id);
		$criteria->compare('t.dr_account',$this->dr_account);
		$criteria->compare('t.cr_account',$this->cr_account);
		$criteria->compare('t.amount',$this->amount);
		$criteria->compare('t.trans_date',$this->trans_date,true);
		$criteria->with=array();
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
	public function vouchersearch($id)
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
        $criteria->condition="voucher_id=".$id;
		$criteria->compare('t.id',$this->id);
		$criteria->compare('t.dr_account',$this->dr_account);
		$criteria->compare('t.cr_account',$this->cr_account);
		$criteria->compare('t.amount',$this->amount);
		$criteria->compare('t.trans_date',$this->trans_date,true);
		$criteria->with=array('voucher','draccount','craccount');
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
}