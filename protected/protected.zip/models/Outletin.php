<?php

/**
 * This is the model class for table "outletin".
 *
 * The followings are the available columns in table 'outletin':
 * @property integer $id
 * @property integer $outlet_id
 * @property integer $inventoryitem_id
 * @property string $doi
 * @property integer $quantity
 * @property integer $store_id
 * @property string $remarks
 * @property integer $enter_by
 * @property integer $stock_transfer_id
 *
 * The followings are the available model relations:
 * @property StockTransfer $stockTransfer
 * @property Outlet $outlet
 * @property Inventoryitem $inventoryitem
 * @property Store $store
 * @property User $enterBy
 */
class Outletin extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return Outletin the static model class
	 */
	  /////use in search///////
	// public $supplier;
	 public $store;
	 public $from_date;
	 public $to_date;
	// public $created_date;
	 //public $enter_by;
	 //public $type;
	 
	 ////////////////////////
	 
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'outletin';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
    //array('doadmission, dodischarge','match','pattern'=>'/^(([0-2][0-9]|3[0-1])\-(0[1-9]|1[0-2])\-([1-2][0|1|2|9][0-9][0-9]))+$/','message'=>'{attribute} has Invalid Date'),
//array('model', 'match', 'pattern'=>'/^\w+[\w+\\.]*$/', 'message'=>'{attribute} should only contain word characters and dots.'),
//array('controller', 'match', 'pattern'=>'/^\w+[\w+\\/]*$/', 'message'=>'{attribute} should only contain word characters and slashes.'),
//array('baseControllerClass', 'match', 'pattern'=>'/^[a-zA-Z_]\w*$/', 'message'=>'{attribute} should only contain word characters.'),
//array('username', 'unique'),
//array('password', 'CCompositeUniqueKeyValidator', 'keyColumns' => 'password, branch_id'),

	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('outlet_id, inventoryitem_id, doi, quantity,section_id, store_id, enter_by', 'required'),
			array('outlet_id, inventoryitem_id, quantity, store_id, enter_by, stock_transfer_id', 'numerical', 'integerOnly'=>true),
			array('remarks', 'length', 'max'=>200),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, outlet_id, inventoryitem_id,store, from_date, to_date, doi, quantity, store_id, remarks, enter_by, stock_transfer_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'stockTransfer' => array(self::BELONGS_TO, 'StockTransfer', 'stock_transfer_id'),
			'outlet' => array(self::BELONGS_TO, 'Outlet', 'outlet_id'),
			'section' => array(self::BELONGS_TO, 'Section', 'section_id'),
			'inventoryitem' => array(self::BELONGS_TO, 'Inventoryitem', 'inventoryitem_id'),
			'store' => array(self::BELONGS_TO, 'Store', 'store_id'),
			'enterBy' => array(self::BELONGS_TO, 'User', 'enter_by'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'outlet_id' => 'Outlet',
			'inventoryitem_id' => 'Inventoryitem',
			'doi' => 'Doi',
			'quantity' => 'Quantity',
			'store_id' => 'Store',
			'remarks' => 'Remarks',
			'enter_by' => 'Enter By',
			'stock_transfer_id' => 'Stock Transfer',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	 public function quantity($id)
	 {
		 $outletin=Outletin::model()->findByPk($id);
		$qauntity=$outletin->quantity;
		$inventoryitem=Inventoryitem::model()->findByPk($outletin->inventoryitem_id);
		$purchase_unit=Unit::model()->findByPk($inventoryitem->purchase_unit);
		$sale_unit=Unit::model()->findByPk($inventoryitem->sale_unit);
		$per_purchase=$inventoryitem->per_purchase;
		$cal_quantity=$qauntity.' '.$purchase_unit->name.'('.$per_purchase*$qauntity.' '. $sale_unit->name.')';
		return $cal_quantity;
		 
		 
	 }
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
		
		if(Yii::app()->user->hasState('outlet'))
		{
			$outlet_id=Yii::app()->user->getState('outlet');
		}
        
	    if($outlet_id!='')
		{
			$criteria->condition='outlet.id='.$outlet_id;
		}
        if(isset($this->from_date) && isset($this->to_date))
		{
			$criteria->addBetweenCondition('stockTransfer.transfer_date', $this->from_date,$this->to_date, 'AND');
			//$criteria->compare('pr.from_date',$this->from_date);
			//$criteria->compare('pr.to_date',$this->to_date);
		}
		$criteria->compare('t.id',$this->id);
		$criteria->compare('stockTransfer.store_id',$this->store,true);
		//$criteria->compare('stockTransfer.store_id',$this->store,true);
		$criteria->compare('outlet.id',$this->outlet_id,true);
		$criteria->compare('inventoryitem.id',$this->inventoryitem_id,true);
		$criteria->compare('t.doi',$this->doi,true);
		$criteria->compare('t.quantity',$this->quantity);
		//$criteria->compare('store.id',$this->store_id,true);
		$criteria->compare('t.remarks',$this->remarks,true);
		$criteria->compare('enterBy.name',$this->enter_by,true);
		$criteria->compare('stockTransfer.name',$this->stock_transfer_id,true);
		$criteria->with=array('outlet','inventoryitem','store','enterBy','stockTransfer',);
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
}