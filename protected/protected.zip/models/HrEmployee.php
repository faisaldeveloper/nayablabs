<?php

/**
 * This is the model class for table "hr_employee".
 *
 * The followings are the available columns in table 'hr_employee':
 * @property integer $id
 * @property string $first_name
 * @property string $last_name
 * @property string $dob
 * @property string $email
 * @property integer $contact_no
 * @property string $address
 * @property integer $user_id
 * @property integer $designation_id
 * @property double $salary
 * @property integer $account
 *
 * The followings are the available model relations:
 * @property HrAttendance[] $hrAttendances
 * @property User $user
 * @property AccountChartOfAccount $account0
 * @property HrDesignation $designation
 * @property HrEmployeeLeaves[] $hrEmployeeLeaves
 */
class HrEmployee extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return HrEmployee the static model class
	 */
	public $account_group;
	public $medical_leaves;
	public $casual_leaves;
	public $urgent_leaves;
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'hr_employee';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
    //array('doadmission, dodischarge','match','pattern'=>'/^(([0-2][0-9]|3[0-1])\-(0[1-9]|1[0-2])\-([1-2][0|1|2|9][0-9][0-9]))+$/','message'=>'{attribute} has Invalid Date'),
//array('model', 'match', 'pattern'=>'/^\w+[\w+\\.]*$/', 'message'=>'{attribute} should only contain word characters and dots.'),
//array('controller', 'match', 'pattern'=>'/^\w+[\w+\\/]*$/', 'message'=>'{attribute} should only contain word characters and slashes.'),
//array('baseControllerClass', 'match', 'pattern'=>'/^[a-zA-Z_]\w*$/', 'message'=>'{attribute} should only contain word characters.'),
//array('username', 'unique'),
//array('password', 'CCompositeUniqueKeyValidator', 'keyColumns' => 'password, branch_id'),

	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('first_name, last_name,CNIC, dob, contact_no, address, designation_id, salary', 'required'),
			array('contact_no, user_id, designation_id, account', 'numerical', 'integerOnly'=>true),
			array('CNIC','unique'),
			array('medical_leaves,casual_leaves,urgent_leaves','numerical','integerOnly'=>true,'max'=>20),
			array('email', 'email','message'=>"The email isn't correct"),
			array('salary,CNIC', 'numerical'),
			array('contact_no','length','min'=>11),
			array('first_name, last_name', 'length', 'max'=>20),
			array('email', 'length', 'max'=>30),
			array('CNIC', 'length', 'max'=>13),
			array('address', 'length', 'max'=>200),
			array('contact_no','unique','message'=>'Already entered!'),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, first_name, last_name,CNIC, dob, email, contact_no, address, user_id, designation_id, salary, account,account_group', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'hrAttendances' => array(self::HAS_MANY, 'HrAttendance', 'hr_employee_id'),
			'user' => array(self::BELONGS_TO, 'User', 'user_id'),
			'account0' => array(self::BELONGS_TO, 'AccountChartOfAccount', 'account'),
			'designation' => array(self::BELONGS_TO, 'HrDesignation', 'designation_id'),
			'hrEmployeeLeaves' => array(self::HAS_MANY, 'HrEmployeeLeaves', 'employee_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'first_name' => 'First Name',
			'last_name' => 'Last Name',
			'dob' => 'Dob',
			'email' => 'Email',
			'CNIC'=>'CNIC',
			'contact_no' => 'Contact No',
			'address' => 'Address',
			'user_id' => 'User',
			'designation_id' => 'Designation',
			'salary' => 'Salary',
			'account' => 'Account',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
        
		$criteria->compare('t.id',$this->id);
		$criteria->compare('t.first_name',$this->first_name,true);
		$criteria->compare('t.last_name',$this->last_name,true);
		if(!empty($this->dob)){$this->dob = date('Y-m-d',strtotime($this->dob));}
		$criteria->compare('t.dob',$this->dob,true);
		$criteria->compare('t.email',$this->email,true);
		$criteria->compare('t.contact_no',$this->contact_no);
		$criteria->compare('t.address',$this->address,true);
		$criteria->compare('user.name',$this->user_id,true);
		$criteria->compare('designation.id',$this->designation_id,true);
		$criteria->compare('t.salary',$this->salary);
		$criteria->compare('account0.account_code_2',$this->account,true);
		$criteria->with=array('user','designation','account0',);
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
}