<?php

/**
 * This is the model class for table "hr_employee_earning".
 *
 * The followings are the available columns in table 'hr_employee_earning':
 * @property integer $leave_days
 * @property integer $days
 * @property double $advance_salary
 * @property double $gross_pay
 * @property double $medical
 * @property double $house_rent
 * @property double $over_time
 * @property integer $employee_id
 * @property double $Conveyance_Allowance
 * @property double $bonus
 * @property double $leave_encashment
 * @property double $other_incentive
 * @property integer $id
 *
 * The followings are the available model relations:
 * @property HrEmployee $employee
 */
class HrEmployeeEarning extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return HrEmployeeEarning the static model class
	 */
	 public $medical_leave=0;
	 public $casual_leave=0;
	 public $urgent_leave=0;
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'hr_employee_earning';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
    //array('doadmission, dodischarge','match','pattern'=>'/^(([0-2][0-9]|3[0-1])\-(0[1-9]|1[0-2])\-([1-2][0|1|2|9][0-9][0-9]))+$/','message'=>'{attribute} has Invalid Date'),
//array('model', 'match', 'pattern'=>'/^\w+[\w+\\.]*$/', 'message'=>'{attribute} should only contain word characters and dots.'),
//array('controller', 'match', 'pattern'=>'/^\w+[\w+\\/]*$/', 'message'=>'{attribute} should only contain word characters and slashes.'),
//array('baseControllerClass', 'match', 'pattern'=>'/^[a-zA-Z_]\w*$/', 'message'=>'{attribute} should only contain word characters.'),
//array('username', 'unique'),
//array('password', 'CCompositeUniqueKeyValidator', 'keyColumns' => 'password, branch_id'),

	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('employee_id', 'required'),
			array('leave_days, days, employee_id', 'numerical', 'integerOnly'=>true),
			array('advance_salary, gross_pay, medical, house_rent, over_time, 
			Conveyance_Allowance, bonus, leave_encashment, other_incentive', 'numerical'),
			array('days', 'numerical', 'integerOnly'=>true, 'max'=>31,'message'=>'Days cannot be greater than 31'),
            array('medical_leave,casual_leave,urgent_leave','required','on'=>'update'),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('leave_days, days, advance_salary, gross_pay, medical, house_rent, over_time, employee_id, Conveyance_Allowance, bonus,sp_allownces, leave_encashment,last_update_date, other_incentive, id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'employee' => array(self::BELONGS_TO, 'HrEmployee', 'employee_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'leave_days' => 'Leave Days',
			'days' => 'Days',
			'advance_salary' => 'Advance Salary',
			'gross_pay' => 'Gross Pay',
			'medical' => 'Medical',
			'house_rent' => 'House Rent',
			'over_time' => 'Over Time',
			'employee_id' => 'Employee',
			'Conveyance_Allowance' => 'Conveyance Allowance',
			'bonus' => 'Bonus',
			'leave_encashment' => 'Leave Encashment',
			'other_incentive' => 'Other Incentive',
			'id' => 'ID',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
        
		$criteria->compare('t.leave_days',$this->leave_days);
		$criteria->compare('t.days',$this->days);
		$criteria->compare('t.advance_salary',$this->advance_salary);
		$criteria->compare('t.gross_pay',$this->gross_pay);
		$criteria->compare('t.medical',$this->medical);
		$criteria->compare('t.house_rent',$this->house_rent);
		$criteria->compare('t.over_time',$this->over_time);
		$criteria->compare('employee.name',$this->employee_id,true);
		$criteria->compare('t.Conveyance_Allowance',$this->Conveyance_Allowance);
		$criteria->compare('t.bonus',$this->bonus);
		$criteria->compare('t.leave_encashment',$this->leave_encashment);
		$criteria->compare('t.other_incentive',$this->other_incentive);
		$criteria->compare('t.id',$this->id);
		$criteria->with=array('employee',);
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
}