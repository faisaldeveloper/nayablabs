<?php

/**
 * This is the model class for table "hr_loan".
 *
 * The followings are the available columns in table 'hr_loan':
 * @property integer $id
 * @property integer $employee_id
 * @property double $amount_given
 * @property double $amount_returned
 * @property string $issue_date
 * @property string $return_date
 *
 * The followings are the available model relations:
 * @property HrEmployee $employee
 */
class HrLoan extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return HrLoan the static model class
	 */
	 public $amount_left =0;
	
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'hr_loan';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
    //array('doadmission, dodischarge','match','pattern'=>'/^(([0-2][0-9]|3[0-1])\-(0[1-9]|1[0-2])\-([1-2][0|1|2|9][0-9][0-9]))+$/','message'=>'{attribute} has Invalid Date'),
//array('model', 'match', 'pattern'=>'/^\w+[\w+\\.]*$/', 'message'=>'{attribute} should only contain word characters and dots.'),
//array('controller', 'match', 'pattern'=>'/^\w+[\w+\\/]*$/', 'message'=>'{attribute} should only contain word characters and slashes.'),
//array('baseControllerClass', 'match', 'pattern'=>'/^[a-zA-Z_]\w*$/', 'message'=>'{attribute} should only contain word characters.'),
//array('username', 'unique'),
//array('password', 'CCompositeUniqueKeyValidator', 'keyColumns' => 'password, branch_id'),

	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('employee_id, issue_date', 'required'),
			array('employee_id', 'numerical', 'integerOnly'=>true),
			array('amount_given, amount_returned', 'numerical'),
			array('return_date', 'safe'),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, employee_id, amount_given, amount_returned, issue_date, return_date', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'employee' => array(self::BELONGS_TO, 'HrEmployee', 'employee_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'employee_id' => 'Employee',
			'amount_given' => 'Amount Given',
			'amount_returned' => 'Amount Returned',
			'issue_date' => 'Issue Date',
			'return_date' => 'Return Date',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('t.id',$this->id);
		$criteria->compare('employee.name',$this->employee_id,true);
		$criteria->compare('t.amount_given',$this->amount_given);
		$criteria->compare('t.amount_returned',$this->amount_returned);
		if(!empty($this->dob)){$this->dob = date('Y-m-d',strtotime($this->dob));}
		$criteria->compare('t.issue_date',$this->issue_date,true);
		if(!empty($this->dob)){$this->dob = date('Y-m-d',strtotime($this->dob));}
		$criteria->compare('t.return_date',$this->return_date,true);
		$criteria->with=array('employee',);
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
}