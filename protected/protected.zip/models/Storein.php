<?php

/**
 * This is the model class for table "storein".
 *
 * The followings are the available columns in table 'storein':
 * @property integer $id
 * @property integer $quantity
 * @property double $purchrate
 * @property double $salerate
 * @property string $scheme
 * @property integer $discount
 * @property integer $inventoryitem_id
 * @property integer $store_id
 * @property integer $pr_id
 *
 * The followings are the available model relations:
 * @property PurchaseRequisition $pr
 * @property Inventoryitem $inventoryitem
 * @property Store $store
 */
class Storein extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return Storein the static model class
	 */
	 /////use in search///////
	 public $supplier;
	 public $store;
	 public $from_date;
	 public $to_date;
	 public $created_date;
	 public $enter_by;
	 
	 ////////////////////////
	 public $category;
	 public $code;
	 public $discount_per;
	 public $sales_tax_per;
	 public $purchase_total;
	 public $net_purchase_rate;
	 public $sales_total;
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'storein';
	}
	/////////////////////////////////////////////////////////// Faisal Code
	 public function provider(){ //without pagination
	 
	 $criteria = $this->criteria();
	 return new CActiveDataProvider($this, array('criteria'=>$criteria,'pagination'=>false,//false
	 		));	
	}

	 public function provider2(){ //with pagination
	 $criteria = $this->criteria();
	return new CActiveDataProvider($this, array('criteria'=>$criteria,'pagination'=>array('pageSize'=>Yii::app()->params['defaultPageSize']),//false
	 		));		
	}	
    public function totalQty($allrecords, $pagerecords){		
		$total=0;	$grand_total=0;	
		foreach($allrecords->data as $ar){$grand_total += (int)$ar->quantity;}		
		foreach($pagerecords->data as $ar){	$total += (int)$ar->quantity;	}
		return "$total / $grand_total";	
	}
	
	public function totalPurchase($allrecords, $pagerecords){		
		$total=0;	$grand_total=0;	
		foreach($allrecords->data as $ar){$grand_total += (int)$ar->purchrate;}		
		foreach($pagerecords->data as $ar){	$total += (int)$ar->purchrate;	}
		return "$total / $grand_total";	
	}
	public function totalSale($allrecords, $pagerecords){		
		$total=0;	$grand_total=0;	
		foreach($allrecords->data as $ar){$grand_total += (int)$ar->salerate;}		
		foreach($pagerecords->data as $ar){	$total += (int)$ar->salerate;	}
		return "$total / $grand_total";	
	}
	
	/////////////// End Faisal Code
	/**
	 * @return array validation rules for model attributes.
	 */
    //array('doadmission, dodischarge','match','pattern'=>'/^(([0-2][0-9]|3[0-1])\-(0[1-9]|1[0-2])\-([1-2][0|1|2|9][0-9][0-9]))+$/','message'=>'{attribute} has Invalid Date'),
//array('model', 'match', 'pattern'=>'/^\w+[\w+\\.]*$/', 'message'=>'{attribute} should only contain word characters and dots.'),
//array('controller', 'match', 'pattern'=>'/^\w+[\w+\\/]*$/', 'message'=>'{attribute} should only contain word characters and slashes.'),
//array('baseControllerClass', 'match', 'pattern'=>'/^[a-zA-Z_]\w*$/', 'message'=>'{attribute} should only contain word characters.'),
//array('username', 'unique'),
//array('password', 'CCompositeUniqueKeyValidator', 'keyColumns' => 'password, branch_id'),

	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('quantity, purchrate, salerate, inventoryitem_id, store_id, pr_id', 'required','on'=>'in'),
			array('inventoryitem_id,quantity,store_id,outlet_id,section_id,stocktransfer_id','required','on'=>'returnstore'),
			array('inventoryitem_id,quantity,store_id,stocktransfer_id','required','on'=>'storetostore'),
			array('quantity, inventoryitem_id, store_id, pr_id', 'numerical', 'integerOnly'=>true),
			array('purchrate, salerate', 'numerical'),
			array('quantity, purchrate, salerate, inventoryitem_id, pr_id,outlet_id', 'required', 'on'=>'nscreate'),
			array('scheme', 'length', 'max'=>10),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, quantity,supplier, store, from_date, created_date, enter_by, purchrate, salerate, scheme, discount, inventoryitem_id,to_date, store_id, pr_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'pr' => array(self::BELONGS_TO, 'PurchaseRequisition', 'pr_id'),
			'inventoryitem' => array(self::BELONGS_TO, 'Inventoryitem', 'inventoryitem_id'),
			'store' => array(self::BELONGS_TO, 'Store', 'store_id'),
			'outlet' => array(self::BELONGS_TO, 'Outlet', 'outlet_id'),
			'section' => array(self::BELONGS_TO, 'Section', 'section_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'quantity' => 'Quantity',
			'purchrate' => 'Purch Rate',
			'salerate' => 'Sale Rate',
			'scheme' => 'Scheme',
			'discount' => 'Discount',
			'inventoryitem_id' => 'Inventoryitem',
			'store_id' => 'Store',
			'pr_id' => 'Pr',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	 public function quantity($id){
		 
		 $storein=Storein::model()->findByPk($id);
		 if(count($storein)>0)
		 {
			$item=Inventoryitem::model()->findByPk($storein->inventoryitem_id) ;
			return $storein->quantity.' '.$item->unit->name;
		 }
		 
	 }
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
		if(Yii::app()->user->hasState('store'))
		{
			$store_id=Yii::app()->user->getState('store');
		}
        
	    if($store_id!='')
		{
			$criteria->condition='pr.store_id='.$store_id;
		}
		if(isset($this->from_date) && isset($this->to_date))
		{
			$criteria->addBetweenCondition('pr.requisition_date', $this->from_date,$this->to_date, 'AND');
			//$criteria->compare('pr.from_date',$this->from_date);
			//$criteria->compare('pr.to_date',$this->to_date);
		}
		//$criteria->compare('pr.from_date',$this->from_date);
		$criteria->compare('pr.supplier_id',$this->supplier);
		$criteria->compare('pr.store_id',$this->store);
		$criteria->compare('pr.enter_date',$this->created_date);
		$criteria->compare('pr.enter_by',$this->enter_by);
		
		
		$criteria->compare('t.id',$this->id);
		$criteria->compare('t.quantity',$this->quantity);
		$criteria->compare('t.purchrate',$this->purchrate);
		$criteria->compare('t.salerate',$this->salerate);
		$criteria->compare('t.scheme',$this->scheme,true);
		$criteria->compare('t.discount',$this->discount);
		$criteria->compare('inventoryitem.name',$this->inventoryitem_id,true);
		$criteria->compare('store.name',$this->store_id,true);
		$criteria->compare('pr.name',$this->pr_id,true);
		$criteria->with=array('inventoryitem','store','pr',);
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
	public function storesearch($id)
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
		if(!empty($id))
		{
        $criteria->condition="pr_id=$id";
		}else if(!empty($_REQUEST['id'])){
		$criteria->condition="pr_id=".(int)$_REQUEST['id'];	
		}
		$criteria->compare('t.id',$this->id);
		$criteria->compare('t.quantity',$this->quantity);
		$criteria->compare('t.purchrate',$this->purchrate);
		$criteria->compare('t.salerate',$this->salerate);
		$criteria->compare('t.scheme',$this->scheme,true);
		$criteria->compare('t.discount',$this->discount);
		$criteria->compare('inventoryitem.name',$this->inventoryitem_id,true);
		$criteria->compare('store.name',$this->store_id,true);
		$criteria->compare('pr.name',$this->pr_id,true);
		$criteria->with=array('inventoryitem','store','pr',);
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
	/////////////////////
	public function returnstoresearch($id)
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
		if(!empty($id))
		{
        $criteria->condition="stocktransfer_id=$id";
		}else if(!empty($_REQUEST['id'])){
		$criteria->condition="stocktransfer_id=".(int)$_REQUEST['id'];	
		}
		$criteria->compare('t.id',$this->id);
		$criteria->compare('t.quantity',$this->quantity);
		$criteria->compare('t.purchrate',$this->purchrate);
		$criteria->compare('t.salerate',$this->salerate);
		$criteria->compare('t.scheme',$this->scheme,true);
		$criteria->compare('t.discount',$this->discount);
		$criteria->compare('inventoryitem.name',$this->inventoryitem_id,true);
		$criteria->compare('store.name',$this->store_id,true);
		$criteria->compare('pr.name',$this->pr_id,true);
		$criteria->with=array('inventoryitem','store','pr',);
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
	/////////////////////
	public function criteria(){
		$criteria=new CDbCriteria;
      
	    
		if(isset($this->from_date) && isset($this->to_date))
		{
			$criteria->addBetweenCondition('pr.requisition_date', $this->from_date,$this->to_date, 'AND');
			//$criteria->compare('pr.from_date',$this->from_date);
			//$criteria->compare('pr.to_date',$this->to_date);
		}
		//$criteria->compare('pr.from_date',$this->from_date);
		$criteria->compare('pr.supplier_id',$this->supplier);
		$criteria->compare('pr.store_id',$this->store);
		$criteria->compare('pr.enter_date',$this->created_date);
		$criteria->compare('pr.enter_by',$this->enter_by);
		
		
		$criteria->compare('t.id',$this->id);
		$criteria->compare('t.quantity',$this->quantity);
		$criteria->compare('t.purchrate',$this->purchrate);
		$criteria->compare('t.salerate',$this->salerate);
		$criteria->compare('t.scheme',$this->scheme,true);
		$criteria->compare('t.discount',$this->discount);
		$criteria->compare('inventoryitem.name',$this->inventoryitem_id,true);
		$criteria->compare('store.name',$this->store_id,true);
		$criteria->compare('pr.name',$this->pr_id,true);
		$criteria->with=array('inventoryitem','store','pr',);
		
		return $criteria;	
	}
	
}