<?php

/**
 * This is the model class for table "store_stock".
 *
 * The followings are the available columns in table 'store_stock':
 * @property integer $id
 * @property integer $inventoryitem_id
 * @property integer $store_id
 * @property integer $stock
 *
 * The followings are the available model relations:
 * @property Inventoryitem $inventoryitem
 * @property Store $store
 */
class StoreStock extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return StoreStock the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'store_stock';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
    //array('doadmission, dodischarge','match','pattern'=>'/^(([0-2][0-9]|3[0-1])\-(0[1-9]|1[0-2])\-([1-2][0|1|2|9][0-9][0-9]))+$/','message'=>'{attribute} has Invalid Date'),
//array('model', 'match', 'pattern'=>'/^\w+[\w+\\.]*$/', 'message'=>'{attribute} should only contain word characters and dots.'),
//array('controller', 'match', 'pattern'=>'/^\w+[\w+\\/]*$/', 'message'=>'{attribute} should only contain word characters and slashes.'),
//array('baseControllerClass', 'match', 'pattern'=>'/^[a-zA-Z_]\w*$/', 'message'=>'{attribute} should only contain word characters.'),
//array('username', 'unique'),
//array('password', 'CCompositeUniqueKeyValidator', 'keyColumns' => 'password, branch_id'),

	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('inventoryitem_id, store_id, stock', 'required'),
			array('inventoryitem_id, store_id, stock', 'numerical', 'integerOnly'=>true),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, inventoryitem_id, store_id, stock', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'inventoryitem' => array(self::BELONGS_TO, 'Inventoryitem', 'inventoryitem_id'),
			'store' => array(self::BELONGS_TO, 'Store', 'store_id'),
		);
	}
    
	public function currentstock($id)
	 {
		 $outlet_stock=StoreStock::model()->findByPk($id);
		$inventory_item=Inventoryitem::model()->findByPk($outlet_stock->inventoryitem_id);
		if(count($inventory_item)>0)
		{
		$stock=(float)($outlet_stock->stock/$inventory_item->per_purchase);	
			if((int)$stock>0)
			{
				if($outlet_stock->stock%$inventory_item->per_purchase==0)
				{
			     return $stock.' '.$inventory_item->purchaseUnit->name.'('.$inventory_item->per_purchase*$stock.' '.$inventory_item->saleUnit->name.')'.' '.$inventory_item->per_purchase.$inventory_item->saleUnit->name.' '.'each';
				}
				else
				{
				 return floor($outlet_stock->stock/$inventory_item->per_purchase).' '.$inventory_item->purchaseUnit->name.'('.$inventory_item->per_purchase*floor($stock).' '.$inventory_item->saleUnit->name.')'.' '.'and '.$outlet_stock->stock%$inventory_item->per_purchase.$inventory_item->saleUnit->name;
					
				}
			}
			else
			return 0;
			
		}
		// return 'abc';
	 }
	
	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'inventoryitem_id' => 'Inventoryitem',
			'store_id' => 'Store',
			'stock' => 'Stock',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
        if(Yii::app()->user->hasState('store'))
		{
			$store_id=Yii::app()->user->getState('store');
		}
        
	    if($store_id!='')
		{
			$criteria->condition='store.id='.$store_id;
		}
		$criteria->compare('t.id',$this->id);
		$criteria->compare('inventoryitem.id',$this->inventoryitem_id,true);
		$criteria->compare('store.id',$this->store_id,true);
		$criteria->compare('t.stock',$this->stock);
		$criteria->with=array('inventoryitem','store',);
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
}