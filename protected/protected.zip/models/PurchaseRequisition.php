<?php

/**
 * This is the model class for table "purchase_requisition".
 *
 * The followings are the available columns in table 'purchase_requisition':
 * @property integer $id
 * @property string $requisition_date
 * @property string $enter_date
 * @property string $p_r_no
 * @property integer $supplier_id
 * @property integer $store_id
 * @property double $l_s_discount
 * @property string $remarks
 * @property integer $enter_by
 * @property double $tax_overload
 * @property string $p_o_no
 *
 * The followings are the available model relations:
 * @property User $enterBy
 * @property Supplier $supplier
 * @property Store $store
 */
class PurchaseRequisition extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return PurchaseRequisition the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'purchase_requisition';
	}
    public function getprdate($id)
	 {
		 $PurchaseRequisition=PurchaseRequisition::model()->findByPk($id);
		 return $PurchaseRequisition->requisition_date;
		 
	 }
	/**
	 * @return array validation rules for model attributes.
	 */
    //array('doadmission, dodischarge','match','pattern'=>'/^(([0-2][0-9]|3[0-1])\-(0[1-9]|1[0-2])\-([1-2][0|1|2|9][0-9][0-9]))+$/','message'=>'{attribute} has Invalid Date'),
//array('model', 'match', 'pattern'=>'/^\w+[\w+\\.]*$/', 'message'=>'{attribute} should only contain word characters and dots.'),
//array('controller', 'match', 'pattern'=>'/^\w+[\w+\\/]*$/', 'message'=>'{attribute} should only contain word characters and slashes.'),
//array('baseControllerClass', 'match', 'pattern'=>'/^[a-zA-Z_]\w*$/', 'message'=>'{attribute} should only contain word characters.'),
//array('username', 'unique'),
//array('password', 'CCompositeUniqueKeyValidator', 'keyColumns' => 'password, branch_id'),

	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('requisition_date, enter_date, p_r_no, supplier_id, store_id, enter_by', 'required'),
			array('supplier_id, store_id, enter_by', 'numerical', 'integerOnly'=>true),
			array('l_s_discount, tax_overload', 'numerical'),
			array('p_r_no','unique'),
			array('p_r_no, p_o_no', 'length', 'max'=>20),
			array('remarks', 'length', 'max'=>300),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, requisition_date, enter_date, p_r_no, supplier_id, store_id, l_s_discount, remarks, enter_by, tax_overload, p_o_no', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'enterBy' => array(self::BELONGS_TO, 'User', 'enter_by'),
			'supplier' => array(self::BELONGS_TO, 'Supplier', 'supplier_id'),
			'store' => array(self::BELONGS_TO, 'Store', 'store_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'requisition_date' => 'Requisition Date',
			'enter_date' => 'Enter Date',
			'p_r_no' => 'P R No',
			'supplier_id' => 'Supplier',
			'store_id' => 'Store',
			'l_s_discount' => 'L S Discount',
			'remarks' => 'Remarks',
			'enter_by' => 'Enter By',
			'tax_overload' => 'Tax Overload',
			'p_o_no' => 'P O No',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('t.id',$this->id);
		$criteria->compare('t.requisition_date',$this->requisition_date,true);
		$criteria->compare('t.enter_date',$this->enter_date,true);
		$criteria->compare('t.p_r_no',$this->p_r_no,true);
		$criteria->compare('supplier.id',$this->supplier_id,true);
		$criteria->compare('store.id',$this->store_id,true);
		$criteria->compare('t.l_s_discount',$this->l_s_discount);
		$criteria->compare('t.remarks',$this->remarks,true);
		$criteria->compare('enterBy.name',$this->enter_by,true);
		$criteria->compare('t.tax_overload',$this->tax_overload);
		$criteria->compare('t.p_o_no',$this->p_o_no,true);
		$criteria->with=array('supplier','store','enterBy',);
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
}