<?php

/**
 * This is the model class for table "outletout".
 *
 * The followings are the available columns in table 'outletout':
 * @property integer $id
 * @property integer $outlet_id
 * @property integer $inventoryitem_id
 * @property integer $quantity
 * @property string $remarks
 * @property integer $enter_by
 *
 * The followings are the available model relations:
 * @property Outlet $outlet
 * @property Inventoryitem $inventoryitem
 * @property User $enterBy
 */
class Outletout extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return Outletout the static model class
	 */
	  public $supplier;
	 public $store;
	 public $outlet;
	 public $from_date;
	 public $to_date;
	 public $created_date;
	 public $enter_by;
	 public $type;
	 
	 ////////////////////////
	 public $category;
	 public $code;
	 public $discount_per;
	 public $sales_tax_per;
	 public $purchase_total;
	 public $net_purchase_rate;
	 
	 public $sales_total;
	 public $purchrate;
	 public $scheme;
	 public $salerate;
	 public $discount;
	 public $sales_tax;
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'outletout';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
    //array('doadmission, dodischarge','match','pattern'=>'/^(([0-2][0-9]|3[0-1])\-(0[1-9]|1[0-2])\-([1-2][0|1|2|9][0-9][0-9]))+$/','message'=>'{attribute} has Invalid Date'),
//array('model', 'match', 'pattern'=>'/^\w+[\w+\\.]*$/', 'message'=>'{attribute} should only contain word characters and dots.'),
//array('controller', 'match', 'pattern'=>'/^\w+[\w+\\/]*$/', 'message'=>'{attribute} should only contain word characters and slashes.'),
//array('baseControllerClass', 'match', 'pattern'=>'/^[a-zA-Z_]\w*$/', 'message'=>'{attribute} should only contain word characters.'),
//array('username', 'unique'),
//array('password', 'CCompositeUniqueKeyValidator', 'keyColumns' => 'password, branch_id'),
     public function calquantity($id)
	 {
		 $outletout=Outletout::model()->findByPk($id);
		$qauntity=$outletout->quantity;
		$inventoryitem=Inventoryitem::model()->findByPk($outletout->inventoryitem_id);
		$purchase_unit=Unit::model()->findByPk($inventoryitem->purchase_unit);
		$sale_unit=Unit::model()->findByPk($inventoryitem->sale_unit);
		$per_purchase=$inventoryitem->per_purchase;
		$cal_quantity=$qauntity.' '.$purchase_unit->name.'('.$per_purchase*$qauntity.' '. $sale_unit->name.')';
		return $cal_quantity;
		 
		 
	 }
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('outlet_id, inventoryitem_id, quantity, enter_by,purchrate,salerate', 'required'),
			array('outlet_id, inventoryitem_id, quantity, enter_by', 'numerical', 'integerOnly'=>true),
			array('remarks', 'length', 'max'=>200),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, outlet_id,out_date,section_id, inventoryitem_id, quantity, remarks, enter_by', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'outlet' => array(self::BELONGS_TO, 'Outlet', 'outlet_id'),
			'stocktransfer' => array(self::BELONGS_TO, 'StockTransfer', 'stock_transfer_id'),
			'section' => array(self::BELONGS_TO, 'Section', 'section_id'),
			'inventoryitem' => array(self::BELONGS_TO, 'Inventoryitem', 'inventoryitem_id'),
			'enterBy' => array(self::BELONGS_TO, 'User', 'enter_by'),
		);
	}
     public function quantity($id){
		 
		 $outletout=Outletout::model()->findByPk($id);
		 if(count($outletout)>0)
		 {
			$item=Inventoryitem::model()->findByPk($outletout->inventoryitem_id) ;
			return $outletout->quantity.' '.$item->unit->name;
		 }
		 
	 }
	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'outlet_id' => 'Outlet',
			'inventoryitem_id' => 'Inventoryitem',
			'quantity' => 'Quantity',
			'remarks' => 'Remarks',
			'enter_by' => 'Enter By',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search($id)
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
        $criteria->condition="stock_transfer_id=".$id;
		$criteria->compare('t.id',$this->id);
		$criteria->compare('outlet.name',$this->outlet_id,true);
		$criteria->compare('inventoryitem.name',$this->inventoryitem_id,true);
		$criteria->compare('t.quantity',$this->quantity);
		$criteria->compare('t.remarks',$this->remarks,true);
		$criteria->compare('enterBy.name',$this->enter_by,true);
		$criteria->with=array('outlet','inventoryitem','enterBy',);
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
	public function adminsearch()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.
        
		$criteria=new CDbCriteria;
		if(Yii::app()->user->hasState('outlet'))
		{
			$outlet_id=Yii::app()->user->getState('outlet');
		}
        
	    if($outlet_id!='')
		{
			$criteria->condition='outlet.id='.$outlet_id;
		}
        if(isset($this->from_date) && isset($this->to_date))
		{
			$criteria->addBetweenCondition('t.out_date', $this->from_date,$this->to_date, 'AND');
			//$criteria->compare('pr.from_date',$this->from_date);
			//$criteria->compare('pr.to_date',$this->to_date);
		}
       // $criteria->condition="stock_transfer_id=".$id;
		$criteria->compare('t.id',$this->id);
		$criteria->compare('outlet.id',$this->outlet_id,true);
		$criteria->compare('section.id',$this->section_id,true);
		$criteria->compare('inventoryitem.id',$this->inventoryitem_id,true);
		$criteria->compare('t.quantity',$this->quantity);
		$criteria->compare('t.remarks',$this->remarks,true);
		$criteria->compare('enterBy.id',$this->enter_by,true);
		$criteria->with=array('outlet','inventoryitem','enterBy','section');
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
}