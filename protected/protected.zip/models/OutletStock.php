<?php

/**
 * This is the model class for table "outlet_stock".
 *
 * The followings are the available columns in table 'outlet_stock':
 * @property integer $id
 * @property integer $inventoryitem_id
 * @property integer $outlet_id
 * @property integer $stock
 *
 * The followings are the available model relations:
 * @property Inventoryitem $inventoryitem
 * @property Outlet $outlet
 */
class OutletStock extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return OutletStock the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'outlet_stock';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
    //array('doadmission, dodischarge','match','pattern'=>'/^(([0-2][0-9]|3[0-1])\-(0[1-9]|1[0-2])\-([1-2][0|1|2|9][0-9][0-9]))+$/','message'=>'{attribute} has Invalid Date'),
//array('model', 'match', 'pattern'=>'/^\w+[\w+\\.]*$/', 'message'=>'{attribute} should only contain word characters and dots.'),
//array('controller', 'match', 'pattern'=>'/^\w+[\w+\\/]*$/', 'message'=>'{attribute} should only contain word characters and slashes.'),
//array('baseControllerClass', 'match', 'pattern'=>'/^[a-zA-Z_]\w*$/', 'message'=>'{attribute} should only contain word characters.'),
//array('username', 'unique'),
//array('password', 'CCompositeUniqueKeyValidator', 'keyColumns' => 'password, branch_id'),

	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('inventoryitem_id, outlet_id, stock,section_id', 'required'),
			array('inventoryitem_id, outlet_id, stock', 'numerical', 'integerOnly'=>true),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, inventoryitem_id, outlet_id, section_id, stock', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'inventoryitem' => array(self::BELONGS_TO, 'Inventoryitem', 'inventoryitem_id'),
			'outlet' => array(self::BELONGS_TO, 'Outlet', 'outlet_id'),
			'section' => array(self::BELONGS_TO, 'Section', 'section_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	 public function currentstock($id)
	 {
		 $outlet_stock=OutletStock::model()->findByPk($id);
		$inventory_item=Inventoryitem::model()->findByPk($outlet_stock->inventoryitem_id);
		if(count($inventory_item)>0)
		{
		$stock=(float)($outlet_stock->stock/$inventory_item->per_purchase);	
			if((int)$stock>0)
			{
				if($outlet_stock->stock%$inventory_item->per_purchase==0)
				{
			     return $stock.' '.$inventory_item->purchaseUnit->name.'('.$inventory_item->per_purchase*$stock.' '.$inventory_item->saleUnit->name.')'.' '.$inventory_item->per_purchase.$inventory_item->saleUnit->name.' '.'each';
				}
				
				else
				{
				 return floor($outlet_stock->stock/$inventory_item->per_purchase).' '.$inventory_item->purchaseUnit->name.'('.$inventory_item->per_purchase*floor($stock).' '.$inventory_item->saleUnit->name.')'.' '.'and '.$outlet_stock->stock%$inventory_item->per_purchase.$inventory_item->saleUnit->name;
					//.' '.'Total:'.' '.$inventory_item->per_purchase*floor($stock)+$outlet_stock->stock%$inventory_item->per_purchase.$inventory_item->saleUnit->name;
				}
			}
			
			else if((int)$stock < 1)
			{
				
			return $outlet_stock->stock.$inventory_item->saleUnit->name;
			}
			
		}
		// return 'abc';
	 }
	 
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'inventoryitem_id' => 'Inventoryitem',
			'outlet_id' => 'Outlet',
			'stock' => 'Stock',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
        
		if(Yii::app()->user->hasState('outlet'))
		{
			$outlet_id=Yii::app()->user->getState('outlet');
		}
        
	    if($outlet_id!='')
		{
			$criteria->condition='outlet.id='.$outlet_id;
		}
		if(Yii::app()->user->hasState('section'))
		{
			$section_id=Yii::app()->user->getState('section');
		}
        
	    if($section_id!='')
		{
			$criteria->addCondition('section.id='.$section_id);
		}
		$criteria->compare('t.id',$this->id);
		$criteria->compare('inventoryitem.id',$this->inventoryitem_id,true);
		$criteria->compare('outlet.id',$this->outlet_id,true);
		$criteria->compare('section.id',$this->section_id,true);
		$criteria->compare('t.stock',$this->stock);
		$criteria->with=array('inventoryitem','outlet','section');
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
}