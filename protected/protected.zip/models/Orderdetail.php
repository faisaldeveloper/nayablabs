<?php

/**
 * This is the model class for table "orderdetail".
 *
 * The followings are the available columns in table 'orderdetail':
 * @property integer $id
 * @property integer $quantity
 * @property integer $menu_id
 * @property integer $item_id
 * @property integer $tableorder_id
 * @property double $rate
 *
 * The followings are the available model relations:
 * @property Menu $menu
 * @property Item $item
 * @property tableorder $tableorder
 */
class Orderdetail extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return orderdetail the static model class
	 */
	 public $from;
	 public $to;
	 public $totalqty;
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'orderdetail';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
    //array('doadmission, dodischarge','match','pattern'=>'/^(([0-2][0-9]|3[0-1])\-(0[1-9]|1[0-2])\-([1-2][0|1|2|9][0-9][0-9]))+$/','message'=>'{attribute} has Invalid Date'),
//array('model', 'match', 'pattern'=>'/^\w+[\w+\\.]*$/', 'message'=>'{attribute} should only contain word characters and dots.'),
//array('controller', 'match', 'pattern'=>'/^\w+[\w+\\/]*$/', 'message'=>'{attribute} should only contain word characters and slashes.'),
//array('baseControllerClass', 'match', 'pattern'=>'/^[a-zA-Z_]\w*$/', 'message'=>'{attribute} should only contain word characters.'),
//array('username', 'unique'),
//array('password', 'CCompositeUniqueKeyValidator', 'keyColumns' => 'password, branch_id'),

	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('quantity, item_id, tableorder_id, rate', 'required'),
			array('quantity, menu_id, item_id, tableorder_id', 'numerical', 'integerOnly'=>true),
			array('rate', 'numerical'),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, quantity, menu_id, item_id, tableorder_id, rate,from,to', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'menu' => array(self::BELONGS_TO, 'Menu', 'menu_id'),
			'item' => array(self::BELONGS_TO, 'Item', 'item_id'),
			'tableorder' => array(self::BELONGS_TO, 'Tableorder', 'tableorder_id'),
		);
	}
    public function total($id)
	 {
		 
		 
	 }

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'quantity' => 'Quantity',
			'menu_id' => 'Menu',
			'item_id' => 'Item',
			'tableorder_id' => 'tableorder',
			'rate' => 'Rate',
		);
	}
     
	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	 public static function pageTotal($provider)//,$provider2
		{
		
			$total=0;
			foreach($provider->data as $vehicle){
				$total+=(float)$vehicle->rate;
			}
		
			/*$grand_total = 0;
		
			foreach($provider2->data as $vehicle){
			$grand_total+=(int)$vehicle->commission-(int)$vehicle->expense+(int)$vehicle->earning;	
			}*/
		return '<u>'.'Total:'.number_format($total,2).'</u>';//<br>'.number_format($grand_total);
		}
		 public static function pageTotalQuant($provider)//,$provider2
		{
		
			$total=0;
			foreach($provider->data as $vehicle){
				$total+=(float)$vehicle->quantity;
			}
		
			/*$grand_total = 0;
		
			foreach($provider2->data as $vehicle){
			$grand_total+=(int)$vehicle->commission-(int)$vehicle->expense+(int)$vehicle->earning;	
			}*/
		return '<u>'.'Total:'.number_format($total,2).'</u>';//<br>'.number_format($grand_total);
		}
		
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
		
         if(isset($this->from) && isset($this->to))
		{
			/*$pos = strpos($this->from,'-');
			if($pos==2){
			$this->from = explode('-',$this->from);
			$this->from = array_reverse($this->from);
			$this->from = implode('-',$this->from);
			}
			
			$pos = strpos($this->to,'-');
			if($pos==2){
			$this->to = explode('-',$this->to);
			$this->to = array_reverse($this->to);
			$this->to = implode('-',$this->to);
			}*/
			
			//$criteria->addBetweenCondition('cast(tableorder.date_of_tableorder as date) ', $this->from,$this->to, 'AND');     
			
		}
		
		$cond = '';
		if(isset($this->from)&&!empty($this->from)){
			$pos = strpos($this->from,'-');
			if($pos==2){
			$this->from = explode('-',$this->from);
			$this->from = array_reverse($this->from);
			$this->from = implode('-',$this->from);
			}
			$cond .="and tableorder.date_of_tableorder >= '".$this->from."' ";
		}
		if(isset($this->to)&&!empty($this->to)){
			$pos = strpos($this->to,'-');
			if($pos==2){
			$this->to = explode('-',$this->to);
			$this->to = array_reverse($this->to);
			$this->to = implode('-',$this->to);
			}
			$cond .="and tableorder.date_of_tableorder <= '".$this->to."' ";
		}
		if(!empty($cond)){
		$cond = substr($cond,3);
		$criteria->condition=$cond;
		}
		
		$criteria->select='t.item_id,sum(t.quantity) as quantity,sum(t.rate) as rate';
		$criteria->group='t.item_id';
		$criteria->distinct=true;
		$criteria->compare('t.id',$this->id);
		$criteria->compare('t.quantity',$this->quantity);
		$criteria->compare('menu.id',$this->menu_id,true);
		$criteria->compare('item.name',$this->item_id,true);
		$criteria->compare('tableorder.id',$this->tableorder_id,true);
		$criteria->compare('t.rate',$this->rate);
		$criteria->with=array('menu','item','tableorder',);
		
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>false
		));
	}
	
	
	public function daily($today)
		{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
		$criteria->compare('t.id',$this->id);
		//, SUBSTRING_INDEX(`date_of_tableorder`, ' ', 1) as `mycol` , 
		//$criteria->select = "sum(total) as total,t.date_of_tableorder";
		//$criteria->group = "`date_of_tableorder`";
		$criteria->condition="t.date_of_tableorder like '".$today."'";
		$criteria->compare('t.date_of_tableorder',$this->date_of_tableorder,true);
		$criteria->compare('t.total',$this->total);
		
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
			//'pagination'=>array('pageSize'=> Yii::app()->user->getState('pageSize',Yii::app()->params['defaultPageSize']),),
			'pagination'=>array('pageSize'=>7),//false
			'sort'=>false,
	
		));
		
		}
	
	public function weekly($ids)
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
		$criteria->compare('t.id',$this->id);
		$criteria->select = "sum(quantity) as totalqty,t.*";
		$criteria->group = "`item_id`";
		
		$criteria->condition="t.tableorder_id in ($ids)";
		
		//$criteria->compare('t.date_of_tableorder',$this->date_of_tableorder,true);
		//$criteria->compare('t.total',$this->total);
		
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
			//'pagination'=>array('pageSize'=> Yii::app()->user->getState('pageSize',Yii::app()->params['defaultPageSize']),),
			'pagination'=>false,//array('pageSize'=>7),//false
			'sort'=>false,
	
		));
		
	}
	
	public function itemwise($ids)
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.
if(empty($ids)){$ids='0';}
		$criteria=new CDbCriteria;
		$criteria->compare('t.id',$this->id);
		$criteria->select = "sum(quantity) as totalqty,t.*";
		$criteria->group = "`item_id`";
		$criteria->order = "`totalqty` desc";
		
		$criteria->condition="t.tableorder_id in ($ids)";
		
		
		//$criteria->compare('t.date_of_tableorder',$this->date_of_tableorder,true);
		//$criteria->compare('t.total',$this->total);
		
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
			//'pagination'=>array('pageSize'=> Yii::app()->user->getState('pageSize',Yii::app()->params['defaultPageSize']),),
			'pagination'=>false,//array('pageSize'=>7),//false
			'sort'=>false,
	
		));
		
	}
	
	public function monthly($weekno)
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

       
		$criteria->compare('t.id',$this->id);
		$criteria->select = "sum(total) as total, count(*) as days, t.date_of_tableorder,t.weekno";
		$criteria->group = "`weekno`";
		
		$criteria->condition="t.date_of_tableorder like '".$weekno."'";
		
		$criteria->compare('t.date_of_tableorder',$this->date_of_tableorder,true);
		$criteria->compare('t.total',$this->total);
		
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
			//'pagination'=>array('pageSize'=> Yii::app()->user->getState('pageSize',Yii::app()->params['defaultPageSize']),),
			'pagination'=>false,//false
			'sort'=>false,
	
		));
		
	}
	
	public function yearly($weekno)
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

       
		$criteria->compare('t.id',$this->id);
		$criteria->select = "sum(total) as total,t.date_of_tableorder,SUBSTRING_INDEX(`date_of_tableorder`, '-', 2) as `mycol`";
		$criteria->group = "`mycol`";
		
		$criteria->condition="t.date_of_tableorder like '".$weekno."-%'";
		
		$criteria->compare('t.date_of_tableorder',$this->date_of_tableorder,true);
		$criteria->compare('t.total',$this->total);
		
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
			//'pagination'=>array('pageSize'=> Yii::app()->user->getState('pageSize',Yii::app()->params['defaultPageSize']),),
			'pagination'=>array('pageSize'=>7),//false
			'sort'=>false,
	
		));
		
	}
	
}