<?php

/**
 * This is the model class for table "stock_transfer".
 *
 * The followings are the available columns in table 'stock_transfer':
 * @property integer $id
 * @property string $transfer_date
 * @property string $enter_date
 * @property string $s_t_no
 * @property integer $supplier_id
 * @property integer $store_id
 * @property string $remarks
 * @property integer $enter_by
 * @property string $t_o_no
 * @property integer $transfer_type
 *
 * The followings are the available model relations:
 * @property Outletin[] $outletins
 * @property User $enterBy
 * @property Supplier $supplier
 * @property Store $store
 * @property Storeout[] $storeouts
 */
class StockTransfer extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return StockTransfer the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'stock_transfer';
	}
     public function refundtype($id)
	{
		if($id==1)
		return true;
		else
		return false;
		
	}
	function get_type($id)
	{
		if($id==1)
		return 'Return';
		else if($id==2)
		return 'Transfer';
		else if($id==3)
		return 'Sale';
		else if($id==4)
		return 'Transfer';
		else if($id==5)
		return 'Sale';
		else if($id==6)
		return 'Return to Supplier';
		else if($id==7)
		return 'Sale';
		
	}
	/**
	 * @return array validation rules for model attributes.
	 */
    //array('doadmission, dodischarge','match','pattern'=>'/^(([0-2][0-9]|3[0-1])\-(0[1-9]|1[0-2])\-([1-2][0|1|2|9][0-9][0-9]))+$/','message'=>'{attribute} has Invalid Date'),
//array('model', 'match', 'pattern'=>'/^\w+[\w+\\.]*$/', 'message'=>'{attribute} should only contain word characters and dots.'),
//array('controller', 'match', 'pattern'=>'/^\w+[\w+\\/]*$/', 'message'=>'{attribute} should only contain word characters and slashes.'),
//array('baseControllerClass', 'match', 'pattern'=>'/^[a-zA-Z_]\w*$/', 'message'=>'{attribute} should only contain word characters.'),
//array('username', 'unique'),
//array('password', 'CCompositeUniqueKeyValidator', 'keyColumns' => 'password, branch_id'),

	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('transfer_date, enter_date, s_t_no, store_id, enter_by, transfer_type', 'required'),
			array('tostore_id','required', 'on'=>'StoreToStore'),
			array('supplier_id','required','on'=>'StockRefund'),
			array('outlet_id,section_id,store_id','required','on'=>'returnstore'),
			array('storein_id,outlet_id,section_id', 'required', 'on'=>'nostore' ),
			array('outlet_id,section_id','required','on'=>'StockTransfer'),
			array('supplier_id, store_id, enter_by, transfer_type', 'numerical', 'integerOnly'=>true),
			array('s_t_no, t_o_no', 'length', 'max'=>50),
			array('remarks', 'length', 'max'=>300),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, transfer_date, enter_date, s_t_no, supplier_id, store_id, remarks, enter_by, t_o_no, transfer_type', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'outletins' => array(self::HAS_MANY, 'Outletin', 'stock_transfer_id'),
			'enterBy' => array(self::BELONGS_TO, 'User', 'enter_by'),
			'supplier' => array(self::BELONGS_TO, 'Supplier', 'supplier_id'),
			'store' => array(self::BELONGS_TO, 'Store', 'store_id'),
			'outlet' => array(self::BELONGS_TO, 'Outlet', 'outlet_id'),
			'storeouts' => array(self::HAS_MANY, 'Storeout', 'stock_transfer_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'transfer_date' => 'Credit Date',
			'enter_date' => 'Enter Date',
			's_t_no' => 'Credit No',
			'supplier_id' => 'To Supplier',
			'store_id' => 'From Store',
			'outlet_id' => 'To Outlet',
			'buyer_name' => 'Buyer Name',
			'buyer_contact' => 'Contact',
			'buyer_address' => 'Address',
			'remarks' => 'Remarks',
			'enter_by' => 'Enter By',
			't_o_no' => 'C O No',
			'transfer_type' => 'Transfer Type',
			'tostore_id'=>'To Store'
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search($id)
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
        $criteria->condition="transfer_type=".$id;
		$criteria->compare('t.id',$this->id);
		if(!empty($this->dob)){$this->dob = date('Y-m-d',strtotime($this->dob));}
		$criteria->compare('t.transfer_date',$this->transfer_date,true);
		$criteria->compare('t.enter_date',$this->enter_date,true);
		$criteria->compare('t.s_t_no',$this->s_t_no,true);
		$criteria->compare('supplier.name',$this->supplier_id,true);
		$criteria->compare('store.name',$this->store_id,true);
		$criteria->compare('t.remarks',$this->remarks,true);
		$criteria->compare('enterBy.name',$this->enter_by,true);
		$criteria->compare('t.t_o_no',$this->t_o_no,true);
		$criteria->compare('t.transfer_type',$this->transfer_type);
		$criteria->with=array('supplier','store','enterBy',);
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
	public function refundsearch()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
        $criteria->condition="transfer_type=1";
		$criteria->compare('t.id',$this->id);
		if(!empty($this->dob)){$this->dob = date('Y-m-d',strtotime($this->dob));}
		$criteria->compare('t.transfer_date',$this->transfer_date,true);
		$criteria->compare('t.enter_date',$this->enter_date,true);
		$criteria->compare('t.s_t_no',$this->s_t_no,true);
		$criteria->compare('supplier.name',$this->supplier_id,true);
		$criteria->compare('store.name',$this->store_id,true);
		$criteria->compare('t.remarks',$this->remarks,true);
		$criteria->compare('enterBy.name',$this->enter_by,true);
		$criteria->compare('t.t_o_no',$this->t_o_no,true);
		$criteria->compare('t.transfer_type',$this->transfer_type);
		$criteria->with=array('supplier','store','enterBy',);
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
}