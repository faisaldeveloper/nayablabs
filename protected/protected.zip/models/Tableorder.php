<?php

/**
 * This is the model class for table "tableorder".
 *
 * The followings are the available columns in table 'tableorder':
 * @property integer $id
 * @property string $tableno
 * @property integer $waiter_id
 * @property string $date_of_tableorder
 * @property string $comments
 * @property integer $cover
 * @property integer $discount
 * @property integer $payment
 * @property integer $change
 *
 * The followings are the available model relations:
 * @property orderdetail[] $orderdetails
 * @property Waiter $waiter
 */
class Tableorder extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return tableorder the static model class
	 */
	public $room_id;
	public $mop;
	public $company_id; 
	public $from;
	public $to;
	public $days;
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'tableorder';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
    //array('doadmission, dodischarge','match','pattern'=>'/^(([0-2][0-9]|3[0-1])\-(0[1-9]|1[0-2])\-([1-2][0|1|2|9][0-9][0-9]))+$/','message'=>'{attribute} has Invalid Date'),
//array('model', 'match', 'pattern'=>'/^\w+[\w+\\.]*$/', 'message'=>'{attribute} should only contain word characters and dots.'),
//array('controller', 'match', 'pattern'=>'/^\w+[\w+\\/]*$/', 'message'=>'{attribute} should only contain word characters and slashes.'),
//array('baseControllerClass', 'match', 'pattern'=>'/^[a-zA-Z_]\w*$/', 'message'=>'{attribute} should only contain word characters.'),
//array('username', 'unique'),
//array('password', 'CCompositeUniqueKeyValidator', 'keyColumns' => 'password, branch_id'),

	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('tableno,check_no', 'required'),
			array('cover', 'numerical', 'integerOnly'=>true),
			array('discount, payment, change', 'numerical'),
			array('tableno', 'length', 'max'=>20),
			array('comments', 'length', 'max'=>200),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id,tableordertype, tableno, check_no, waiter_id, date_of_tableorder, comments, cover,gst_rate,gst, discountrate,discount, payment, change,total,from,to,name,phone,address,weekno,created_time,mop', 'safe'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			//'orderdetails' => array(self::HAS_MANY, 'Orderdetail', 'tableorder_id'),
			'waiter' => array(self::BELONGS_TO, 'Waiter', 'waiter_id'),
			'modeofpayment' => array(self::BELONGS_TO, 'Mop', 'mop'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'tableno' => 'Tableno',
			'waiter_id' => 'Waiter',
			'check_no'=>'Check #',
			'date_of_tableorder' => 'Date Of Order',
			'comments' => 'Comments',
			'cover' => 'Cover',
			'discount' => 'Discount',
			'payment' => 'Payment',
			'change' => 'Change',
			'tableordertype'=>'Order Type'
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
		
		$criteria->condition="t.status=1 and t.total>0";
          if(isset($this->from) && isset($this->to))
		{
			$from_date = date("Y-m-d 00:00:00", strtotime($this->from));
            $to_date = date("Y-m-d 00:00:00", strtotime($this->to));
			$criteria->addBetweenCondition('t.date_of_tableorder', $this->from,$this->to, 'AND');     
			
			//$criteria->compare('pr.from_date',$this->from_date);
			//$criteria->compare('pr.to_date',$this->to_date);
		}
		//$criteria->condition="t.status=1 ";
		
		$criteria->compare('t.id',$this->id);
		$criteria->compare('t.tableno',$this->tableno,true);
		$criteria->compare('waiter.name',$this->waiter_id,true);
		//$criteria->compare('t.date_of_tableorder',$this->date_of_tableorder,true);
		$criteria->compare('t.comments',$this->comments,true);
		$criteria->compare('t.cover',$this->cover);
		$criteria->compare('t.discount',$this->discount);
		$criteria->compare('t.payment',$this->payment);
		$criteria->compare('t.change',$this->change);
		$criteria->compare('t.total',$this->total);
		$criteria->with=array('waiter',);
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
	
	
	public function criteria()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
		
		$criteria->condition="t.status=1 ";
		
       
		$criteria->compare('t.id',$this->id);
		
		
		$criteria->compare('t.tableno',$this->tableno,true);
		$criteria->compare('waiter.name',$this->waiter_id,true);
		$criteria->compare('t.date_of_tableorder',$this->date_of_tableorder,true);
		$criteria->compare('t.comments',$this->comments,true);
		$criteria->compare('t.cover',$this->cover);
		$criteria->compare('t.discount',$this->discount);
		$criteria->compare('t.payment',$this->payment);
		$criteria->compare('t.change',$this->change);
		$criteria->compare('t.total',$this->total);
		$criteria->with=array('waiter',);
		return $criteria;
	}
	
	
	
	
	public function search_report()
	{
		$criteria = $this->criteria();
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
			//'pagination'=>array('pageSize'=> Yii::app()->user->getState('pageSize',Yii::app()->params['defaultPageSize']),),
			'pagination'=>array('pageSize'=>30),//false
			'sort'=>false,
	
		));
		}
	public static function pageTotal($provider)//,$provider2
		{
		
			$total=0;
			foreach($provider->data as $vehicle){
				$total+=(float)$vehicle->total;
			}
		
			/*$grand_total = 0;
		
			foreach($provider2->data as $vehicle){
			$grand_total+=(int)$vehicle->commission-(int)$vehicle->expense+(int)$vehicle->earning;	
			}*/
		return '<u>'.number_format($total,2).'</u>';//<br>'.number_format($grand_total);
		}
		
		public static function pageTotalGst($provider)//,$provider2
		{
		
			$total=0;
			foreach($provider->data as $vehicle){
				$total+=(float)$vehicle->gst;
				
			}
		
			/*$grand_total = 0;
		
			foreach($provider2->data as $vehicle){
			$grand_total+=(int)$vehicle->commission-(int)$vehicle->expense+(int)$vehicle->earning;	
			}*/
		return '<u>'.number_format($total,2).'</u>';//<br>'.number_format($grand_total);
		}
		
		public static function pageTotalDiccount($provider)//,$provider2
		{
		
			$total=0;
			foreach($provider->data as $vehicle){
				$total+=(float)$vehicle->discount;
				
			}
		
			/*$grand_total = 0;
		
			foreach($provider2->data as $vehicle){
			$grand_total+=(int)$vehicle->commission-(int)$vehicle->expense+(int)$vehicle->earning;	
			}*/
		return '<u>'.number_format($total,2).'</u>';//<br>'.number_format($grand_total);
		}
		
		
		public function daily($today)
		{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
		//$criteria->compare('t.id',$this->id);
		//, SUBSTRING_INDEX(`date_of_tableorder`, ' ', 1) as `mycol` , 
		//$criteria->select = "sum(total) as total,t.date_of_tableorder";
		//$criteria->group = "`date_of_tableorder`";
		//=====================================================================
		$cond = '';
		if(isset($this->from)&&!empty($this->from)){
			$pos = strpos($this->from,'-');
			if($pos==2){
			$this->from = explode('-',$this->from);
			$this->from = array_reverse($this->from);
			$this->from = implode('-',$this->from);
			}
			$cond .="and t.date_of_tableorder >= '".$this->from."' ";
		}
		if(isset($this->to)&&!empty($this->to)){
			$pos = strpos($this->to,'-');
			if($pos==2){
			$this->to = explode('-',$this->to);
			$this->to = array_reverse($this->to);
			$this->to = implode('-',$this->to);
			}
			$cond .="and t.date_of_tableorder <= '".$this->to."' ";
		}
		if(!empty($cond)){
		$cond = substr($cond,3);
		$criteria->condition=$cond;
		}else{
		$criteria->condition="t.date_of_tableorder like '".$today."' and t.status=1 ";
		}
		//=========================================================================
		$criteria->compare('t.date_of_tableorder',$this->date_of_tableorder,true);
		$criteria->compare('t.check_no',$this->check_no,true);
		$criteria->compare('modeofpayment.name',$this->mop,true);
		$criteria->compare('t.total',$this->total);
		$criteria->with = array('modeofpayment');
		
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
			//'pagination'=>array('pageSize'=> Yii::app()->user->getState('pageSize',Yii::app()->params['defaultPageSize']),),
			'pagination'=>false,//array('pageSize'=>7),//false
			'sort'=>false,
	
		));
		
		}
	
	public function weekly($weekno,$yearno)
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;
		$criteria->compare('t.id',$this->id);
		$criteria->select = "sum(total) as total, t.date_of_tableorder";
		$criteria->group = "`date_of_tableorder`";
		
		$criteria->condition='t.weekno='.$weekno." and date_of_tableorder like '20".$yearno."-%'  and t.status=1 ";
		
		$criteria->compare('t.date_of_tableorder',$this->date_of_tableorder,true);
		$criteria->compare('t.total',$this->total);
		
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
			//'pagination'=>array('pageSize'=> Yii::app()->user->getState('pageSize',Yii::app()->params['defaultPageSize']),),
			'pagination'=>false,//array('pageSize'=>7),//false
			'sort'=>false,
	
		));
		
	}
	
	public function monthly($weekno)
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

       
		$criteria->compare('t.id',$this->id);
		$criteria->select = "sum(total) as total, COUNT(DISTINCT date_of_tableorder) as days, t.date_of_tableorder,t.weekno";
		$criteria->group = "`weekno`";
		
		$criteria->condition="t.date_of_tableorder like '".$weekno."'  and t.status=1 ";
		
		$criteria->compare('t.date_of_tableorder',$this->date_of_tableorder,true);
		$criteria->compare('t.total',$this->total);
		
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
			//'pagination'=>array('pageSize'=> Yii::app()->user->getState('pageSize',Yii::app()->params['defaultPageSize']),),
			'pagination'=>false,//false
			'sort'=>false,
	
		));
		
	}
	
	public function yearly($weekno)
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

       
		$criteria->compare('t.id',$this->id);
		$criteria->select = "sum(total) as total,t.date_of_tableorder,SUBSTRING_INDEX(`date_of_tableorder`, '-', 2) as `mycol`";
		$criteria->group = "`mycol`";
		
		$criteria->condition="t.date_of_tableorder like '".$weekno."-%'  and t.status=1 ";
		
		$criteria->compare('t.date_of_tableorder',$this->date_of_tableorder,true);
		$criteria->compare('t.total',$this->total);
		
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
			//'pagination'=>array('pageSize'=> Yii::app()->user->getState('pageSize',Yii::app()->params['defaultPageSize']),),
			'pagination'=>false,//array('pageSize'=>7),//
			'sort'=>false,
	
		));
		
	}
}