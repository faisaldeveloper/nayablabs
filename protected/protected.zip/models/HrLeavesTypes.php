<?php

/**
 * This is the model class for table "hr_leaves_types".
 *
 * The followings are the available columns in table 'hr_leaves_types':
 * @property integer $id
 * @property string $name
 * @property integer $designation_id
 * @property integer $sick_leaves
 * @property integer $casual_leaves
 * @property integer $urgent_leaves
 */
class HrLeavesTypes extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return HrLeavesTypes the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'hr_leaves_types';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
    //array('doadmission, dodischarge','match','pattern'=>'/^(([0-2][0-9]|3[0-1])\-(0[1-9]|1[0-2])\-([1-2][0|1|2|9][0-9][0-9]))+$/','message'=>'{attribute} has Invalid Date'),
//array('model', 'match', 'pattern'=>'/^\w+[\w+\\.]*$/', 'message'=>'{attribute} should only contain word characters and dots.'),
//array('controller', 'match', 'pattern'=>'/^\w+[\w+\\/]*$/', 'message'=>'{attribute} should only contain word characters and slashes.'),
//array('baseControllerClass', 'match', 'pattern'=>'/^[a-zA-Z_]\w*$/', 'message'=>'{attribute} should only contain word characters.'),
//array('username', 'unique'),
//array('password', 'CCompositeUniqueKeyValidator', 'keyColumns' => 'password, branch_id'),

	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array(' designation_id, sick_leaves, casual_leaves, urgent_leaves', 'required'),
			array('designation_id, sick_leaves, casual_leaves, urgent_leaves', 'numerical', 'integerOnly'=>true),
			array('name', 'length', 'max'=>20),
			array('designation_id','unique','message'=>'Designation is Already Added'),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id,  designation_id, sick_leaves, casual_leaves, urgent_leaves', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		'designation' => array(self::BELONGS_TO, 'Hrdesignation', 'designation_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'designation_id' => 'Designation',
			'sick_leaves' => 'Sick Leaves',
			'casual_leaves' => 'Casual Leaves',
			'urgent_leaves' => 'Urgent Leaves',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('t.id',$this->id);
		$criteria->compare('t.name',$this->name,true);
		$criteria->compare('t.designation_id',$this->designation_id);
		$criteria->compare('t.sick_leaves',$this->sick_leaves);
		$criteria->compare('t.casual_leaves',$this->casual_leaves);
		$criteria->compare('t.urgent_leaves',$this->urgent_leaves);
		$criteria->with=array();
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
}