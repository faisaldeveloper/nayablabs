<?php

/**
 * This is the model class for table "account_groups".
 *
 * The followings are the available columns in table 'account_groups':
 * @property integer $id
 * @property string $group_name
 * @property integer $sub_group_of
 * @property integer $class
 *
 * The followings are the available model relations:
 * @property AccountChartOfAccount[] $accountChartOfAccounts
 * @property AccountClasses $class0
 */
class AccountGroups extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return AccountGroups the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'account_groups';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
    //array('doadmission, dodischarge','match','pattern'=>'/^(([0-2][0-9]|3[0-1])\-(0[1-9]|1[0-2])\-([1-2][0|1|2|9][0-9][0-9]))+$/','message'=>'{attribute} has Invalid Date'),
//array('model', 'match', 'pattern'=>'/^\w+[\w+\\.]*$/', 'message'=>'{attribute} should only contain word characters and dots.'),
//array('controller', 'match', 'pattern'=>'/^\w+[\w+\\/]*$/', 'message'=>'{attribute} should only contain word characters and slashes.'),
//array('baseControllerClass', 'match', 'pattern'=>'/^[a-zA-Z_]\w*$/', 'message'=>'{attribute} should only contain word characters.'),
//array('username', 'unique'),
//array('password', 'CCompositeUniqueKeyValidator', 'keyColumns' => 'password, branch_id'),

	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('group_name, class,code,full_code', 'required'),
			array('sub_group_of, class', 'numerical', 'integerOnly'=>true),
			array('group_name', 'length', 'max'=>20),
			array('group_name', 'unique'),
			array('code','length','max'=>2),
			array('full_code','length','max'=>5),
			array('code', 'UniqueAttributesValidator',
                      'with'=>'class','message'=>'Code is already in use!'),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, group_name, sub_group_of, class,code,full_code', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'accountChartOfAccounts' => array(self::HAS_MANY, 'AccountChartOfAccount', 'account_group'),
			'class0' => array(self::BELONGS_TO, 'AccountClasses', 'class'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'group_name' => 'Group Name',
			'sub_group_of' => 'Sub Group Of',
			'class' => 'Class',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('t.id',$this->id);
		$criteria->compare('t.group_name',$this->group_name,true);
		$criteria->compare('t.sub_group_of',$this->sub_group_of);
		$criteria->compare('class0.name',$this->class,true);
		$criteria->with=array('class0',);
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
}