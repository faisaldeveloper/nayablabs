<?php

/**
 * This is the model class for table "supplier".
 *
 * The followings are the available columns in table 'supplier':
 * @property integer $id
 * @property integer $code
 * @property string $name
 * @property string $contact_person
 * @property string $address
 * @property integer $phone
 * @property string $email
 * @property integer $mobile_no
 * @property integer $opening_balance
 * @property integer $closing_balance
 * @property integer $ntn
 * @property integer $region
 *
 * The followings are the available model relations:
 * @property Storein[] $storeins
 */
class Supplier extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return Supplier the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'supplier';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
    //array('doadmission, dodischarge','match','pattern'=>'/^(([0-2][0-9]|3[0-1])\-(0[1-9]|1[0-2])\-([1-2][0|1|2|9][0-9][0-9]))+$/','message'=>'{attribute} has Invalid Date'),
//array('model', 'match', 'pattern'=>'/^\w+[\w+\\.]*$/', 'message'=>'{attribute} should only contain word characters and dots.'),
//array('controller', 'match', 'pattern'=>'/^\w+[\w+\\/]*$/', 'message'=>'{attribute} should only contain word characters and slashes.'),
//array('baseControllerClass', 'match', 'pattern'=>'/^[a-zA-Z_]\w*$/', 'message'=>'{attribute} should only contain word characters.'),
//array('username', 'unique'),
//array('password', 'CCompositeUniqueKeyValidator', 'keyColumns' => 'password, branch_id'),

	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('code, name', 'required'),
			array('code, phone, mobile_no, opening_balance, closing_balance, ntn, region', 'numerical', 'integerOnly'=>true),
			array('name, contact_person', 'length', 'max'=>30),
			array('address', 'length', 'max'=>200),
			array('email', 'length', 'max'=>20),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, code, name, contact_person, address, phone, email, mobile_no, opening_balance, closing_balance, ntn, region', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'storeins' => array(self::HAS_MANY, 'Storein', 'supplier_id'),
		);
	}
    public function getname($id)
	 {
		 $supplier=Supplier::model()->findByPk($id);
		 return $supplier->name;
		 
	 }
	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'code' => 'Code',
			'name' => 'Name',
			'contact_person' => 'Contact Person',
			'address' => 'Address',
			'phone' => 'Phone',
			'email' => 'Email',
			'mobile_no' => 'Mobile No',
			'opening_balance' => 'Opening Balance',
			'closing_balance' => 'Closing Balance',
			'ntn' => 'Ntn',
			'region' => 'Region',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('t.id',$this->id);
		$criteria->compare('t.code',$this->code);
		$criteria->compare('t.name',$this->name,true);
		$criteria->compare('t.contact_person',$this->contact_person,true);
		$criteria->compare('t.address',$this->address,true);
		$criteria->compare('t.phone',$this->phone);
		$criteria->compare('t.email',$this->email,true);
		$criteria->compare('t.mobile_no',$this->mobile_no);
		$criteria->compare('t.opening_balance',$this->opening_balance);
		$criteria->compare('t.closing_balance',$this->closing_balance);
		$criteria->compare('t.ntn',$this->ntn);
		$criteria->compare('t.region',$this->region);
		$criteria->with=array();
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
}