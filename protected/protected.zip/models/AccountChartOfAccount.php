<?php

/**
 * This is the model class for table "account_chart_of_account".
 *
 * The followings are the available columns in table 'account_chart_of_account':
 * @property integer $id
 * @property string $account_code
 * @property string $account_code_2
 * @property string $account_name
 * @property integer $account_group
 * @property integer $account_tags
 * @property integer $account_status
 *
 * The followings are the available model relations:
 * @property AccountGroups $accountGroup
 * @property HrEmployee[] $hrEmployees
 */
class AccountChartOfAccount extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return AccountChartOfAccount the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'account_chart_of_account';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
    //array('doadmission, dodischarge','match','pattern'=>'/^(([0-2][0-9]|3[0-1])\-(0[1-9]|1[0-2])\-([1-2][0|1|2|9][0-9][0-9]))+$/','message'=>'{attribute} has Invalid Date'),
//array('model', 'match', 'pattern'=>'/^\w+[\w+\\.]*$/', 'message'=>'{attribute} should only contain word characters and dots.'),
//array('controller', 'match', 'pattern'=>'/^\w+[\w+\\/]*$/', 'message'=>'{attribute} should only contain word characters and slashes.'),
//array('baseControllerClass', 'match', 'pattern'=>'/^[a-zA-Z_]\w*$/', 'message'=>'{attribute} should only contain word characters.'),
//array('username', 'unique'),
//array('password', 'CCompositeUniqueKeyValidator', 'keyColumns' => 'password, branch_id'),

	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('account_code,  account_name, account_group, account_status', 'required'),
			array('account_group, account_tags, account_status', 'numerical', 'integerOnly'=>true),
			array('account_code, account_code_2', 'length', 'max'=>20),
			array('account_name', 'length', 'max'=>30),
			array('account_code', 'UniqueAttributesValidator',
                      'with'=>'account_group','message'=>' Account Code is already in use!'),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, account_code, account_code_2, account_name,account_type, account_group, account_tags, account_status', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'accountGroup' => array(self::BELONGS_TO, 'AccountGroups', 'account_group'),
			'hrEmployees' => array(self::HAS_MANY, 'HrEmployee', 'account'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'account_code' => 'Account Code',
			'account_code_2' => 'Account Code',
			'account_name' => 'Account Name',
			'account_group' => 'Account Group',
			'account_tags' => 'Account Tags',
			'account_status' => 'Account Status',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('t.id',$this->id);
		$criteria->compare('t.account_code',$this->account_code,true);
		$criteria->compare('t.account_code_2',$this->account_code_2,true);
		$criteria->compare('t.account_name',$this->account_name,true);
		$criteria->compare('accountGroup.name',$this->account_group,true);
		$criteria->compare('t.account_tags',$this->account_tags);
		$criteria->compare('t.account_status',$this->account_status);
		$criteria->with=array('accountGroup',);
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
}