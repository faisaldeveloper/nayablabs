<?php

/**
 * This is the model class for table "hr_employee_deductions".
 *
 * The followings are the available columns in table 'hr_employee_deductions':
 * @property integer $id
 * @property double $income_tax
 * @property double $instalment_loan
 * @property integer $allowed_leaves
 * @property double $insurance
 * @property double $security_deposit
 * @property double $EOBI
 * @property integer $employee_id
 *
 * The followings are the available model relations:
 * @property HrEmployee $employee
 */
class HrEmployeeDeductions extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return HrEmployeeDeductions the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'hr_employee_deductions';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
    //array('doadmission, dodischarge','match','pattern'=>'/^(([0-2][0-9]|3[0-1])\-(0[1-9]|1[0-2])\-([1-2][0|1|2|9][0-9][0-9]))+$/','message'=>'{attribute} has Invalid Date'),
//array('model', 'match', 'pattern'=>'/^\w+[\w+\\.]*$/', 'message'=>'{attribute} should only contain word characters and dots.'),
//array('controller', 'match', 'pattern'=>'/^\w+[\w+\\/]*$/', 'message'=>'{attribute} should only contain word characters and slashes.'),
//array('baseControllerClass', 'match', 'pattern'=>'/^[a-zA-Z_]\w*$/', 'message'=>'{attribute} should only contain word characters.'),
//array('username', 'unique'),
//array('password', 'CCompositeUniqueKeyValidator', 'keyColumns' => 'password, branch_id'),

	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('employee_id', 'required'),
			array('allowed_leaves, employee_id', 'numerical', 'integerOnly'=>true),
			array('income_tax, instalment_loan, insurance, security_deposit, EOBI', 'numerical'),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, income_tax, instalment_loan, allowed_leaves, insurance, security_deposit, EOBI, employee_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'employee' => array(self::BELONGS_TO, 'HrEmployee', 'employee_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'income_tax' => 'Income Tax',
			'instalment_loan' => 'Instalment Loan',
			'allowed_leaves' => 'Allowed Leaves',
			'insurance' => 'Insurance',
			'security_deposit' => 'Security Deposit',
			'EOBI' => 'Eobi',
			'employee_id' => 'Employee',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('t.id',$this->id);
		$criteria->compare('t.income_tax',$this->income_tax);
		$criteria->compare('t.instalment_loan',$this->instalment_loan);
		$criteria->compare('t.allowed_leaves',$this->allowed_leaves);
		$criteria->compare('t.insurance',$this->insurance);
		$criteria->compare('t.security_deposit',$this->security_deposit);
		$criteria->compare('t.EOBI',$this->EOBI);
		$criteria->compare('employee.name',$this->employee_id,true);
		$criteria->with=array('employee',);
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
            'pagination'=>array('pageSize'=>30),//false
		));
	}
}