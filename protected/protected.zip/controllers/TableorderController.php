<?php
class TableorderController extends Controller
{
/**
* @var string the default layout for the views. Defaults to '//layouts/column2', meaning
* using two-column layout. See 'protected/views/layouts/column2.php'.
*/
public $layout='//layouts/column1';

/**
* @return array action filters
*/
public function filters()
{
return array(
'accessControl', // perform access control for CRUD operations
);
}
public function actionAddCompany($id){
$footer = $_POST['footer'];
$rs = Yii::app()->db->createCommand('update tableorder set footer="'.$footer.'" where id='.$id)->execute();
echo $rs;
}

public function actionTest()
    {
        # mPDF
        $mPDF1 = Yii::app()->ePdf->mpdf();
 
        # You can easily override default constructor's params
        $mPDF1 = Yii::app()->ePdf->mpdf('', 'A5');
 
        # render (full page)
        $mPDF1->WriteHTML($this->render('index', array(), true));
 
        # Load a stylesheet
        $stylesheet = file_get_contents(Yii::getPathOfAlias('webroot.css') . '/main.css');
        $mPDF1->WriteHTML($stylesheet, 1);
 
        # renderPartial (only 'view' of current controller)
        $mPDF1->WriteHTML($this->renderPartial('index', array(), true));
 
        # Renders image
        $mPDF1->WriteHTML(CHtml::image(Yii::getPathOfAlias('webroot.css') . '/bg.gif' ));
 
        # Outputs ready PDF
        $mPDF1->Output();
 
        ////////////////////////////////////////////////////////////////////////////////////
 
        # HTML2PDF has very similar syntax
        $html2pdf = Yii::app()->ePdf->HTML2PDF();
        $html2pdf->WriteHTML($this->renderPartial('index', array(), true));
        $html2pdf->Output();
 
        ////////////////////////////////////////////////////////////////////////////////////
 
        # Example from HTML2PDF wiki: Send PDF by email
        $content_PDF = $html2pdf->Output('', EYiiPdf::OUTPUT_TO_STRING);
        require_once(dirname(__FILE__).'/pjmail/pjmail.class.php');
        $mail = new PJmail();
        $mail->setAllFrom('webmaster@my_site.net', "My personal site");
        $mail->addrecipient('mail_user@my_site.net');
        $mail->addsubject("Example sending PDF");
        $mail->text = "This is an example of sending a PDF file";
        $mail->addbinattachement("my_document.pdf", $content_PDF);
        $res = $mail->sendmail();
    }

/*public function actionPrintKOT(){
$printers = Yii::app()->db->createCommand('select * from section where name like "Warm Kitchen"')->queryRow();
//shell_exec('"C:\\Program Files (x86)\\Adobe\Reader 11.0\\Reader\\AcroRd32.exe" /t "D:\\pdf.pdf"  "ML-2571"');
//shell_exec('"'.$printers['program'].'" /t "D:\\pdf.pdf"  "'.$printers['printer_name'].'"');
//print_r($printers);
}
*/

public function actionBill($id)
{
	$this->layout = '//layouts/print';

//$order=	$this->loadModel(23);
	//$order_detail=Orderdetail::model()->findAll('tableorder_id=:tableorder_id',array(':tableorder_id'=>$order->id));
	/*$order_detail=OrderDetail::model()->findAllBySql('SELECT t.id, t.tableno, d.id, SUM( d.quantity ) AS quantity, d.menu_id, d.item_id, d.tableorder_id, SUM( d.rate ) AS total
FROM orderdetail AS d, tableorder AS t Where t.id=24
GROUP BY d.item_id ');*/
$order = Yii::app()->db->createCommand('select * from tableorder where id='.(int)$id)->queryRow();
$order_detail=Yii::app()->db->createCommand('SELECT t.id as order_id,t.gst,t.discount,t.discountrate,t.gst_rate, t.tableno, d.id, d.rate,SUM( d.quantity ) AS quantity, d.menu_id, d.item_id, d.tableorder_id, SUM( d.quantity*d.rate ) AS total
FROM orderdetail AS d, tableorder AS t Where  d.tableorder_id=t.id AND d.tableorder_id='.$id.'
GROUP BY d.item_id HAVING quantity >0')->queryAll();

	$this->render( 'bill', array( 'order' => $order,'order_detail'=>$order_detail ) );
}

/**
* Specifies the access control rules.
* This method is used by the 'accessControl' filter.
* @return array access control rules
*/

/**
* Displays a particular model.
* @param integer $id the ID of the model to be displayed
*/
public function actionUpdateDiscount($id){
if($_POST['discountrate']>0){
echo Yii::app()->db->createCommand('update tableorder set discount=0,discountrate='.(float)$_POST['discountrate'].' ,total='.$_POST['total'].'  where id='.(int)$id)->execute();
}else if($_POST['discount']>=0){
echo Yii::app()->db->createCommand('update tableorder set discount='.(float)$_POST['discount'].' ,discountrate=0 ,total='.$_POST['total'].' where id='.(int)$id)->execute();	
}
}

public function actionView($id)
{
		$model = $this->loadModel($id);
		
		if( Yii::app()->request->isAjaxRequest )
		{
			// Stop jQuery from re-initialization
			Yii::app()->clientScript->scriptMap['jquery.js'] = false;
		 	echo CJSON::encode( array(
			  'status' => 'failure',
			  'content' => $this->renderPartial( 'view', array('model' => $model ), true, true ),));
			exit;
		  }
		  else
			$this->render( 'view', array( 'model' => $model ) );
	  
	  
}

/**
* Creates a new model.
* If creation is successful, the browser will be redirected to the 'view' page.
*/
/*public function actionMyAction()
        {       
                $model=new Tableorder;             
                $this->performAjaxValidation($model);  
                
                if(isset($_POST['Tableorder']))
                {
                        $model->attributes=$_POST['Tableorder'];
                        $valid=$model->validate();            
                        if($valid){
                                          
                           //do anything here
						   $model->save();
                             echo CJSON::encode(array(
                                  'status'=>'success',
								  'cover'=>$model->cover,
								  'tableno'=>$model->tableno,
								  'waiter'=>$model->waiter->name,
								  'tableorderid'=>$model->id,
								  'check'=>$model->check,
								  'discount'=>$model->discount,
								  'payment'=>$model->payment,
								  'change'=>$model->change
                             ));
                            Yii::app()->end();
                            }
                            else{
                                $error = CActiveForm::validate($model);
                                if($error!='[]')
                                    echo $error;
                                Yii::app()->end();
                            }
               }
     
        }*/
public function actionChangeTableOrder()
{
$itemdetail = (int)Yii::app()->session['settings']['order_detail'];
 ////////// getting system settings //////////	
 $setting=SystemSettings::model()->find();
 if($setting->stock_restrickted==1)
 {$open=false;}
 else
 {$open=true;}
 ////////// gettin system settings /////////
   $model = new Orderdetail;
   $model->tableorder_id = (int)$_POST['tableorder_id'];
   $model->quantity  = (int)$_POST['qty'];
   $model->item_id  = (int)$_POST['item_id'];
   $model->rate  = (int)$_POST['rate'];
   $item=Item::model()->findByPk((int)$_POST['item_id']);
   $item_outlet=$item->outlet_id;
   $item_section=$item->section_id;
   
   if($item->section_id>0){
   $model->section_id  = $item->section_id;
   }
   
   ///////////// if no ware house //////////////
   
   if(count($setting)>0 && $setting->warehouse==0)
     {
		 
	      if($model->save()){ 
 
           Yii::app()->db->createCommand('update tableorder set total='.(float)$_POST['total'].',gst='.(float)$_POST['gst'].',discount='.(float)$_POST['discount'].' where id='.$model->tableorder_id)->execute();
     
     //$outlet_stock->stock=$outlet_stock->stock-(int)$_POST['qty'];
     //$outlet_stock->save();
        echo '1';
		$orderdetails = Yii::app()->db->createCommand('select i.*,od.* from orderdetail od join item i on od.item_id=i.id where tableorder_id='.(int)$_POST['tableorder_id'])->queryAll();
		//echo 'first';
		//print_r($orderdetails);
		$html ='';
		$serial_no=0;
		foreach($orderdetails as $orderdetail){
		$serial_no++;
		//--------------------
		if($orderdetail['quantity']>0 && $itemdetail){
		$link = CHtml::link($orderdetail['name'],array('tableorder/extrasCreate/'.$orderdetail['id']),array('class'=>'update-dialog-create','id'=>Yii::t('strings','Create Extras')));
		}else{
		$link=$orderdetail['name'];
		}
		//--------------
		if($orderdetail['quantity']>0){
		$lnk1 = '<a style="float:left" class="removeqt removeqt1" item_id="'.$orderdetail['item_id'].
	'"  href="javascript:void(0)">'.'<div  class="order_frist"> '.$serial_no.' </div></a>';
		}else{
		$lnk1 = '<a class="removeqt" item_id="'.$orderdetail['item_id'].'"><div  class="order_frist"> '.$serial_no.' </div></a>';
		}
		//----------------
		if($orderdetail['section_id']){$pending_kot='style="color:yellow"';}else{$pending_kot='';}
		$html .='<div class="bill_row"'.$pending_kot.'>'.$lnk1.'<div class="order_second"> '.$link.'</div><div class="order_third">'.$orderdetail['quantity'].'</div><div class="order_fourth"> '.$orderdetail['rate'].
	' </div><div class="order_fifth_item" item_type="'.$orderdetail['discounted'].'"> '.$orderdetail['quantity']*$orderdetail['rate'].' </div></div>';
	
		}//end foreach
		
		echo $html;
		
           }
	 
	    exit;
     }
   
   //////////// if no ware house condition end ///////////////
   /////////// if ware house exist //////////////////////////
else{  
   //////////if item is inventoryitem type /////////
   if($item->inventoryitem_id!=NULL && $item->recipe_id==NULL)
   {
    $inventoryitem=Inventoryitem::model()->findByPk($item->inventoryitem_id);
    $outlet_stock=OutletStock::model()->find('inventoryitem_id='.$inventoryitem->id.' '.'AND outlet_id='.$item_outlet.' '.'AND section_id='.$item_section);
    /////////stock check//////////////
    if(count($outlet_stock)>0)
    {
    
    if(($outlet_stock->stock>=(int)$_POST['qty'] && count($outlet_stock)>0) || $open)
    {
     
           if($model->save()){ 
     
           Yii::app()->db->createCommand('update tableorder set total='.$_POST['total'].',gst='.(float)$_POST['gst'].',discount='.(float)$_POST['discount'].' where id='.$model->tableorder_id)->execute();
     
     $outlet_stock->stock=$outlet_stock->stock-(int)$_POST['qty'];
     $outlet_stock->save();
        //echo '1';
		$orderdetails = Yii::app()->db->createCommand('select i.*,od.* from orderdetail od join item i on od.item_id=i.id where tableorder_id='.(int)$_POST['tableorder_id'])->queryAll();
		//echo 'first';
		//print_r($orderdetails);
		$html ='';
		$serial_no=0;
		foreach($orderdetails as $orderdetail){
		$serial_no++;
		//--------------------
		if($orderdetail['quantity']>0 && $itemdetail){
		$link = CHtml::link($orderdetail['name'],array('tableorder/extrasCreate/'.$orderdetail['id']),array('class'=>'update-dialog-create','id'=>Yii::t('strings','Create Extras')));
		}else{
		$link=$orderdetail['name'];
		}
		//--------------
		if($orderdetail['quantity']>0){
		$lnk1 = '<a style="float:left" class="removeqt removeqt1" item_id="'.$orderdetail['item_id'].
	'"  href="javascript:void(0)">'.'<div  class="order_frist"> '.$serial_no.' </div></a>';
		}else{
		$lnk1 = '<a class="removeqt" item_id="'.$orderdetail['item_id'].'"><div  class="order_frist"> '.$serial_no.' </div></a>';
		}
		//----------------
		if($orderdetail['section_id']){$pending_kot='style="color:yellow"';}else{$pending_kot='';}
		$html .='<div class="bill_row"'.$pending_kot.'>'.$lnk1.'<div class="order_second"> '.$link.'</div><div class="order_third">'.$orderdetail['quantity'].'</div><div class="order_fourth"> '.$orderdetail['rate'].
	' </div><div class="order_fifth_item" item_type="'.$orderdetail['discounted'].'"> '.$orderdetail['quantity']*$orderdetail['rate'].' </div></div>';
	
		}//end foreach
		
		echo $html;
		
           }
        else
     {
   echo '0';
     }
    }//////////stock check /////////
    else///////Out of stock alert////////
    {
     echo "Selected Item is Out of Stock";
    }///////Out of stock alert////////
    
    }
    else
    {
     if($open)
     {
    if($model->save()){ 
     
           Yii::app()->db->createCommand('update tableorder set total='.$_POST['total'].',gst='.           (float)$_POST['gst'].',discount='.(float)$_POST['discount'].' where id='.$model->tableorder_id)->           execute();
     $outletstock= new OutletStock;
     $outletstock->inventoryitem_id=$item->inventoryitem_id;
     $outletstock->outlet_id=$item_outlet;
     $outletstock->section_id=$item_section;
     $outletstock->stock=(0)-(int)$_POST['qty'];
     $outletstock->save();
     //echo 1;
	 $orderdetails = Yii::app()->db->createCommand('select i.*,od.* from orderdetail od join item i on od.item_id=i.id where tableorder_id='.(int)$_POST['tableorder_id'])->queryAll();
		//echo 'second';
		//print_r($orderdetails);
		$html ='';
		$serial_no=0;
		foreach($orderdetails as $orderdetail){
		$serial_no++;
		//--------------------
		if($orderdetail['quantity']>0 && $itemdetail){
		$link = CHtml::link($orderdetail['name'],array('tableorder/extrasCreate/'.$orderdetail['id']),array('class'=>'update-dialog-create','id'=>Yii::t('strings','Create Extras')));
		}else{
		$link=$orderdetail['name'];
		}
		//--------------
		if($orderdetail['quantity']>0){
		$lnk1 = '<a style="float:left" class="removeqt removeqt1" item_id="'.$orderdetail['item_id'].
	'"  href="javascript:void(0)">'.'<div  class="order_frist"> '.$serial_no.' </div></a>';
		}else{
		$lnk1 = '<a class="removeqt" item_id="'.$orderdetail['item_id'].'"><div  class="order_frist"> '.$serial_no.' </div></a>';
		}
		//----------------
		if($orderdetail['section_id']){$pending_kot='style="color:yellow"';}else{$pending_kot='';}
		$html .='<div class="bill_row"'.$pending_kot.'>'.$lnk1.'<div class="order_second"> '.$link.'</div><div class="order_third">'.$orderdetail['quantity'].'</div><div class="order_fourth"> '.$orderdetail['rate'].
	' </div><div class="order_fifth_item" item_type="'.$orderdetail['discounted'].'"> '.$orderdetail['quantity']*$orderdetail['rate'].' </div></div>';
	
		}//end foreach
		
		echo $html;
    }
    else
    {
     echo 0;
    }
     }
    }
    }//////////if item is inventoryitem type /////////
 //////////if item is recipe type ///////////
 else if($item->inventoryitem_id==NULL && $item->recipe_id!=NULL)
 {
  $out_of_stock=array();
  $no_stock=array();
  $recipe=Recipe::model()->findByPK($item->recipe_id);
  $recipe_items=RecipeItem::model()->findAll('recipe_id='.$recipe->id);
  if($open==false)
  {
   
   
       foreach($recipe_items as $row)
         {
       $outlet_stock=OutletStock::model()->find('inventoryitem_id='.$row->
    inventoryitem_id.
       ' '.'AND outlet_id='.$item_outlet.' '.'AND section_id='.$item_section);
     
         if(count($outlet_stock)>0 && ($outlet_stock->stock >= (int)$_POST['qty']*$row->                  quantity))
       {
           
       }
       else
       {
      $out_of_stock[]=$row->inventoryitem->name;  
        
       }
         }
     
         if(count($out_of_stock)==0)
      {
        if($model->save())
              { 
     
                    Yii::app()->db->createCommand('update tableorder set total='.$_POST['total']                    .',gst='.(float)$_POST['gst'].',discount='.(float)$_POST['discount'].' where id='.$model->
     tableorder_id)->execute();
     
           foreach($recipe_items as $row)
                 {
                  $outlet_stock=OutletStock::model()->find('inventoryitem_id='.$row->
      inventoryitem_id.
               ' '.'AND outlet_id='.$item_outlet.' '.'AND section_id='.$item_section);
          $outlet_stock->stock=$outlet_stock->stock-($row->quantity*(int)$_POST[
       'qty']);
       $outlet_stock->save();
            }
      //echo 1;
	  $orderdetails = Yii::app()->db->createCommand('select i.*,od.* from orderdetail od join item i on od.item_id=i.id where tableorder_id='.(int)$_POST['tableorder_id'])->queryAll();
		//echo 'third';
		//print_r($orderdetails);
		$html ='';
		$serial_no=0;
		foreach($orderdetails as $orderdetail){
		$serial_no++;
		//--------------------
		if($orderdetail['quantity']>0 && $itemdetail){
		$link = CHtml::link($orderdetail['name'],array('tableorder/extrasCreate/'.$orderdetail['id']),array('class'=>'update-dialog-create','id'=>Yii::t('strings','Create Extras')));
		}else{
		$link=$orderdetail['name'];
		}
		//--------------
		if($orderdetail['quantity']>0){
		$lnk1 = '<a style="float:left" class="removeqt removeqt1" item_id="'.$orderdetail['item_id'].
	'"  href="javascript:void(0)">'.'<div  class="order_frist"> '.$serial_no.' </div></a>';
		}else{
		$lnk1 = '<a class="removeqt" item_id="'.$orderdetail['item_id'].'"><div  class="order_frist"> '.$serial_no.' </div></a>';
		}
		//----------------
		if($orderdetail['section_id']){$pending_kot='style="color:yellow"';}else{$pending_kot='';}
		$html .='<div class="bill_row"'.$pending_kot.'>'.$lnk1.'<div class="order_second"> '.$link.'</div><div class="order_third">'.$orderdetail['quantity'].'</div><div class="order_fourth"> '.$orderdetail['rate'].
	' </div><div class="order_fifth_item" item_type="'.$orderdetail['discounted'].'"> '.$orderdetail['quantity']*$orderdetail['rate'].' </div></div>';
	
		}//end foreach
		
		echo $html;
     }
      }
            else
      {
       $str='';
       foreach($out_of_stock as $row)
       {
     $str.=$row.',';   
       }
       echo $str.' '.'out of stock';
      }
  }//////// open==false /////
  //////// recipe open=true /////////
  else
  {
   
        if($model->save())
              { 
     
                    Yii::app()->db->createCommand('update tableorder set total='.$_POST['total']                    .',gst='.(float)$_POST['gst'].',discount='.(float)$_POST['discount'].' where id='.$model->
     tableorder_id)->execute();
        if(count($setting)>0 && $setting->recipe_calculator==1)
     {
           foreach($recipe_items as $row)
                 {
                  $outlet_stock=OutletStock::model()->find('inventoryitem_id='.$row->
      inventoryitem_id.
               ' '.'AND outlet_id='.$item_outlet.' '.'AND section_id='.$item_section);
      if(count($outlet_stock)>0)
      {
          $outlet_stock->stock=$outlet_stock->stock-($row->quantity*(int)$_POST[
       'qty']);
       $outlet_stock->save();
      }
    
      else
      {
       $outlet_stock=new OutletStock;
       $outlet_stock->inventoryitem_id=$row->inventoryitem_id;
       $outlet_stock->outlet_id=$item_outlet;
       $outlet_stock->section_id=$item_section;
       $outlet_stock->stock=$outlet_stock->stock-($row->quantity*(int)$_POST[
       'qty']);
        $outlet_stock->save();
   
   
      }
            }
     }
      //echo 1;
   $orderdetails = Yii::app()->db->createCommand('select i.*,od.* from orderdetail od join item i on od.item_id=i.id where tableorder_id='.(int)$_POST['tableorder_id'])->queryAll();
  //echo 'third';
  //print_r($orderdetails);
  $html ='';
  $serial_no=0;
  foreach($orderdetails as $orderdetail){
  //--------------------
		if($orderdetail['quantity']>0 && $itemdetail){
		$link = CHtml::link($orderdetail['name'],array('tableorder/extrasCreate/'.$orderdetail['id']),array('class'=>'update-dialog-create','id'=>Yii::t('strings','Create Extras')));
		}else{
		$link=$orderdetail['name'];
		}
		//--------------
		if($orderdetail['quantity']>0){
		$lnk1 = '<a style="float:left" class="removeqt removeqt1" item_id="'.$orderdetail['item_id'].
	'"  href="javascript:void(0)">'.'<div  class="order_frist"> '.$serial_no.' </div></a>';
		}else{
		$lnk1 = '<a class="removeqt" item_id="'.$orderdetail['item_id'].'"><div  class="order_frist"> '.$serial_no.' </div></a>';
		}
		//----------------
		if($orderdetail['section_id']){$pending_kot='style="color:yellow"';}else{$pending_kot='';}
		$html .='<div class="bill_row"'.$pending_kot.'>'.$lnk1.'<div class="order_second"> '.$link.'</div><div class="order_third">'.$orderdetail['quantity'].'</div><div class="order_fourth"> '.$orderdetail['rate'].
	' </div><div class="order_fifth_item" item_type="'.$orderdetail['discounted'].'"> '.$orderdetail['quantity']*$orderdetail['rate'].' </div></div>';
 
  }//end foreach
  
  echo $html;
     }
      
   
   
  }
  ///////// recipe open=true //////////
  
    
 }
 else
 {
  if($model->save()){ 
     
           Yii::app()->db->createCommand('update tableorder set total='.$_POST['total'].',gst='.(float)$_POST['gst'].',discount='.(float)$_POST['discount'].' where id='.$model->tableorder_id)->execute();
     //echo 1;
	 $orderdetails = Yii::app()->db->createCommand('select i.*,od.* from orderdetail od join item i on od.item_id=i.id where tableorder_id='.(int)$_POST['tableorder_id'])->queryAll();
		//echo 'fourth';
		//print_r($orderdetails);
		$html ='';
		$serial_no=0;
		foreach($orderdetails as $orderdetail){
		$serial_no++;
		//--------------------
		if($orderdetail['quantity']>0 && $itemdetail){
		$link = CHtml::link($orderdetail['name'],array('tableorder/extrasCreate/'.$orderdetail['id']),array('class'=>'update-dialog-create','id'=>Yii::t('strings','Create Extras')));
		}else{
		$link=$orderdetail['name'];
		}
		//--------------
		if($orderdetail['quantity']>0){
		$lnk1 = '<a style="float:left" class="removeqt removeqt1" item_id="'.$orderdetail['item_id'].
	'"  href="javascript:void(0)">'.'<div  class="order_frist"> '.$serial_no.' </div></a>';
		}else{
		$lnk1 = '<a class="removeqt" item_id="'.$orderdetail['item_id'].'"><div  class="order_frist"> '.$serial_no.' </div></a>';
		}
		//----------------
		if($orderdetail['section_id']){$pending_kot='style="color:yellow"';}else{$pending_kot='';}
		$html .='<div class="bill_row"'.$pending_kot.'>'.$lnk1.'<div class="order_second"> '.$link.'</div><div class="order_third">'.$orderdetail['quantity'].'</div><div class="order_fourth"> '.$orderdetail['rate'].
	' </div><div class="order_fifth_item" item_type="'.$orderdetail['discounted'].'"> '.$orderdetail['quantity']*$orderdetail['rate'].' </div></div>';
	
		}//end foreach
		
		echo $html;
      }
     else
     {
      echo 0;
     }
 }
 
 }
///////// ware house exist condition end ////////////

}


public function actionLoadTables()
{
$tables = Yii::app()->db->createCommand('select id,tableno,check_no from tableorder where status=0')->queryAll();
echo $tables = json_encode($tables);
}

public function actionPosting($id){


$model=new Tableorder;

$model->tableno='05';
$model->waiter_id ='1';
$model->check_no ='1';
$model->cover='5';

$this->performAjaxValidation($model);

if(isset($_POST['Tableorder']))
{
//$model->attributes=$_POST['Tableorder'];
//$model->date_of_tableorder=date('Y-m-d H:i:s');

if($model->validate() ){//posting to faisal app from here

$tableorder=$this->loadModel($id);
$tableorder->status=1;
$tableorder->payment=$_REQUEST['payment'];
$tableorder->gst=$_REQUEST['gst'];
$tableorder->mop=$_POST['Tableorder']['mop'];
$tableorder->save();

$c_date=date('Y-m-d H:i:s');
$c_time=date('H:i:s');
$chkin_id='0';
$service_id='8';

$room_id = $_POST['Tableorder']['room_id'];
/*if($room_id>0){//it is HMS Guest
$checkin_rs = Yii::app()->dbhotel->createCommand("select * from hms_checkin_info where room_id=$room_id and chkout_status='N'")->queryRow();
$guest_name = Yii::app()->dbhotel->createCommand("select guest_name from hms_guest_info where guest_id=".$checkin_rs['guest_id'])->queryScalar();

Yii::app()->dbhotel->createCommand("insert into hms_guest_ledger 
(chkin_id,guest_name,room_status,room_id,chkin_date,chkout_date,c_date,c_time,service_id,remarks,debit,btc,company_id)
values
(".$checkin_rs['chkin_id'].",'".$guest_name."','O',".$checkin_rs['room_id'].",'".$checkin_rs['chkin_date']."','".$checkin_rs['chkout_date']."','".$c_date."','".$c_time."',".$service_id.",'".$tableorder->check_no."',".$tableorder->total.",".$_POST['Tableorder']['mop'].",".$_POST['Tableorder']['company_id'].")")->execute();

}else{//It is not a HMS Guest
Yii::app()->dbhotel->createCommand("insert into hms_guest_ledger (chkin_id,service_id,debit,btc,company_id,c_date,c_time)values($chkin_id,$service_id,".$tableorder->total.",".$_POST['Tableorder']['mop'].",".$_POST['Tableorder']['company_id'].",'$c_date','$c_time')")->execute();
}
*/




	if( Yii::app()->request->isAjaxRequest )
		  {
			// Stop jQuery from re-initialization
			Yii::app()->clientScript->scriptMap['jquery.js'] = false;
	 	$json_arr = array(
			  'status' => 'success',
			  'hms_id' => 1,
			  'url' => $_SERVER['REQUEST_URI'],
			  'content' => 'tableorder successfully Created',
			  
			);
			
			echo CJSON::encode($json_arr);
			exit;
		  }else{
          	Yii::app()->user->setFlash('success','tableorder successfully created.');	
			$this->redirect( array( 'view', 'id' => $model->id ) );
		  }
}

}//end post

				if( Yii::app()->request->isAjaxRequest ){
					// Stop jQuery from re-initialization
					Yii::app()->clientScript->scriptMap['jquery.js'] = false;
				 	echo CJSON::encode( array(
					  'status' => 'failure',
					  'url' => $_SERVER['REQUEST_URI'],
					  'content' => $this->renderPartial( '_post', array(
					  'model' => $model), true, true ),
					));
					exit;
				  }else{
					$this->render( '_post', array( 'model' => $model) );
				  }
	
	
}
public function actionCreate()
{
$msg='';
$model=new Tableorder;
$model->check_no = 1+(int)Yii::app()->db->createCommand("select max(check_no) from tableorder")->queryScalar();
$table_id=0;
if(!empty($_POST['Tableorder']['tableno'])){
$table_id = Yii::app()->db->createCommand("select id from tableorder where status=0 and tableno like '".$_POST['Tableorder']['tableno']."'")->queryScalar();
if($table_id>0){$msg='This table is already in List';}
}
// Uncomment the following line if AJAX validation is needed

$this->performAjaxValidation($model);

if(isset($_POST['Tableorder']))
{
$model->attributes=$_POST['Tableorder'];

if($_POST['Tableorder']['gst']==1)
{
$model->gst_rate=16;
}else{
$model->gst_rate=0;	
}

//$model->date_of_tableorder=date('Y-m-d H:i:s');
$model->created_time=date('Y-m-d H:i:s');
$model->weekno=(int)date('W');

$closetime=Yii::app()->session['settings']['closetime'];
$time =  date('H',strtotime(date('Y-m-d H:i:s')));
if( $time>=0 && $time<$closetime && $closetime>=0 && $closetime<8){
$model->date_of_tableorder=date('Y-m-d',strtotime(date('Y-m-d').'-1 day'));
}else{
$model->date_of_tableorder=date('Y-m-d');
}



if($model->validate()  && $table_id==0 ){
$model->check_no = 1+(int)Yii::app()->db->createCommand("select max(check_no) from tableorder")->queryScalar();
$model->save();
	if( Yii::app()->request->isAjaxRequest )
		  {
			// Stop jQuery from re-initialization
			Yii::app()->clientScript->scriptMap['jquery.js'] = false;
	 	$json_arr = array(
			  'status' => 'success',
			  'grid' => 'categories-grid',
			  'url' => $_SERVER['REQUEST_URI'],
			  'content' => 'tableorder successfully Created',
			  'cover'=>$model->cover,
			  'tableno'=>$model->tableno,
			  'waiter_id'=>$model->waiter->name,
			  'tableorder_id'=>$model->id,
			  'check_no'=>$model->check_no,
			  'tableordertype'=>$model->tableordertype,
			  'name'=>$model->name,
			  'phone'=>$model->phone,
			  'address'=>$model->address,
			  'gst_rate'=>$model->gst_rate,
			  'discountrate'=>$model->discountrate,
			  'discount'=>$model->discount,
			  
			);
			
			echo CJSON::encode($json_arr);
			exit;
		  }else{
          	Yii::app()->user->setFlash('success','tableorder successfully created.');	
			$this->redirect( array( 'view', 'id' => $model->id ) );
		  }
}

}//end post

				if( Yii::app()->request->isAjaxRequest ){
					// Stop jQuery from re-initialization
					Yii::app()->clientScript->scriptMap['jquery.js'] = false;
				 	echo CJSON::encode( array(
					  'status' => 'failure',
					  'url' => $_SERVER['REQUEST_URI'],
					  'content' => $this->renderPartial( '_form', array(
					  'model' => $model,'msg'=>$msg,), true, true ),
					));
					exit;
				  }else{
					$this->render( 'create', array( 'model' => $model) );
				  }
}//end function



public function actionExtrasCreate($id)
{

$model=Orderdetail::model()->find('id='.(int)$id);

// Uncomment the following line if AJAX validation is needed

$this->performAjaxValidation($model);

if(isset($_POST['Orderdetail']))
{
//print_r($_POST);
//echo json_encode($_POST['Orderdetail']['extras']);
$model->description=$_POST['Orderdetail']['description'];
$model->extras=json_encode($_POST['extras']);


if($model->validate()  ){
$model->save();
	if( Yii::app()->request->isAjaxRequest )
		  {
			// Stop jQuery from re-initialization
			Yii::app()->clientScript->scriptMap['jquery.js'] = false;
	 	$json_arr = array(
			  'status' => 'success',
			  'grid' => 'categories-grid',
			  'url' => $_SERVER['REQUEST_URI'],
			  'content' => '',
			  /*'cover'=>$model->cover,
			  'tableno'=>$model->tableno,
			  'waiter_id'=>$model->waiter->name,
			  'tableorder_id'=>$model->id,
			  'check_no'=>$model->check_no,
			  
			  'gst_rate'=>$model->gst_rate,
			  'discountrate'=>$model->discountrate,
			  'discount'=>$model->discount,*/
			  
			);
			
			echo CJSON::encode($json_arr);
			exit;
		  }else{
          	Yii::app()->user->setFlash('success','tableorder successfully created.');	
			$this->redirect( array( 'view', 'id' => $model->id ) );
		  }
}

}//end post

				if( Yii::app()->request->isAjaxRequest ){
					// Stop jQuery from re-initialization
					Yii::app()->clientScript->scriptMap['jquery.js'] = false;
				 	echo CJSON::encode( array(
					  'status' => 'failure',
					  'url' => $_SERVER['REQUEST_URI'],
					  'content' => $this->renderPartial( 'extras', array(
					  'model' => $model,'msg'=>$msg,), true, true ),
					));
					exit;
				  }else{
					$this->render( 'extras', array( 'model' => $model) );
				  }
}//end function


/**
* Updates a particular model.
* If update is successful, the browser will be redirected to the 'view' page.
* @param integer $id the ID of the model to be updated
*/
public function actionUpdateTableOrder($id){
$model=$this->loadModel($id);
$model->status=$_POST['status'];
if($model->save()){echo '1';}else{echo 'problem in saving';}
}//end function

public function actionTable_old_OrderInfo($id){
$model=$this->loadModel($id);
$orderdetail = Yii::app()->db->createCommand('select * from orderdetail where tableorder_id='.(int)$id)->queryAll();

$item_ids = array();
foreach($orderdetail as $row){
$item_ids[$row['item_id']] = $row['item_id'];	
}

$distinct_items = count($item_ids);
if($distinct_items>0){
$item_ids = implode(',',$item_ids);
$items_rs = Yii::app()->db->createCommand('select * from item where id in ('.$item_ids.') limit '.$distinct_items)->queryAll();
$item_names = array();
foreach($items_rs as $row){
$item_names[$row['id']]	= $row['name'];
$item_types[$row['id']] = $row['item_type'];
}

foreach($orderdetail as $k=>$row){
$orderdetail[$k]['item_name'] = $item_names[$row['item_id']];
$orderdetail[$k]['item_type'] = $item_types[$row['item_id']];
}
}//end if items count

//echo '<pre>';
//print_r($neworderdetail);
//echo '</pre>';
					echo CJSON::encode( array(
					  'status' => 'failure',
					  'id' => $model->id,
					  'tableno' => $model->tableno,
					  'waiter_id' => $model->waiter->name,
					  'covers' => $model->cover,
					  'check_no' => $model->check_no,
					  'tableordertype'=>$model->tableordertype,
			  'name'=>$model->name,
			  'phone'=>$model->phone,
			  'address'=>$model->address,
					  'orderdetail' => $orderdetail,
					  'gst_rate' => $model->gst_rate,
					  'gst' => $model->gst,
					  'discountrate' => $model->discountrate,
					  'discount' => $model->discount,
					));
					
					exit;
					

}//end function


public function actionTableOrderInfo($id){
$model=$this->loadModel($id);
$itemdetail = (int)Yii::app()->session['settings']['order_detail'];
//$orderdetail = Yii::app()->db->createCommand('select * from orderdetail where tableorder_id='.(int)$id)->queryAll();

$orderdetails = Yii::app()->db->createCommand('select i.*,od.* from orderdetail od join item i on od.item_id=i.id where tableorder_id='.(int)$id)->queryAll();
		//echo 'fourth';
		//print_r($orderdetails);
		$html ='';
		$serial_no=0;
		foreach($orderdetails as $orderdetail){
		$serial_no++;
		//--------------------
		if($orderdetail['quantity']>0 && $itemdetail){
		$link = CHtml::link($orderdetail['name'],array('tableorder/extrasCreate/'.$orderdetail['id']),array('class'=>'update-dialog-create','id'=>Yii::t('strings','Create Extras')));
		}else{
		$link=$orderdetail['name'];
		}
		//--------------
		if($orderdetail['quantity']>0){
		$lnk1 = '<a style="float:left" class="removeqt removeqt1" item_id="'.$orderdetail['item_id'].
	'"  href="javascript:void(0)">'.'<div  class="order_frist"> '.$serial_no.' </div></a>';
		}else{
		$lnk1 = '<a class="removeqt" item_id="'.$orderdetail['item_id'].'"><div  class="order_frist"> '.$serial_no.' </div></a>';
		}
		//----------------
		if($orderdetail['section_id']){$pending_kot='style="color:yellow"';}else{$pending_kot='';}
		$html .='<div class="bill_row"'.$pending_kot.'>'.$lnk1.'<div class="order_second" style="text-align:right"> '.$link.'</div><div class="order_third">'.$orderdetail['quantity'].'</div><div class="order_fourth"> '.$orderdetail['rate'].
	' </div><div class="order_fifth_item" item_type="'.$orderdetail['discounted'].'"> '.$orderdetail['quantity']*$orderdetail['rate'].' </div></div>';
	
		}//end foreach
		

					echo CJSON::encode( array(
					  'status' => 'failure',
					  'id' => $model->id,
					  'tableno' => $model->tableno,
					  'waiter_id' => $model->waiter->name,
					  'covers' => $model->cover,
					  'check_no' => $model->check_no,
					  'tableordertype'=>$model->tableordertype,
			  'name'=>$model->name,
			  'phone'=>$model->phone,
			  'address'=>$model->address,
					  'orderdetail' => $html,
					  'gst_rate' => $model->gst_rate,
					  'gst' => $model->gst,
					  'discountrate' => $model->discountrate,
					  'discount' => $model->discount,
					));
					

					exit;
					

}//end function


public function actionUpdate($id)
{
$model=$this->loadModel($id);

// Uncomment the following line if AJAX validation is needed
$this->performAjaxValidation($model);

if(isset($_POST['Tableorder']))
{
$model->attributes=$_POST['Tableorder'];
	
	if($model->save()){
		
		if( Yii::app()->request->isAjaxRequest ){
			// Stop jQuery from re-initialization
			Yii::app()->clientScript->scriptMap['jquery.js'] = false;
	 		echo CJSON::encode( array(
			  'status' => 'success',
			  'url' => $_SERVER['REQUEST_URI'],
			  'grid' => 'asset-grid',//grid to update
			  'content' => 'tableorder successfully Updated',
			));
		exit;
		}else{
		Yii::app()->user->setFlash('success','tableorder successfully Updated');	
		$this->redirect(array('view','id'=>$model->id));
		}
	}//end if model save
}//end if POST


				if( Yii::app()->request->isAjaxRequest ){
					// Stop jQuery from re-initialization
					Yii::app()->clientScript->scriptMap['jquery.js'] = false;
				 	echo CJSON::encode( array(
					  'status' => 'failure',
					  'url' => $_SERVER['REQUEST_URI'],
					  'content' => $this->renderPartial( '_form', array(
					  'model' => $model), true, true ),
					));
					exit;
				  }else{
					$this->render( 'update', array( 'model' => $model) );
				  }

}//end function
/**
* Deletes a particular model.
* If deletion is successful, the browser will be redirected to the 'admin' page.
* @param integer $id the ID of the model to be deleted
*/
public function actionDelete($id)
{
if(Yii::app()->request->isPostRequest)
{
// we only allow deletion via POST request
$this->loadModel($id)->delete();

// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
if(!isset($_GET['ajax']))
$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
}
else
throw new CHttpException(400,'Invalid request. Please do not repeat this request again.');
}

/**
* Lists all models.
*/
public function actionIndex()
{
$this->actionAdmin();
exit;
$dataProvider=new CActiveDataProvider('tableorder');
$this->render('index',array(
'dataProvider'=>$dataProvider,
));
}

/**
* Manages all models.
*/
public function actionAdmin()
{
$model=new Tableorder('search');
$model->unsetAttributes();  // clear any default values
if(isset($_GET['Tableorder']))
$model->attributes=$_GET['Tableorder'];

$this->render('admin',array(
'model'=>$model,
));
}

/**
* Returns the data model based on the primary key given in the GET variable.
* If the data model is not found, an HTTP exception will be raised.
* @param integer the ID of the model to be loaded
*/
public function loadModel($id)
{
$model=Tableorder::model()->findByPk($id);
if($model===null)
throw new CHttpException(404,'The requested page does not exist.');
return $model;
}

/**
* Performs the AJAX validation.
* @param CModel the model to be validated
*/
protected function performAjaxValidation($model)
{
if(isset($_POST['ajax']) && $_POST['ajax']==='tableorder-form')
{
echo CActiveForm::validate($model);
Yii::app()->end();
}
}
}
