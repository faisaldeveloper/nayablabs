<?php

class HrEmployeeController extends Controller
{
/**
* @var string the default layout for the views. Defaults to '//layouts/column2', meaning
* using two-column layout. See 'protected/views/layouts/column2.php'.
*/
public $layout='//layouts/main-hr';

/**
* @return array action filters
*/
public function filters()
{
return array(
'accessControl', // perform access control for CRUD operations
);
}

/**
* Specifies the access control rules.
* This method is used by the 'accessControl' filter.
* @return array access control rules
*/
    public function actions()
    {
    return array(
    'toggle' => array(
    'class'=>'bootstrap.actions.TbToggleAction',
    'modelName' => 'HrEmployee',
    )
    );
    }
public function accessRules()
{
return array(
array('allow',  // allow all users to perform 'index' and 'view' actions
'actions'=>array('index','view'),
'users'=>array('*'),
),
array('allow', // allow authenticated user to perform 'create' and 'update' actions
'actions'=>array('create','update','toggle'),
'users'=>array('@'),
),
array('allow', // allow admin user to perform 'admin' and 'delete' actions
'actions'=>array('admin','delete'),
'users'=>array('admin'),
),
array('deny',  // deny all users
'users'=>array('*'),
),
);
}*/

/**
* Displays a particular model.
* @param integer $id the ID of the model to be displayed
*/
public function actionView($id)
{
		$model = $this->loadModel($id);
		
		if( Yii::app()->request->isAjaxRequest )
		  {
			// Stop jQuery from re-initialization
			Yii::app()->clientScript->scriptMap['jquery.js'] = false;
		 	echo CJSON::encode( array(
			  'status' => 'failure',
			  'content' => $this->renderPartial( 'view', array('model' => $model ), true, true ),));
			exit;
		  }
		  else
			$this->render( 'view', array( 'model' => $model ) );
	  
	  
}

/**
* Creates a new model.
* If creation is successful, the browser will be redirected to the 'view' page.
*/
public function actionCreate()
{

$model=new HrEmployee;

// Uncomment the following line if AJAX validation is needed

$this->performAjaxValidation($model);

if(isset($_POST['HrEmployee']))
{
$model->attributes=$_POST['HrEmployee'];
if($model->save()){

	if( Yii::app()->request->isAjaxRequest )
		  {
			// Stop jQuery from re-initialization
			Yii::app()->clientScript->scriptMap['jquery.js'] = false;
	 
	 		$json_arr = array(
			  'status' => 'success',
			  'grid' => 'categories-grid',
			  'url' => $_SERVER['REQUEST_URI'],
			  'content' => 'Categories successfully Created',
			);
			if(isset($_GET['dropDownList'])){
			$json_arr['inputType']='dropDownList';
			$json_arr['inputId']=$_GET['dropDownList'];
			$json_arr['inputData']=CHtml::tag('option',array('value'=>$model->id,'selected'=>true),CHtml::encode($model->name),true);
			}
			echo CJSON::encode($json_arr);
			exit;
		  }else{
          	Yii::app()->user->setFlash('success','HrEmployee successfully created.');	
			$this->redirect( array( 'view', 'id' => $model->id ) );
		  }
}//end model save
}//end post

				if( Yii::app()->request->isAjaxRequest ){
					// Stop jQuery from re-initialization
					Yii::app()->clientScript->scriptMap['jquery.js'] = false;
				 	echo CJSON::encode( array(
					  'status' => 'failure',
					  'url' => $_SERVER['REQUEST_URI'],
					  'content' => $this->renderPartial( '_form', array(
					  'model' => $model), true, true ),
					));
					exit;
				  }else{
					$this->render( 'create', array( 'model' => $model) );
				  }
}//end function
/**
* Updates a particular model.
* If update is successful, the browser will be redirected to the 'view' page.
* @param integer $id the ID of the model to be updated
*/
public function actionUpdate($id)
{
$employee=$this->loadModel($id);
if(count($employee)>0)
{
    $employee_earning=HrEmployeeEarning::model()->find('employee_id=:employee_id',array(':employee_id'=>$employee->id));
	$employee_deduction=HrEmployeeDeductions::model()->find('employee_id=:employee_id',array(':employee_id'=>$employee->id));
}
if(count($employee)>0 && $employee->account!=NULL)
$account=AccountChartOfAccount::model()->findByPK($employee->account);
if(count($employee)>0)
{
    
		
			$employee_leaves=HrEmployeeLeaves::model()->find('employee_id=:employee_id AND 
			name=:name',array(':employee_id'=>$employee->id,':name'=>'medical'));
			if(count($employee_leaves)>0)
			$employee->medical_leaves=$employee_leaves->available;
			
			$employee_leaves=HrEmployeeLeaves::model()->find('employee_id=:employee_id AND 
			name=:name',array(':employee_id'=>$employee->id,':name'=>'casual'));
			if(count($employee_leaves)>0)
			$employee->casual_leaves=$employee_leaves->available;
			
			$employee_leaves=HrEmployeeLeaves::model()->find('employee_id=:employee_id AND 
			name=:name',array(':employee_id'=>$employee->id,':name'=>'urgent'));
			if(count($employee_leaves)>0)
			$employee->urgent_leaves=$employee_leaves->available;
		
}
// Uncomment the following line if AJAX validation is needed
$this->performAjaxValidation($model);



if(isset($_POST['HrEmployee']))
 {
	/* echo "<pre>";
	 print_r($_POST);
	 echo "</pre>";
	 exit;*/
	$account->account_group=$_POST['AccountChartOfAccount']['account_group'];
	$account->account_code=substr($_POST['AccountChartOfAccount']['account_code'],5);
	$account->account_code_2=$_POST['AccountChartOfAccount']['account_code'];
	$account->account_name= $_POST['HrEmployee']['first_name'].$_POST['HrEmployee']['last_name'];
	$account->account_status=1;
	$account->account_type=1;
	     
	$employee->attributes=$_POST['HrEmployee'];
	$employee->active=$_POST['HrEmployee']['active'];
    $employee_earning->attributes=$_POST['HrEmployeeEarning'];
	$employee_deduction->attributes=$_POST['HrEmployeeDeductions'];
	if($account->validate() && $employee->validate())
	  {
		  
			if( $account->save())
		    {
				$employee->account=$account->id;
				if($employee->save())
				{
					if(isset($_POST['HrEmployee']['medical_leaves']))
	                {
		                $employee_leave=HrEmployeeLeaves::model()->find('name=:name AND     
						employee_id=:employee_id',
						array(':name'=>'medical',':employee_id'=>$employee->id));
		                if(count( $employee_leave)>0)
						{
							$employee_leave->available=(int)$_POST['HrEmployee']
							['medical_leaves'];
							$employee_leave->save();
						}
	                }
					if(isset($_POST['HrEmployee']['casual_leaves']))
	                {
		                $employee_leave=HrEmployeeLeaves::model()->find('name=:name AND     
						employee_id=:employee_id',
						array(':name'=>'casual',':employee_id'=>$employee->id));
		                if(count( $employee_leave)>0)
						{
							$employee_leave->available=(int)$_POST['HrEmployee']
							['casual_leaves'];
							$employee_leave->save();
						}
	                }
					if(isset($_POST['HrEmployee']['urgent_leaves']))
	                {
		                $employee_leave=HrEmployeeLeaves::model()->find('name=:name AND     
						employee_id=:employee_id',
						array(':name'=>'urgent',':employee_id'=>$employee->id));
		                if(count( $employee_leave)>0)
						{
							$employee_leave->available=(int)$_POST['HrEmployee']
							['urgent_leaves'];
							$employee_leave->save();
						}
	                }
					$employee_earning->employee_id=$employee->id;
					$employee_deduction->employee_id=$employee->id;
					$employee_earning->save();
					$employee_deduction->save();
			     Yii::app()->user->setFlash('success','Employee '.$employee->first_name.' '.$employee->last_name.' successfully Updated!');	
		         $this->redirect(array('HrEmployee/admin'));
				}
			}
			
	  }
	
 }
					$this->render( 'update', array( 'employee' => $employee,'account'=>$account,'employee_earning'=>$employee_earning,'employee_deduction'=>$employee_deduction) );
				

}//end function
/**
* Deletes a particular model.
* If deletion is successful, the browser will be redirected to the 'admin' page.
* @param integer $id the ID of the model to be deleted
*/
public function actionDelete($id)
{
	$model=$this->loadModel($id);
	$account=$model->account;
if(Yii::app()->request->isPostRequest)
{
// we only allow deletion via POST request
$this->loadModel($id)->delete();

// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser

if(!isset($_GET['ajax']))
$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
}
else
throw new CHttpException(400,'Invalid request. Please do not repeat this request again.');
}

/**
* Lists all models.
*/
public function actionIndex()
{
$this->actionAdmin();
exit;
$dataProvider=new CActiveDataProvider('HrEmployee');
$this->render('index',array(
'dataProvider'=>$dataProvider,
));
}

/**
* Manages all models.
*/
public function actionAdmin()
{
	
	$employee=new HrEmployee;
	$employee_earning=new HrEmployeeEarning;
	$employee_deduction=new HrEmployeeDeductions;
	$account=new AccountChartOfAccount;
	$account_group=AccountGroups::model()->findAll();
	$designation=HrDesignation::model()->findAll();
	$this->performAjaxValidation($employee);
	if(count($account_group)==0)
	{
		Yii::app()->user->setFlash('error','Create Account Group First!&nbsp;
&nbsp;
&nbsp;
<a href="'.Yii::app()->baseUrl.'/AccountGroups/admin">click here to create Account Group</a>');	
		//$this->redirect(array('AccountClasses/admin'));
		
	}
	if(count($designation)==0)
	{
		Yii::app()->user->setFlash('error','Create Designation First!&nbsp;
&nbsp;
&nbsp;
<a href="'.Yii::app()->baseUrl.'/HrDesignation/admin">click here to create Designations</a>');	
		//$this->redirect(array('AccountClasses/admin'));
		
	}
$model=new HrEmployee('search');
$model->unsetAttributes();  // clear any default values
if(isset($_GET['HrEmployee']))
$model->attributes=$_GET['HrEmployee'];

 if(isset($_POST['HrEmployee']))
 {
	 /*echo "<pre>";
	 print_r($_POST);
	 echo "</pre>";
	 exit;*/
	$account->account_group=$_POST['AccountChartOfAccount']['account_group'];
	$account->account_code=substr($_POST['AccountChartOfAccount']['account_code'],5);
	$account->account_code_2=$_POST['AccountChartOfAccount']['account_code'];
	$account->account_name= $_POST['HrEmployee']['first_name'].$_POST['HrEmployee']['last_name'];
	$account->account_status=1;
	$account->account_type=1;
	     
	$employee->attributes=$_POST['HrEmployee'];
	$employee->active=$_POST['HrEmployee']['active'];
	$employee_earning->attributes=$_POST['HrEmployeeEarning'];
	$employee_earning->sp_allownces=$_POST['HrEmployeeEarning']['sp_allownces'];
	$employee_deduction->attributes=$_POST['HrEmployeeDeductions'];
	
	if($account->validate() && $employee->validate())
	  {
			if( $account->save())
		    {
				$employee->account=$account->id;
				if($employee->save())
				{
					if(isset($_POST['HrEmployee']['medical_leaves']))
	                {
		                $employee_leave=new HrEmployeeLeaves;
		                $employee_leave->employee_id=$employee->id;
						$employee_leave->name="medical";
						$employee_leave->available=$_POST['HrEmployee']['medical_leaves'];
						$employee_leave->avail=0;
						$employee_leave->save();
						
	                }
					if(isset($_POST['HrEmployee']['casual_leaves']))
	                {
		                $employee_leave=new HrEmployeeLeaves;
		                $employee_leave->employee_id=$employee->id;
						$employee_leave->name="casual";
						$employee_leave->available=$_POST['HrEmployee']['casual_leaves'];
						$employee_leave->avail=0;
						$employee_leave->save();
	                }
					if(isset($_POST['HrEmployee']['urgent_leaves']))
	                {
		                $employee_leave=new HrEmployeeLeaves;
		                $employee_leave->employee_id=$employee->id;
						$employee_leave->name="urgent";
						$employee_leave->available=$_POST['HrEmployee']['urgent_leaves'];
						$employee_leave->avail=0;
						$employee_leave->save();
	                }
					$employee_earning->employee_id=$employee->id;
					$employee_deduction->employee_id=$employee->id;
					$employee_earning->save();
					$employee_deduction->save();
			        Yii::app()->user->setFlash('success','HrEmployee successfully Created');	
		            $this->redirect(array('HrEmployee/admin'));
					
				}
			}
			
	  }
	
 }
$this->render('admin',array(
'model'=>$model,'employee'=>$employee,'account'=>$account,'employee_earning'=>$employee_earning,'employee_deduction'=>$employee_deduction
));
}

/**
* Returns the data model based on the primary key given in the GET variable.
* If the data model is not found, an HTTP exception will be raised.
* @param integer the ID of the model to be loaded
*/
public function loadModel($id)
{
$model=HrEmployee::model()->findByPk($id);
if($model===null)
throw new CHttpException(404,'The requested page does not exist.');
return $model;
}

/**
* Performs the AJAX validation.
* @param CModel the model to be validated
*/
protected function performAjaxValidation($model)
{
if(isset($_POST['ajax']) && $_POST['ajax']==='hr-employee-form')
{
echo CActiveForm::validate($model);
Yii::app()->end();
}
}
}
