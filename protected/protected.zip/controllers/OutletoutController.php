<?php

class OutletoutController extends Controller
{
/**
* @var string the default layout for the views. Defaults to '//layouts/column2', meaning
* using two-column layout. See 'protected/views/layouts/column2.php'.
*/
public $layout='//layouts/column2';

/**
* @return array action filters
*/
public function filters()
{
return array(
'accessControl', // perform access control for CRUD operations
);
}

/**
* Specifies the access control rules.
* This method is used by the 'accessControl' filter.
* @return array access control rules
*/
/*public function accessRules()
{
return array(
array('allow',  // allow all users to perform 'index' and 'view' actions
'actions'=>array('index','view'),
'users'=>array('*'),
),
array('allow', // allow authenticated user to perform 'create' and 'update' actions
'actions'=>array('create','update'),
'users'=>array('@'),
),
array('allow', // allow admin user to perform 'admin' and 'delete' actions
'actions'=>array('admin','delete','refund','sale'),
'users'=>array('admin'),
),
array('deny',  // deny all users
'users'=>array('*'),
),
);
}*/

/**
* Displays a particular model.
* @param integer $id the ID of the model to be displayed
*/
public function actionsale($id)
{
$this->layout="//layouts/column1";
$model=new Outletout;
$stock_transfer=StockTransfer::model()->findByPk($id);
// Uncomment the following line if AJAX validation is needed

//$this->performAjaxValidation($model);

if(isset($_POST['Outletout']))
{
	/*echo "<pre>";
	print_r($_POST['Outletout']);
	echo "</pre>";
	exit;*/
        $model->attributes=$_POST['Outletout'];
        $model->category=$_POST['Outletout']['category'];
		$model->code=$_POST['Outletout']['code'];
		$model->discount_per=$_POST['Outletout']['discount_per'];
		$model->sales_tax_per=$_POST['Outletout']['sales_tax_per'];
		$model->purchase_total=$_POST['Outletout']['purchase_total'];
		$model->net_purchase_rate=$_POST['Outletout']['net_purchase_rate'];
		$model->sales_total=$_POST['Outletout']['sales_total'];
		$model->discount=$_POST['Outletout']['discount'];
		$model->section_id=$_POST['Outletout']['section_id'];
		$model->outlet_id=$_POST['Outletout']['outlet_id'];
		$model->stock_transfer_id=$_POST['Outletout']['stock_transfer_id'];
		$model->out_date=$_POST['Outletout']['out_date'];
		//$model->store_id=$_POST['Outletout']['store_id'];
		$datetime=$stock_transfer->enter_date;
        $dt = strtotime($datetime); 
        $date=date("Y-m-d", $dt);
if($date==date('Y-m-d'))
{
   if($model->save())
    {
	   $outlet_stock=OutletStock::model()->find('inventoryitem_id=:inventoryitem_id AND outlet_id=:outlet_id AND section_id=:section_id',array(':inventoryitem_id'=>$_POST['Outletout']['inventoryitem_id'],':outlet_id'=>$_POST['Outletout']['outlet_id'],':section_id'=>$_POST['Outletout']['section_id']));
	  if(count($outlet_stock)>0)
	  {
		  
		  $item_info=Inventoryitem::model()->findByPk($_POST['Outletout']['inventoryitem_id']);
		  if(count($item_info)>0)
		  {	  
		  $stock=$_POST['Outletout']['quantity']*$item_info->per_purchase;
		  $outlet_stock->stock=$outlet_stock->stock-$stock;
		  $outlet_stock->save();
		  }
		    
	  }
	 Yii::app()->user->setFlash('success','Outletout successfully created.');	
			$this->redirect( array( 'outletout/refund', 'id' => $stock_transfer->id ) );
	 
  }
}
else
{
	Yii::app()->user->setFlash('error','Failed to add new item, Date not matched');
}
}//end post

				
					$this->render( 'sale', array( 'model' => $model,'stock_transfer'=>$stock_transfer) );
				 // }
}//end function
public function actionrefund($id)
{
$this->layout='//layouts/column1';
$model=new Outletout;
$stock_transfer=StockTransfer::model()->findByPk($id);
$stock_transfer->scenario = 'StockRefund'; 
// Uncomment the following line if AJAX validation is needed

//$this->performAjaxValidation($model);

if(isset($_POST['Outletout']))
{
	/*echo "<pre>";
	print_r($_POST['Outletout']);
	echo "</pre>";
	exit;*/
  $model->attributes=$_POST['Outletout'];
  $model->category=$_POST['Outletout']['category'];
		$model->code=$_POST['Outletout']['code'];
		$model->discount_per=$_POST['Outletout']['discount_per'];
		$model->sales_tax_per=$_POST['Outletout']['sales_tax_per'];
		$model->purchase_total=$_POST['Outletout']['purchase_total'];
		$model->net_purchase_rate=$_POST['Outletout']['net_purchase_rate'];
		$model->sales_total=$_POST['Outletout']['sales_total'];
		$model->discount=$_POST['Outletout']['discount'];
		$model->section_id=$_POST['Outletout']['section_id'];
		$model->outlet_id=$_POST['Outletout']['outlet_id'];
		$model->stock_transfer_id=$_POST['Outletout']['stock_transfer_id'];
		$model->out_date=$_POST['Outletout']['out_date'];
		//$model->store_id=$_POST['Outletout']['store_id'];
		$datetime=$stock_transfer->enter_date;
$dt = strtotime($datetime); 
$date=date("Y-m-d", $dt);
if($date==date('Y-m-d'))
{
  if($model->save())
  {
	  $outlet_stock=OutletStock::model()->find('inventoryitem_id=:inventoryitem_id AND outlet_id=:outlet_id AND section_id=:section_id',array(':inventoryitem_id'=>$_POST['Outletout']['inventoryitem_id'],':outlet_id'=>$_POST['Outletout']['outlet_id'],':section_id'=>$_POST['Outletout']['section_id']));
	  if(count($outlet_stock)>0)
	  {
		  
		  $item_info=Inventoryitem::model()->findByPk($_POST['Outletout']['inventoryitem_id']);
		  if(count($item_info)>0)
		  {	  
		  $stock=$_POST['Outletout']['quantity']*$item_info->per_purchase;
		  $outlet_stock->stock=$outlet_stock->stock-$stock;
		  $outlet_stock->save();
		  }
		    
	  }
	 Yii::app()->user->setFlash('success','Outletout successfully created.');	
			$this->redirect( array( 'outletout/refund', 'id' => $stock_transfer->id ) );
	 
  }
}
else
{
	Yii::app()->user->setFlash('error','Failed to add new item');
}
}//end post

				/*if( Yii::app()->request->isAjaxRequest ){
					// Stop jQuery from re-initialization
					Yii::app()->clientScript->scriptMap['jquery.js'] = false;
				 	echo CJSON::encode( array(
					  'status' => 'failure',
					  'url' => $_SERVER['REQUEST_URI'],
					  'content' => $this->renderPartial( 'refund', array(
					  'model' => $model,'stock_transfer'=>$stock_transfer), true, true ),
					));
					exit;
				  }else{*/
					$this->render( 'refund', array( 'model' => $model,'stock_transfer'=>$stock_transfer) );
				  //}
}//end function
public function actionView($id)
{
		$model = $this->loadModel($id);
		
		if( Yii::app()->request->isAjaxRequest )
		  {
			// Stop jQuery from re-initialization
			Yii::app()->clientScript->scriptMap['jquery.js'] = false;
		 	echo CJSON::encode( array(
			  'status' => 'failure',
			  'content' => $this->renderPartial( 'view', array('model' => $model ), true, true ),));
			exit;
		  }
		  else
			$this->render( 'view', array( 'model' => $model ) );
	  
	  
}

/**
* Creates a new model.
* If creation is successful, the browser will be redirected to the 'view' page.
*/
public function actionCreate()
{

$model=new Outletout;

// Uncomment the following line if AJAX validation is needed

$this->performAjaxValidation($model);

if(isset($_POST['Outletout']))
{
$model->attributes=$_POST['Outletout'];
if($model->save()){

	if( Yii::app()->request->isAjaxRequest )
		  {
			// Stop jQuery from re-initialization
			Yii::app()->clientScript->scriptMap['jquery.js'] = false;
	 
	 		$json_arr = array(
			  'status' => 'success',
			  'grid' => 'categories-grid',
			  'url' => $_SERVER['REQUEST_URI'],
			  'content' => 'Categories successfully Created',
			);
			if(isset($_GET['dropDownList'])){
			$json_arr['inputType']='dropDownList';
			$json_arr['inputId']=$_GET['dropDownList'];
			$json_arr['inputData']=CHtml::tag('option',array('value'=>$model->id,'selected'=>true),CHtml::encode($model->name),true);
			}
			echo CJSON::encode($json_arr);
			exit;
		  }else{
          	Yii::app()->user->setFlash('success','Outletout successfully created.');	
			$this->redirect( array( 'view', 'id' => $model->id ) );
		  }
}//end model save
}//end post

				if( Yii::app()->request->isAjaxRequest ){
					// Stop jQuery from re-initialization
					Yii::app()->clientScript->scriptMap['jquery.js'] = false;
				 	echo CJSON::encode( array(
					  'status' => 'failure',
					  'url' => $_SERVER['REQUEST_URI'],
					  'content' => $this->renderPartial( '_form', array(
					  'model' => $model), true, true ),
					));
					exit;
				  }else{
					$this->render( 'create', array( 'model' => $model) );
				  }
}//end function
/**
* Updates a particular model.
* If update is successful, the browser will be redirected to the 'view' page.
* @param integer $id the ID of the model to be updated
*/
public function actionUpdate($id)
{
	$this->layout='//layouts/column1';
$model=$this->loadModel($id);
$stock_transfer=StockTransfer::model()->findByPk($model->stock_transfer_id);
$before_quantity=$model->quantity;
//$stock_transfer->scenario = 'StockRefund'; 

// Uncomment the following line if AJAX validation is needed
$this->performAjaxValidation($model);

if(isset($_POST['Outletout']))
{
	/*echo "<pre>";
	print_r($_POST['Outletout']);
	echo "</pre>";
	exit;*/
        $model->category=$_POST['Outletout']['category'];
		$model->code=$_POST['Outletout']['code'];
		$model->discount_per=$_POST['Outletout']['discount_per'];
		$model->sales_tax_per=$_POST['Outletout']['sales_tax_per'];
		$model->purchase_total=$_POST['Outletout']['purchase_total'];
		$model->net_purchase_rate=$_POST['Outletout']['net_purchase_rate'];
		$model->sales_total=$_POST['Outletout']['sales_total'];
		$model->discount=$_POST['Outletout']['discount'];
		$model->section_id=$_POST['Outletout']['section_id'];
		$model->outlet_id=$_POST['Outletout']['outlet_id'];
		$model->stock_transfer_id=$_POST['Outletout']['stock_transfer_id'];
		$model->quantity=$_POST['Outletout']['quantity'];
		//$model->store_id=$_POST['Outletout']['store_id'];
		$datetime=$stock_transfer->enter_date;
$dt = strtotime($datetime); 
$date=date("Y-m-d", $dt);
if($date==date('Y-m-d'))
{
  if($model->save())
  {
	  
	  $outlet_stock=OutletStock::model()->find('inventoryitem_id=:inventoryitem_id AND outlet_id=:outlet_id AND section_id=:section_id',array(':inventoryitem_id'=>$_POST['Outletout']['inventoryitem_id'],':outlet_id'=>$_POST['Outletout']['outlet_id'],':section_id'=>$_POST['Outletout']['section_id']));
	  if(count($outlet_stock)>0)
	  {
		 
		  $item_info=Inventoryitem::model()->findByPk((int)$_POST['Outletout']['inventoryitem_id']);
		  if(count($item_info)>0)
		  {	  
		     
		     if($before_quantity > $_POST['Outletout']['quantity'])
		     {
				 
				 $diff=$before_quantity-$_POST['Outletout']['quantity'];
		         $stock=$diff*$item_info->per_purchase;
		         $outlet_stock->stock=$outlet_stock->stock+$stock;
		         $outlet_stock->save();
		     }
			 else if($before_quantity < $_POST['Outletout']['quantity'])
			 {
				
				  $diff=$_POST['Outletout']['quantity']-$before_quantity;
		          $stock=$diff*$item_info->per_purchase;
		          $outlet_stock->stock=$outlet_stock->stock-$stock;
		          $outlet_stock->save();
			 }
		  }
		    
	  }
	 Yii::app()->user->setFlash('success','Outletout successfully created.');	
			$this->redirect( array( 'outletout/refund', 'id' => $stock_transfer->id ) );
	 
  }
}
else
{
	Yii::app()->user->setFlash('Failed','Failed to add new item');
}
}//end if POST


				
					$this->render( 'update', array( 'model' => $model,'stock_transfer'=>$stock_transfer) );
				  
}//end function
/**
* Deletes a particular model.
* If deletion is successful, the browser will be redirected to the 'admin' page.
* @param integer $id the ID of the model to be deleted
*/
public function actionDelete($id)
{
	$model=$this->loadModel($id);
	$inventoryitem_id=$model->inventoryitem_id;
	$section_id=$model->section_id;
	$outlet_id=$model->outlet_id;
	$quantity=$model->quantity;
if(Yii::app()->request->isPostRequest)
{
// we only allow deletion via POST request
if($this->loadModel($id)->delete())
{
    $outlet_stock=OutletStock::model()->find('inventoryitem_id=:inventoryitem_id AND outlet_id=:outlet_id AND section_id=:section_id',array(':inventoryitem_id'=>$inventoryitem_id,':outlet_id'=>$outlet_id,':section_id'=>$section_id));
	  if(count($outlet_stock)>0)
	  {
		  
		  $item_info=Inventoryitem::model()->findByPk($inventoryitem_id);
		  if(count($item_info)>0)
		  {	  
		  $stock=$quantity*$item_info->per_purchase;
		  $outlet_stock->stock=$outlet_stock->stock+$stock;
		  $outlet_stock->save();
		  }
		    
	  }
}
// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
if(!isset($_GET['ajax']))
$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
}
else
throw new CHttpException(400,'Invalid request. Please do not repeat this request again.');
}

/**
* Lists all models.
*/
public function actionIndex()
{
$this->actionAdmin();
exit;
$dataProvider=new CActiveDataProvider('Outletout');
$this->render('index',array(
'dataProvider'=>$dataProvider,
));
}

/**
* Manages all models.
*/
public function actionAdmin()
{
	$this->layout='//layouts/column1';
$model=new Outletout('search');
$model->unsetAttributes();  // clear any default values
if(isset($_GET['Outletout']))
$model->attributes=$_GET['Outletout'];

$this->render('admin',array(
'model'=>$model,
));
}

/**
* Returns the data model based on the primary key given in the GET variable.
* If the data model is not found, an HTTP exception will be raised.
* @param integer the ID of the model to be loaded
*/
public function loadModel($id)
{
$model=Outletout::model()->findByPk($id);
if($model===null)
throw new CHttpException(404,'The requested page does not exist.');
return $model;
}

/**
* Performs the AJAX validation.
* @param CModel the model to be validated
*/
protected function performAjaxValidation($model)
{
if(isset($_POST['ajax']) && $_POST['ajax']==='outletout-form')
{
echo CActiveForm::validate($model);
Yii::app()->end();
}
}
}
