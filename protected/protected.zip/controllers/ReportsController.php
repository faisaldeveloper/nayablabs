<?php
class ReportsController extends SBaseController
{
	public function actionIndex()
	{
		$this->render('index');
	}
	
	public function actionDaily()
	{
		$this->render('daily');
	}
	
	public function actionWeekly()
	{
		$this->render('weekly');
	}
	
	public function actionMonthly()
	{
		$this->render('monthly');
	}
	
	public function actionYearly()
	{
		$this->render('yearly');
	}

	// Uncomment the following methods and override them if needed
	/*
	public function filters()
	{
		// return the filter configuration for this controller, e.g.:
		return array(
			'inlineFilterName',
			array(
				'class'=>'path.to.FilterClass',
				'propertyName'=>'propertyValue',
			),
		);
	}

	public function actions()
	{
		// return external action classes, e.g.:
		return array(
			'action1'=>'path.to.ActionClass',
			'action2'=>array(
				'class'=>'path.to.AnotherActionClass',
				'propertyName'=>'propertyValue',
			),
		);
	}
	*/
	
	public function actionDailyitemwise()
	{
		$this->render('dailyitemwise');
	}
	
	public function actionWeeklyitemwise()
	{
		$this->render('weeklyitemwise');
	}
	
	public function actionMonthlyitemwise()
	{
		$this->render('monthlyitemwise');
	}
	
	public function actionYearlyitemwise()
	{
		$this->render('yearlyitemwise');
	}
	
	public function actionTest()
	{
		$this->render('test');
	}
}