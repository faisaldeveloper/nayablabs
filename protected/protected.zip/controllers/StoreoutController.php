<?php

class StoreoutController extends Controller
{
/**
* @var string the default layout for the views. Defaults to '//layouts/column2', meaning
* using two-column layout. See 'protected/views/layouts/column2.php'.
*/
public $layout='//layouts/column1';

/**
* @return array action filters
*/
public function filters()
{
return array(
'accessControl', // perform access control for CRUD operations
);
}

/**
* Specifies the access control rules.
* This method is used by the 'accessControl' filter.
* @return array access control rules
*/
/*public function accessRules()
{
return array(
array('allow',  // allow all users to perform 'index' and 'view' actions
'actions'=>array('index','view'),
'users'=>array('*'),
),
array('allow', // allow authenticated user to perform 'create' and 'update' actions
'actions'=>array('create','update','StoreToStore'),
'users'=>array('@'),
),
array('allow', // allow admin user to perform 'admin' and 'delete' actions
'actions'=>array('admin','delete','refund','sale','transfer'),
'users'=>array('admin'),
),
array('deny',  // deny all users
'users'=>array('*'),
),
);
}*/

/**
* Displays a particular model.
* @param integer $id the ID of the model to be displayed
*/
public function actionView($id)
{
		$model = $this->loadModel($id);
		
		if( Yii::app()->request->isAjaxRequest )
		  {
			// Stop jQuery from re-initialization
			Yii::app()->clientScript->scriptMap['jquery.js'] = false;
		 	echo CJSON::encode( array(
			  'status' => 'failure',
			  'content' => $this->renderPartial( 'view', array('model' => $model ), true, true ),));
			exit;
		  }
		  else
			$this->render( 'view', array( 'model' => $model ) );
	  
	  
}

/**
* Creates a new model.
* If creation is successful, the browser will be redirected to the 'view' page.
*/
public function actionCreate()
{

$model=new Storeout;

// Uncomment the following line if AJAX validation is needed

$this->performAjaxValidation($model);

if(isset($_POST['Storeout']))
{
$model->attributes=$_POST['Storeout'];
if($model->save()){

	if( Yii::app()->request->isAjaxRequest )
		  {
			// Stop jQuery from re-initialization
			Yii::app()->clientScript->scriptMap['jquery.js'] = false;
	 
	 		$json_arr = array(
			  'status' => 'success',
			  'grid' => 'categories-grid',
			  'url' => $_SERVER['REQUEST_URI'],
			  'content' => 'Categories successfully Created',
			);
			if(isset($_GET['dropDownList'])){
			$json_arr['inputType']='dropDownList';
			$json_arr['inputId']=$_GET['dropDownList'];
			$json_arr['inputData']=CHtml::tag('option',array('value'=>$model->id,'selected'=>true),CHtml::encode($model->name),true);
			}
			echo CJSON::encode($json_arr);
			exit;
		  }else{
          	Yii::app()->user->setFlash('success','Storeout successfully created.');	
			$this->redirect( array( 'view', 'id' => $model->id ) );
		  }
}//end model save
}//end post

				if( Yii::app()->request->isAjaxRequest ){
					// Stop jQuery from re-initialization
					Yii::app()->clientScript->scriptMap['jquery.js'] = false;
				 	echo CJSON::encode( array(
					  'status' => 'failure',
					  'url' => $_SERVER['REQUEST_URI'],
					  'content' => $this->renderPartial( '_form', array(
					  'model' => $model), true, true ),
					));
					exit;
				  }else{
					$this->render( 'create', array( 'model' => $model) );
				  }
}//end function

public function actionrefund($id)
{

$model=new Storeout('refund');
$stock_transfer=StockTransfer::model()->findByPk($id);
$stock_transfer->scenario = 'StockRefund'; 
// Uncomment the following line if AJAX validation is needed

//$this->performAjaxValidation($model);

if(isset($_POST['Storeout']))
{
	/*echo "<pre>";
	print_r($_POST['Storeout']);
	echo "</pre>";
	exit;*/
  $model->attributes=$_POST['Storeout'];
  $model->category=$_POST['Storeout']['category'];
		$model->code=$_POST['Storeout']['code'];
		$model->discount_per=$_POST['Storeout']['discount_per'];
		$model->sales_tax_per=$_POST['Storeout']['sales_tax_per'];
		$model->purchase_total=$_POST['Storeout']['purchase_total'];
		$model->net_purchase_rate=$_POST['Storeout']['net_purchase_rate'];
		$model->sales_total=$_POST['Storeout']['sales_total'];
		$model->discount=$_POST['Storeout']['discount'];
  if($model->save())
  {
	  //unset($_POST['Storeout']);
	 // Yii::app()->user->setFlash('success','Storeout successfully created.');	
	  //$model=new Storeout('refund');
	  //$this->render( 'refund', array( 'model' => $model,'stock_transfer'=>$stock_transfer) );
	 // exit;
	
	 Yii::app()->user->setFlash('success','Storeout successfully created.');	
			$this->redirect( array( 'storeout/refund', 'id' => $stock_transfer->id ) );
	 
  }
}//end post

				/*if( Yii::app()->request->isAjaxRequest ){
					// Stop jQuery from re-initialization
					Yii::app()->clientScript->scriptMap['jquery.js'] = false;
				 	echo CJSON::encode( array(
					  'status' => 'failure',
					  'url' => $_SERVER['REQUEST_URI'],
					  'content' => $this->renderPartial( 'refund', array(
					  'model' => $model,'stock_transfer'=>$stock_transfer), true, true ),
					));
					exit;
				  }else{*/
					$this->render( 'refund', array( 'model' => $model,'stock_transfer'=>$stock_transfer) );
				  //}
}//end function

public function actionsale($id)
{

$model=new Storeout;
$stock_transfer=StockTransfer::model()->findByPk($id);
// Uncomment the following line if AJAX validation is needed

//$this->performAjaxValidation($model);

if(isset($_POST['Storeout']))
{
$model->attributes=$_POST['Storeout'];
  //$model->category=$_POST['Storein']['category'];
		 $model->category=$_POST['Storeout']['category'];
		$model->code=$_POST['Storeout']['code'];
		$model->discount_per=$_POST['Storeout']['discount_per'];
		$model->sales_tax_per=$_POST['Storeout']['sales_tax_per'];
		$model->purchase_total=$_POST['Storeout']['purchase_total'];
		$model->net_purchase_rate=$_POST['Storeout']['net_purchase_rate'];
		$model->sales_total=$_POST['Storeout']['sales_total'];
		$model->discount=$_POST['Storeout']['discount'];
if($model->save()){

	
          	Yii::app()->user->setFlash('success','Storeout successfully created.');	
			$this->redirect( array( 'storeout/sale', 'id' => $stock_transfer->id ) );
		//  }
}//end model save
}//end post

				
					$this->render( 'sale', array( 'model' => $model,'stock_transfer'=>$stock_transfer) );
				 // }
}//end function

public function actiontransfer($id)
{

$model=new Storeout;
$stock_transfer=StockTransfer::model()->findByPk($id);
$stock_transfer->scenario = 'StockTransfer';
// Uncomment the following line if AJAX validation is needed

//$this->performAjaxValidation($model);

if(isset($_POST['Storeout']))
{
	/*echo '<pre>';
	print_r($_POST['Storeout']);
	echo '</pre>';
	exit;*/
	$model->attributes=$_POST['Storeout'];
	$model->section_id=$_POST['Storeout']['section_id'];
  $model->category=$_POST['Storeout']['category'];
		$model->code=$_POST['Storeout']['code'];
		$model->discount_per=$_POST['Storeout']['discount_per'];
		$model->sales_tax_per=$_POST['Storeout']['sales_tax_per'];
		$model->purchase_total=$_POST['Storeout']['purchase_total'];
		$model->net_purchase_rate=$_POST['Storeout']['net_purchase_rate'];
		$model->sales_total=$_POST['Storeout']['sales_total'];
		$model->discount=$_POST['Storeout']['discount'];
       
		
         if($model->save()){
           
		    $outletin=new Outletin;
			$outletin->outlet_id=$model->outlet_id;
			$outletin->inventoryitem_id=$model->inventoryitem_id;
			$outletin->doi=date('Y-m-d H:i:s');
			$outletin->quantity=$model->quantity;
			$outletin->store_id=$model->store_id;
			$outletin->remarks=$model->remarks;
			$outletin->enter_by=$model->enter_by;
			$outletin->section_id=$model->section_id;
			$outletin->stock_transfer_id=$model->stock_transfer_id;
			if($outletin->save()){
				
				$outlet_stock=OutletStock::model()->find('inventoryitem_id=:inventoryitem_id AND          outlet_id=:outlet_id AND section_id=:section_id',array(':inventoryitem_id'=>
	   $outletin->inventoryitem_id,':outlet_id'=>$outletin->outlet_id,':section_id'=>$model->section_id));
	           if(count($outlet_stock)>0)
			    {
				  $item_info=Inventoryitem::model()->findByPk($outletin->inventoryitem_id);
			  
						   $stock=$outletin->quantity*$item_info->per_purchase;
				 $outlet_stock->stock=$outlet_stock->stock+$stock;
				 $outlet_stock->save();
			    }
			 
			    else
			   {
				   $outlet_stock=new OutletStock;
				   $outlet_stock->inventoryitem_id=$outletin->inventoryitem_id;
				   $outlet_stock->outlet_id=$outletin->outlet_id;
				   $outlet_stock->section_id=$model->section_id;
				   $item_info=Inventoryitem::model()->findByPk($outletin->inventoryitem_id);
			  
						   $stock=$outletin->quantity*$item_info->per_purchase;
				 //$outlet_stock->stock=$outlet_stock->stock+$stock;
				   $outlet_stock->stock=$stock;
				   $outlet_stock->save();  
				 
			   }
			}
			else
			{
				print_r($outletin->getErrors());
			}
          	Yii::app()->user->setFlash('success','Storeout successfully created.');	
			$this->redirect( array( 'storeout/transfer', 'id' => $stock_transfer->id ) );
		  }

}//end post

					$this->render( 'transfer', array( 'model' => $model,'stock_transfer'=>$stock_transfer) );
				  //}
}//end function
/**


* Updates a particular model.
* If update is successful, the browser will be redirected to the 'view' page.
* @param integer $id the ID of the model to be updated
*/
public function actionStoreToStore($id){
	$stock_transfer=StockTransfer::model()->findByPk($id);
	$stock_transfer->scenario = 'StoreToStore';
	$model=new Storeout;
	if(isset($_POST['Storeout']))
    {
		/*echo "<pre>";
		print_r($_POST['Storeout']);
		echo "</pre>";
		exit;*/
		$model->attributes=$_POST['Storeout'];
		if($model->save())
		{
			
			$storein=new Storein("storetostore");
			$storein->inventoryitem_id=$model->inventoryitem_id;
			$storein->quantity=$model->quantity;
			$storein->store_id=$stock_transfer->tostore_id;
			$storein->stocktransfer_id=$model->stock_transfer_id;
			if($storein->save())
			{
				 $item=Inventoryitem::model()->findByPk($model->inventoryitem_id);
				 $stock=$model->quantity*$item->per_purchase;
				 $to_stock=	StoreStock::model()->find("store_id=".$stock_transfer->tostore_id." AND inventoryitem_id=".$model->inventoryitem_id);
				 if(count($to_stock)>0)
				  {
				     $to_stock->stock=$to_stock->stock+$stock;
				     $to_stock->save();	
				  }
				 else
				  {
					 $to_stock=new StoreStock;
					 $to_stock->inventoryitem_id=$model->inventoryitem_id;
					 $to_stock->store_id=$stock_transfer->tostore_id;
					 $to_stock->stock=$to_stock->stock+$stock;
					 $to_stock->save();
				  }
				
			} //////storein model save end
		} ///// storeout model save end
		Yii::app()->user->setFlash('success','Storeout successfully created.');	
			$this->redirect( array( 'storeout/StoreToStore', 'id' => $stock_transfer->id ) );
	} //// post end
	$this->render( 'storetostore', array( 'model' => $model,'stock_transfer'=>$stock_transfer) );
}
public function actionUpdate($id)
{
$model=$this->loadModel($id);

// Uncomment the following line if AJAX validation is needed
$this->performAjaxValidation($model);

if(isset($_POST['Storeout']))
{
$model->attributes=$_POST['Storeout'];
	
	if($model->save()){
		
		if( Yii::app()->request->isAjaxRequest ){
			// Stop jQuery from re-initialization
			Yii::app()->clientScript->scriptMap['jquery.js'] = false;
	 		echo CJSON::encode( array(
			  'status' => 'success',
			  'url' => $_SERVER['REQUEST_URI'],
			  'grid' => 'asset-grid',//grid to update
			  'content' => 'Storeout successfully Updated',
			));
		exit;
		}else{
		Yii::app()->user->setFlash('success','Storeout successfully Updated');	
		$this->redirect(array('view','id'=>$model->id));
		}
	}//end if model save
}//end if POST


				if( Yii::app()->request->isAjaxRequest ){
					// Stop jQuery from re-initialization
					Yii::app()->clientScript->scriptMap['jquery.js'] = false;
				 	echo CJSON::encode( array(
					  'status' => 'failure',
					  'url' => $_SERVER['REQUEST_URI'],
					  'content' => $this->renderPartial( '_form', array(
					  'model' => $model), true, true ),
					));
					exit;
				  }else{
					$this->render( 'update', array( 'model' => $model) );
				  }

}//end function
/**
* Deletes a particular model.
* If deletion is successful, the browser will be redirected to the 'admin' page.
* @param integer $id the ID of the model to be deleted
*/
public function actionDelete($id)
{
	$storeout=Storeout::model()->findByPk($id);
	$inventoryitem_id=$storeout->inventoryitem_id;
	$store_id=$storeout->store_id;
	$quantity=$storeout->quantity;
	$stock_transfer=StockTransfer::model()->findByPk($storeout->stock_transfer_id);
if(Yii::app()->request->isPostRequest)
{
// we only allow deletion via POST request
if($this->loadModel($id)->delete())
{
	$store_stock=StoreStock::model()->find('inventoryitem_id=:inventoryitem_id AND store_id=:store_id',array(':inventoryitem_id'=>$inventoryitem_id,':store_id'=>$store_id));
	if(count($store_stock)>0) ////// add deletd quantity in stock
	{
		 $item_info=Inventoryitem::model()->findByPk($inventoryitem_id);
			  
						   $stock=$quantity*$item_info->per_purchase;
		$store_stock->stock=$store_stock->stock+$stock;
		if($store_stock->save())////// add deletd quantity in stock
		{
		   if($stock_transfer->transfer_type==2) ///////// if transfer type then change the deletd outletin and outlet stock////////
	        {
		     $outletin=Outletin::model()->find('stock_transfer_id=:stock_transfer_id AND inventoryitem_id=:inventoryitem_id',array(':stock_transfer_id'=>$stock_transfer->id,':inventoryitem_id'=>$inventoryitem_id));
			 
			  if(count($outletin)>0)
			  {
				   $outlet_id=$outletin->outlet_id;
				   $outletin->status='d'; 
				if($outletin->save()) ///// changing status of outletin to 'd'//////
				{
					$outlet_stock=OutletStock::model()->find('outlet_id=:outlet_id AND inventoryitem_id=:inventoryitem_id',array(':inventoryitem_id'=>$inventoryitem_id,':outlet_id'=>$outlet_id));       
					if(count($outlet_stock)>0)///// subtracting outlet stock//////
					{
						 $item_info=Inventoryitem::model()->findByPk($inventoryitem_id);
			  
						   $stock=$quantity*$item_info->per_purchase;
					$outlet_stock->stock=$outlet_stock->stock-$stock;
					$outlet_stock->save();
					}
					
					
				}
			  }
		
	        }	
			if($stock_transfer->transfer_type==5) ////////// if type is store to store
	{
	
		 $item=Inventoryitem::model()->findByPk($inventoryitem_id);
				 $stock=$quantity*$item->per_purchase;
				 $to_stock=	StoreStock::model()->find("store_id=".$stock_transfer->tostore_id." AND inventoryitem_id=".$inventoryitem_id);
				 if(count($to_stock)>0)
				  {
				     $to_stock->stock=$to_stock->stock-$stock;
				     $to_stock->save();	
				  }
				 else
				  {
					 $to_stock=new StoreStock;
					 $to_stock->inventoryitem_id=$inventoryitem_id;
					 $to_stock->store_id=$stock_transfer->tostore_id;
					 $to_stock->stock=$to_stock->stock-$stock;
					 $to_stock->save();
				  }
		
	} ///////// store to store end
		}
	}
	
	
}

// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
if(!isset($_GET['ajax']))
$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
}
else
throw new CHttpException(400,'Invalid request. Please do not repeat this request again.');
}

/**
* Lists all models.
*/
public function actionIndex()
{
$this->actionAdmin();
exit;
$dataProvider=new CActiveDataProvider('Storeout');
$this->render('index',array(
'dataProvider'=>$dataProvider,
));
}

/**
* Manages all models.
*/
public function actionAdmin()
{
$model=new Storeout('search');
$model->unsetAttributes();  // clear any default values
if(isset($_GET['Storeout']))
$model->attributes=$_GET['Storeout'];

$this->render('admin',array(
'model'=>$model,
));
}

/**
* Returns the data model based on the primary key given in the GET variable.
* If the data model is not found, an HTTP exception will be raised.
* @param integer the ID of the model to be loaded
*/
public function loadModel($id)
{
$model=Storeout::model()->findByPk($id);
if($model===null)
throw new CHttpException(404,'The requested page does not exist.');
return $model;
}

/**
* Performs the AJAX validation.
* @param CModel the model to be validated
*/
protected function performAjaxValidation($model)
{
if(isset($_POST['ajax']) && $_POST['ajax']==='storeout-form')
{
echo CActiveForm::validate($model);
Yii::app()->end();
}

}
}
