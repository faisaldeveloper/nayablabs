<?php

class StoreinController extends Controller
{
/**
* @var string the default layout for the views. Defaults to '//layouts/column2', meaning
* using two-column layout. See 'protected/views/layouts/column2.php'.
*/
public $layout='//layouts/column1';

/**
* @return array action filters
*/
public function filters()
{
return array(
'accessControl', // perform access control for CRUD operations
);
}

/**
* Specifies the access control rules.
* This method is used by the 'accessControl' filter.
* @return array access control rules
*/
/*public function accessRules()
{
return array(
array('allow',  // allow all users to perform 'index' and 'view' actions
'actions'=>array('index','view','Getitem','Getcode','Getname','ajaxcreate','nscreate'),
'users'=>array('*'),
),
array('allow', // allow authenticated user to perform 'create' and 'update' actions
'actions'=>array('create','update','Return','OutletStock'),
'users'=>array('@'),
),
array('allow', // allow admin user to perform 'admin' and 'delete' actions
'actions'=>array('admin','delete'),
'users'=>array('admin'),
),
array('deny',  // deny all users
'users'=>array('*'),
),
);
}*/

/**
* Displays a particular model.
* @param integer $id the ID of the model to be displayed
*/
public function actionGetitem(){
	
	/*echo "<pre>";
	print_r($_POST);
	echo "</pre>";
	exit;*/
	 $data=Inventoryitem::model()->findAll('category_id=:category_id', 
                  array(':category_id'=>(int) $_POST['category_id']));
    if(count($data)>0)
	{
    $data=CHtml::listData($data,'id','name');
	echo CHtml::tag('option',
                   array('value'=>''),CHtml::encode('Select an Item'),true);
    foreach($data as $value=>$name)
    {
        echo CHtml::tag('option',
                   array('value'=>$value),CHtml::encode($name),true);
    }
	}
	else
	{
		$data=Inventoryitem::model()->findAll();
	$data=CHtml::listData($data,'id','name');
	echo CHtml::tag('option',
                   array('value'=>''),CHtml::encode('Select an Item'),true);
    foreach($data as $value=>$name)
    {
        echo CHtml::tag('option',
                   array('value'=>$value),CHtml::encode($name),true);
    }	
		
	}
}
public function actionGetcode(){
	
	
	 if($_POST['st']=='store')
	 {
	  $store_stock=StoreStock::model()->find('inventoryitem_id='.(int) $_POST['id'].' AND store_id='.(int) $_POST['store_id']);
	 }
	 else
	 {
		 
		$store_stock=OutletStock::model()->find('inventoryitem_id='.(int) $_POST['id'].' AND outlet_id='.(int) $_POST['store_id'].' AND section_id='.(int) $_POST['section_id']);
		
		
	 }
	  if(count($store_stock)==0 || $store_stock->stock==0)
	  {
		  $status=0;
		  
	  }
	  else
	  {
		 $status=1;
	  }
	 $data=Inventoryitem::model()->find('id=:id', 
                  array(':id'=>(int) $_POST['id']));
				  if($store_stock->stock>0)
				  {
				  $stock=$store_stock->stock/$data->per_purchase;
                    }
					else if($store_stock->stock==0)
					{
					  $stock=0;	
					}
				  $unit=Unit::model()->findByPk($data->purchase_unit);
     $arr=array('code'=>$data->code,'last_purchase'=>$data->last_purchase,'stock'=>$stock,'status'=>$status,'unit'=>$unit->name);
	  echo CJSON::encode($arr);
    //echo $data->code;
	//exit;
}
public function actionOutletStock(){
	
	/*echo "<pre>";
	print_r($_POST);
	echo "</pre>";
	exit;*/
	  $store_stock=OutletStock::model()->find('inventoryitem_id='.(int) $_POST['id'].' AND outlet_id='.(int) $_POST['store_id']);
	  if(count($store_stock)==0 || $store_stock->stock==0)
	  {
		  $status=0;
		  
	  }
	  else
	  {
		 $status=1;
	  }
	 $data=Inventoryitem::model()->find('id=:id', 
                  array(':id'=>(int) $_POST['id']));
				  if($store_stock->stock>0)
				  {
				  $stock=$store_stock->stock/$data->per_purchase;
                    }
					else if($store_stock->stock==0)
					{
					  $stock=0;	
					}
				  $unit=Unit::model()->findByPk($data->purchase_unit);
     $arr=array('code'=>$data->code,'last_purchase'=>$data->last_purchase,'stock'=>$stock,'status'=>$status,'unit'=>$unit->name);
	  echo CJSON::encode($arr);
    //echo $data->code;
	//exit;
}

public function actionGetname(){
	
	/*echo "<pre>";
	print_r($_POST);
	echo "</pre>";
	exit;*/
	 $data=Inventoryitem::model()->find('code=:code', 
                  array(':code'=>$_POST['code']));
				  
 if(count($data)>0){
	 
    $category=Category::model()->findByPk($data->category_id);
	$arr=array('category_id'=>$category->id,'inventoryitem_id'=>$data->id,'last_purchase'=>$data->last_purchase,'purchase_unit'=>$data->unit->id);
    echo CJSON::encode($arr);

 }
	else 
	echo "Not Found";
	//exit;
}
public function actionView($id)
{
		$model = $this->loadModel($id);
		
		if( Yii::app()->request->isAjaxRequest )
		  {
			// Stop jQuery from re-initialization
			Yii::app()->clientScript->scriptMap['jquery.js'] = false;
		 	echo CJSON::encode( array(
			  'status' => 'failure',
			  'content' => $this->renderPartial( 'view', array('model' => $model ), true, true ),));
			exit;
		  }
		  else
			$this->render( 'view', array( 'model' => $model ) );
	  
	  
}

/**
* Creates a new model.
* If creation is successful, the browser will be redirected to the 'view' page.
*/
public function actionajaxcreate()
        {       
                $model=new Storein;             
                $this->performAjaxValidation($model);  
                
                if(isset($_POST['Storein']))
                {
                        $model->attributes=$_POST['Storein'];
                        $valid=$model->validate();            
                        if($valid){
                             $model->save();             
                           //do anything here
                             echo CJSON::encode(array(
                                  'status'=>'success'
                             ));
                            Yii::app()->end();
                            }
                            else{
                                $error = CActiveForm::validate($model);
                                if($error!='[]')
                                    echo $error;
                                Yii::app()->end();
                            }
               }
     
        }



public function actionCreate($id)
{
$purchase_requisition=PurchaseRequisition::model()->findByPk($id);
$model=new Storein('in');
$grid=new Storein('storesearch');
$grid->unsetAttributes();  // clear any default values
if(isset($_GET['Storein']))
$grid->attributes=$_GET['Storein'];
$prid=$purchase_requisition->id;
//$grid->pr_id=$purchase_requisition->id;
//$storein=new Storein;
//$storein->pr_id=$purchase_requisition->id;
// Uncomment the following line if AJAX validation is needed

//$this->performAjaxValidation($model);

if(isset($_POST['Storein']))
{
	/*echo "<pre>";
	print_r($_POST['Storein']);
	echo "</pre>";
	exit;*/
	$check=Storein::model()->find('inventoryitem_id=:inventoryitem_id AND store_id=:store_id AND pr_id=:pr_id',array(':inventoryitem_id'=>$_POST['Storein']['inventoryitem_id'],':store_id'=>$_POST['Storein']['store_id'],':pr_id'=>$_POST['Storein']['pr_id']));
	if(count($check)>0)
	{
		$model->attributes=$_POST['Storein'];
		$model->category=$_POST['Storein']['category'];
		$model->code=$_POST['Storein']['code'];
		$model->discount_per=$_POST['Storein']['discount_per'];
		$model->sales_tax_per=$_POST['Storein']['sales_tax_per'];
		$model->purchase_total=$_POST['Storein']['purchase_total'];
		$model->net_purchase_rate=$_POST['Storein']['net_purchase_rate'];
		$model->sales_total=$_POST['Storein']['sales_total'];
		$model->discount=$_POST['Storein']['discount'];
		//$model=$this->loadModel($_POST['Storein']['id']);
		//$model->quantity=($model->quantity)+($_POST['Storein']['quantity']);
		$model->addError('inventoryitem_id',$check->inventoryitem->name.' Already Added');
		
	}
	else
	{
        $model->attributes=$_POST['Storein'];
//$model->attributes=$_POST['Storein'];
		/*$model->category=$_POST['Storein']['category'];
		$model->code=$_POST['Storein']['code'];
		$model->discount_per=$_POST['Storein']['discount_per'];
		$model->sales_tax_per=$_POST['Storein']['sales_tax_per'];
		$model->purchase_total=$_POST['Storein']['purchase_total'];
		$model->net_purchase_rate=$_POST['Storein']['net_purchase_rate'];
		$model->sales_total=$_POST['Storein']['sales_total'];*/
		$model->discount=$_POST['Storein']['discount'];
        if($model->save()){
	
	    $inventoryitem=Inventoryitem::model()->findByPk($model->inventoryitem_id);
		
		  if(count($inventoryitem)>0)
		   {
			$inventoryitem->last_purchase=$model->purchrate;
			$inventoryitem->save();
			
		   }
	    /////////////////////store stock ////////////////////////////
	
	    $store_stock=StoreStock::model()->find('inventoryitem_id=:inventoryitem_id AND          store_id=:store_id',array(':inventoryitem_id'=>
	   $model->inventoryitem_id,':store_id'=>$model->store_id));
	   if(count($store_stock)>0)
	   {
		$item_info=Inventoryitem::model()->findByPk($model->inventoryitem_id);
		$stock=$item_info->per_purchase*$model->quantity;
		$store_stock->stock=$store_stock->stock+$stock;
		$store_stock->save();	
	    }
	   else
	  {
		  
	   $store_stock=new StoreStock;
	   
	   $store_stock->inventoryitem_id=$model->inventoryitem_id;
	   $store_stock->store_id=$model->store_id;
	   $item_info=Inventoryitem::model()->findByPk($model->inventoryitem_id);
		$stock=$item_info->per_purchase*$model->quantity;
		$store_stock->stock=$stock;
	   //$store_stock->stock=$model->quantity;
	   $store_stock->save();	
	   }
/////////////////// store stock end /////////////////


	if( Yii::app()->request->isAjaxRequest )
		  {
			// Stop jQuery from re-initialization
			Yii::app()->clientScript->scriptMap['jquery.js'] = false;
	 
	 		$json_arr = array(
			  'status' => 'success',
			  'grid' => 'categories-grid',
			  'url' => $_SERVER['REQUEST_URI'],
			  'content' => 'Categories successfully Created',
			);
			if(isset($_GET['dropDownList'])){
			$json_arr['inputType']='dropDownList';
			$json_arr['inputId']=$_GET['dropDownList'];
			$json_arr['inputData']=CHtml::tag('option',array('value'=>$model->id,'selected'=>true),CHtml::encode($model->name),true);
			}
			echo CJSON::encode($json_arr);
			exit;
		  }else{
          	Yii::app()->user->setFlash('success','Storein successfully created.');	
			$this->redirect( array( 'storein/create', 'id' => $model->pr_id ) );
		  }
}//end model save
	}
}//end post

				if( Yii::app()->request->isAjaxRequest ){
					// Stop jQuery from re-initialization
					Yii::app()->clientScript->scriptMap['jquery.js'] = false;
				 	echo CJSON::encode( array(
					  'status' => 'failure',
					  'url' => $_SERVER['REQUEST_URI'],
					  'content' => $this->renderPartial( '_form', array(
					  'model' => $model), true, true ),
					));
					exit;
				  }else{
					$this->render( 'create', array( 'model' => $model,'purchase_requisition'=>$purchase_requisition,'grid'=>$grid,'prid'=>$prid) );
				  }
}//end function

/////////////create storein for no store scenario //////////


public function actionnscreate($id)
{
$purchase_requisition=PurchaseRequisition::model()->findByPk($id);
$model=new Storein('nscreate');
$grid=new Storein('storesearch');
$grid->unsetAttributes();  // clear any default values
if(isset($_GET['Storein']))
$grid->attributes=$_GET['Storein'];
$prid=$purchase_requisition->id;
//$grid->pr_id=$purchase_requisition->id;
//$storein=new Storein;
//$storein->pr_id=$purchase_requisition->id;
// Uncomment the following line if AJAX validation is needed

//$this->performAjaxValidation($model);

if(isset($_POST['Storein']))
{
	/*echo "<pre>";
	print_r($_POST['Storein']);
	echo "</pre>";
	exit;*/
	$check=Storein::model()->find('inventoryitem_id=:inventoryitem_id AND store_id=:store_id AND pr_id=:pr_id',array(':inventoryitem_id'=>$_POST['Storein']['inventoryitem_id'],':store_id'=>$_POST['Storein']['store_id'],':pr_id'=>$_POST['Storein']['pr_id']));
	
	if(count($check)>0)
	{
		
		$model->attributes=$_POST['Storein'];
		$model->section_id=$_POST['Storein']['section_id'];
		$model->category=$_POST['Storein']['category'];
		$model->code=$_POST['Storein']['code'];
		$model->discount_per=$_POST['Storein']['discount_per'];
		$model->sales_tax_per=$_POST['Storein']['sales_tax_per'];
		$model->purchase_total=$_POST['Storein']['purchase_total'];
		$model->net_purchase_rate=$_POST['Storein']['net_purchase_rate'];
		$model->sales_total=$_POST['Storein']['sales_total'];
		$model->discount=$_POST['Storein']['discount'];
		//$model=$this->loadModel($_POST['Storein']['id']);
		//$model->quantity=($model->quantity)+($_POST['Storein']['quantity']);
	    $model->addError('inventoryitem_id',$check->inventoryitem->name.' Already Added');
		
	}
	else
	{
        $model->attributes=$_POST['Storein'];
		$model->section_id=$_POST['Storein']['section_id'];
//$model->attributes=$_POST['Storein'];
		/*$model->category=$_POST['Storein']['category'];
		$model->code=$_POST['Storein']['code'];
		$model->discount_per=$_POST['Storein']['discount_per'];
		$model->sales_tax_per=$_POST['Storein']['sales_tax_per'];
		$model->purchase_total=$_POST['Storein']['purchase_total'];
		$model->net_purchase_rate=$_POST['Storein']['net_purchase_rate'];
		$model->sales_total=$_POST['Storein']['sales_total'];*/
		$model->discount=$_POST['Storein']['discount'];
        if($model->save()){
	
	    $inventoryitem=Inventoryitem::model()->findByPk($model->inventoryitem_id);
		
		  if(count($inventoryitem)>0)
		   {
			$inventoryitem->last_purchase=$model->purchrate;
			$inventoryitem->save();
			
		   }
	    /////////////////////store stock ////////////////////////////
	
	    $store_stock=StoreStock::model()->find('inventoryitem_id=:inventoryitem_id AND          store_id=:store_id',array(':inventoryitem_id'=>
	   $model->inventoryitem_id,':store_id'=>$model->store_id));
	   if(count($store_stock)>0)
	   {
		$item_info=Inventoryitem::model()->findByPk($model->inventoryitem_id);
		$stock=$item_info->per_purchase*$model->quantity;
		$store_stock->stock=$store_stock->stock+$stock;
		 if($store_stock->save())
		   {
			   $flag=true;
		   }
	    }
	   else
	  {
	   $store_stock=new StoreStock;
	   $store_stock->inventoryitem_id=$model->inventoryitem_id;
	   $store_stock->store_id=$model->store_id;
	  $item_info=Inventoryitem::model()->findByPk($model->inventoryitem_id);
		$stock=$item_info->per_purchase*$model->quantity;
		$store_stock->stock=$stock;
	  /* echo $store_stock->stock;
	   exit;*/
	     if($store_stock->save())
		   {
			   $flag=true;
		   }
		 //  echo $store_stock->stock;
		 //  exit;
	   /////////////////// store stock end /////////////////	
	   }
	    
      if($flag==true)
	  {		
       /////////////////// stock transfer start /////////////////
	   //'transfer_date, enter_date, s_t_no, store_id, enter_by, transfer_type, outlet_id
       $stock_transfer                = new StockTransfer('nostore');
	   $stock_transfer->s_t_no        = 0000;
	   $stock_transfer->transfer_date = $purchase_requisition->requisition_date;
	   $stock_transfer->enter_date    = date('Y-m-d H:i:s');
	   $stock_transfer->store_id      = $model->store_id;
	   $stock_transfer->enter_by      = Yii::app()->user->id;
	   $stock_transfer->outlet_id     = $model->outlet_id;
	   $stock_transfer->transfer_type = 2;
	   $stock_transfer->section_id    = $model->section_id;
	   $stock_transfer->storein_id    = $model->id;
	    
		if($stock_transfer->save())
		
        ////////////////// stock transfer end ////////////////////	   
		{
			
           ////////////// Store out start //////////
		   $store_out=new Storeout('transfer');
		   //quantity, inventoryitem_id,  store_id, enter_by, stock_transfer_id, outlet_id
		   $store_out->quantity=$model->quantity;
		   $store_out->inventoryitem_id=$model->inventoryitem_id;
		   $store_out->store_id=$model->store_id;
		   $store_out->enter_by=Yii::app()->user->id;
		   $store_out->stock_transfer_id=$stock_transfer->id;
		   $store_out->outlet_id=$model->outlet_id;
		   $store_out->section_id=$model->section_id;
		   if($store_out->save())
		   ///////////// store out end ////////////
		   {
			   
			       //////////////////outletin start ///////////////////
 
                  $outletin=new Outletin;
			      $outletin->outlet_id=$model->outlet_id;
				  $outletin->section_id=$model->section_id;
			      $outletin->inventoryitem_id=$model->inventoryitem_id;
			      $outletin->doi=date('Y-m-d H:i:s');
			      $outletin->quantity=$model->quantity;
			      $outletin->store_id=$model->store_id;
			      $outletin->stock_transfer_id=$stock_transfer->id;
			      //$outletin->remarks='';
			      $outletin->enter_by=Yii::app()->user->id;
			      //$outletin->stock_transfer_id=$model->stock_transfer_id;
			      if($outletin->save()){
				
				       $outlet_stock=OutletStock::model()->find( 
					   'inventoryitem_id=:inventoryitem_id AND        
					   outlet_id=:outlet_id AND section_id=:section_id',array(':inventoryitem_id'=>
	                   $outletin->inventoryitem_id,':outlet_id'=>$outletin->outlet_id,':section_id'=>$model->section_id));
	                    if(count($outlet_stock)>0)
			             {
				           $item_info=Inventoryitem::model()->findByPk($outletin->inventoryitem_id);
						   $stock=$outletin->quantity*$item_info->per_purchase;
				          $outlet_stock->stock=$outlet_stock->stock+$stock;
				          $outlet_stock->save();
			             }
			 
			            else
			            {
							$item_info=Inventoryitem::model()->findByPk($outletin->inventoryitem_id);
						   $stock=$outletin->quantity*$item_info->per_purchase;
				         $outlet_stock=new OutletStock;
				         $outlet_stock->inventoryitem_id=$outletin->inventoryitem_id;
				         $outlet_stock->outlet_id=$outletin->outlet_id;
						 $outlet_stock->section_id=$model->section_id;
				         $outlet_stock->stock=$stock;
				         $outlet_stock->save();  
				 
			            }
			      }
 
                else
		         {
			          echo "<pre>";
			          print_r($outletin->getErrors()) ;
			          echo "</pre>";
			          exit;  
			     
		         }
             ////////////////outletin end ///////////////////////
			   
		   }/////// stocktransfer if ends here 
		   else
		   {
			   
			   echo "<pre>";
			          print_r($store_out->getErrors()) ;
			          echo "</pre>";
			          exit;
			   
		   }
		   
		}//////// storein save end ////////


 

       
	if( Yii::app()->request->isAjaxRequest )
		  {
			// Stop jQuery from re-initialization
			Yii::app()->clientScript->scriptMap['jquery.js'] = false;
	 
	 		$json_arr = array(
			  'status' => 'success',
			  'grid' => 'categories-grid',
			  'url' => $_SERVER['REQUEST_URI'],
			  'content' => 'Categories successfully Created',
			);
			if(isset($_GET['dropDownList'])){
			$json_arr['inputType']='dropDownList';
			$json_arr['inputId']=$_GET['dropDownList'];
			$json_arr['inputData']=CHtml::tag('option',array('value'=>$model->id,'selected'=>true),CHtml::encode($model->name),true);
			}
			echo CJSON::encode($json_arr);
			exit;
		  }else{
          	Yii::app()->user->setFlash('success','Storein successfully created.');	
			$this->redirect( array( 'storein/nscreate', 'id' => $model->pr_id ) );
		  }
	  }
}//end model save
	}
}//end post

				if( Yii::app()->request->isAjaxRequest ){
					// Stop jQuery from re-initialization
					Yii::app()->clientScript->scriptMap['jquery.js'] = false;
				 	echo CJSON::encode( array(
					  'status' => 'failure',
					  'url' => $_SERVER['REQUEST_URI'],
					  'content' => $this->renderPartial( '_form', array(
					  'model' => $model), true, true ),
					));
					exit;
				  }else{
					$this->render( 'nscreate', array( 'model' => $model,'purchase_requisition'=>$purchase_requisition,'grid'=>$grid,'prid'=>$prid) );
				  }
}//end function


///////////end of storein for no store scenario //////////


/**
* Updates a particular model.
* If update is successful, the browser will be redirected to the 'view' page.
* @param integer $id the ID of the model to be updated
*/
////////// action for reciving stock from store start ///////
public function actionReturn($id){
	$model=new Storein('returnstore');
	$grid=new Storein;
$stock_transfer=StockTransfer::model()->findByPk($id);
$stock_transfer->scenario = 'returnstore';
if(isset($_POST['Storein']))
{
	/*echo "<pre>";
	print_r($_POST['Storein']);
	echo "</pre>";
	exit;*/
	$model->attributes=$_POST['Storein'];
	$model->store_id=$_POST['Storein']['store_id'];
	$model->outlet_id=$_POST['Storein']['outlet_id'];
	$model->section_id=$_POST['Storein']['section_id'];
	$model->stocktransfer_id=$_POST['Storein']['stocktransfer_id'];
	if($model->save())
	{
		$outlet_stock=OutletStock::model()->find('inventoryitem_id='.$model->inventoryitem_id.' AND section_id='.$model->section_id.' AND outlet_id='.$model->outlet_id);
		if(count($outlet_stock)>0 && $outlet_stock->stock>0)
		{
			$item_info=Inventoryitem::model()->findByPK($model->inventoryitem_id);
	
			$outlet_stock->stock=$outlet_stock->stock-(($model->quantity)*($item_info->per_purchase));
			if($outlet_stock->save())
			{
				$store_stock=StoreStock::model()->find('inventoryitem_id='.$model->inventoryitem_id.' AND store_id='.$model->store_id);
				$store_stock->stock=$store_stock->stock+($model->quantity*$item_info->per_purchase);
				$store_stock->save();
				
			}
		}
	}
	else
	{
		print_r($model->getErrors());
		
	}
	 echo "<pre>";
	print_r($model->attributes);
	echo "</pre>";
	exit;
}
$this->render( 'return', array( 'model' => $model,'stock_transfer'=>$stock_transfer) );
}
////////// action for reciving stock from store end ///////
public function actionUpdate($id)
{
$model=$this->loadModel($id);

// Uncomment the following line if AJAX validation is needed
$this->performAjaxValidation($model);

if(isset($_POST['Storein']))
{
$model->attributes=$_POST['Storein'];
	
	if($model->save()){
		
		if( Yii::app()->request->isAjaxRequest ){
			// Stop jQuery from re-initialization
			Yii::app()->clientScript->scriptMap['jquery.js'] = false;
	 		echo CJSON::encode( array(
			  'status' => 'success',
			  'url' => $_SERVER['REQUEST_URI'],
			  'grid' => 'asset-grid',//grid to update
			  'content' => 'Storein successfully Updated',
			));
		exit;
		}else{
		Yii::app()->user->setFlash('success','Storein successfully Updated');	
		$this->redirect(array('view','id'=>$model->id));
		}
	}//end if model save
}//end if POST


				if( Yii::app()->request->isAjaxRequest ){
					// Stop jQuery from re-initialization
					Yii::app()->clientScript->scriptMap['jquery.js'] = false;
				 	echo CJSON::encode( array(
					  'status' => 'failure',
					  'url' => $_SERVER['REQUEST_URI'],
					  'content' => $this->renderPartial( '_form', array(
					  'model' => $model), true, true ),
					));
					exit;
				  }else{
					$this->render( 'update', array( 'model' => $model) );
				  }

}//end function
/**
* Deletes a particular model.
* If deletion is successful, the browser will be redirected to the 'admin' page.
* @param integer $id the ID of the model to be deleted
*/
public function actionDelete($id)
{
	$storein=Storein::model()->findByPk($id);
	$stock_transfer=StockTransfer::model()->find('storein_id='.$id);
	$outlet_id=$stock_transfer->outlet_id;
	$section_id=$storein->section_id;
	$inventoryitem_id=$storein->inventoryitem_id;
	$store_id=$storein->store_id;
	$quantity=$storein->quantity;
	$setting=SystemSettings::model()->find();
	if($setting->store==1)
	{
	$system_type="store";
	}
	else
	{
	$system_type="nostore";
	}
if(Yii::app()->request->isPostRequest)
{
// we only allow deletion via POST request
if($this->loadModel($id)->delete())
{
	$store_stock=StoreStock::model()->find('inventoryitem_id=:inventoryitem_id AND store_id=:store_id',array(':inventoryitem_id'=>$inventoryitem_id,':store_id'=>$store_id));
	if(count($store_stock)>0 && $system_type=="store")
	{
	   $item_info=Inventoryitem::model()->findByPk($inventoryitem_id);
			  
						   $stock=$quantity*$item_info->per_purchase;
		$store_stock->stock=$store_stock->stock-$stock;
		$store_stock->save();
	}
	else if(count($store_stock)>0 && $system_type=="nostore")
	{
		//$store_stock->stock=$store_stock->stock-$quantity;
		
		 	$outlet_stock=OutletStock::model()->find('inventoryitem_id=:inventoryitem_id AND outlet_id=:outlet_id AND section_id=:section_id',array(':inventoryitem_id'=>$inventoryitem_id,':outlet_id'=>$outlet_id,':section_id'=>$section_id));
			if(count($outlet_stock)>0)
		      { 
			  $item_info=Inventoryitem::model()->findByPk($inventoryitem_id);
			  
						   $stock=$quantity*$item_info->per_purchase;
		//$store_stock->stock=$outlet_stock->stock-$stock;
			  $outlet_stock->stock=$outlet_stock->stock-$stock;
			  $outlet_stock->save();
			  }
		
		
	}
}

// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
if(!isset($_GET['ajax']))
$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
}
else
throw new CHttpException(400,'Invalid request. Please do not repeat this request again.');
}

/**
* Lists all models.
*/
public function actionReturnStoreDel($id){
	$storein=$this->loadModel($id);
	$item=Inventoryitem::model()->findByPk($storein->inventoryitem_id);
	$outlet=Outlet::model()->findByPk($storein->outlet_id);
	$store=Store::model()->findByPk($storein->store_id);
	$store_stock=StoreStock::model()->find('store_id='.$store->id.' AND inventoryitem_id='.$item->id);
	//$outlet_stock=OutletStock::
	if(Yii::app()->request->isPostRequest)
    {
// we only allow deletion via POST request
      if($this->loadModel($id)->delete())
      {
	
      }
}
	
}
public function actionIndex()
{
$this->actionAdmin();
exit;
$dataProvider=new CActiveDataProvider('Storein');
$this->render('index',array(
'dataProvider'=>$dataProvider,
));
}

/**
* Manages all models.
*/
public function actionAdmin()
{
$model=new Storein('search');
$model->unsetAttributes();  // clear any default values
if(isset($_GET['Storein']))
$model->attributes=$_GET['Storein'];

$this->render('admin',array(
'model'=>$model,
));
}

/**
* Returns the data model based on the primary key given in the GET variable.
* If the data model is not found, an HTTP exception will be raised.
* @param integer the ID of the model to be loaded
*/
public function loadModel($id)
{
$model=Storein::model()->findByPk($id);
if($model===null)
throw new CHttpException(404,'The requested page does not exist.');
return $model;
}

/**
* Performs the AJAX validation.
* @param CModel the model to be validated
*/
protected function performAjaxValidation($model)
{
if(isset($_POST['ajax']) && $_POST['ajax']==='storein-form')
{
echo CActiveForm::validate($model);
Yii::app()->end();
}
}
}
