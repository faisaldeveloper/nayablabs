<?php
$this->breadcrumbs=array(
	'Outlet Stocks'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List OutletStock','url'=>array('index')),
array('label'=>'Manage OutletStock','url'=>array('admin')),
);
?>

<h1>Create OutletStock</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>