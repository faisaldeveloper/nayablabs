<?php
$this->breadcrumbs=array(
	'Outlet Stocks'=>array('index'),
	$model->id,
);

$this->menu=array(
array('label'=>'List OutletStock','url'=>array('index')),
array('label'=>'Create OutletStock','url'=>array('create')),
array('label'=>'Update OutletStock','url'=>array('update','id'=>$model->id)),
array('label'=>'Delete OutletStock','url'=>'#','linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
array('label'=>'Manage OutletStock','url'=>array('admin')),
);
?>

<h1>View OutletStock #<?php echo $model->id; ?></h1>

<?php $this->widget('bootstrap.widgets.TbDetailView',array(
'data'=>$model,
'attributes'=>array(
		'id',
		'inventoryitem_id',
		'outlet_id',
		'stock',
),
)); ?>
