<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Track Outlet Stock:',
    )
    );

?>
</div>
<?php
$this->breadcrumbs=array(
	'Outlet Stocks'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List OutletStock','url'=>array('index')),
array('label'=>'Create OutletStock','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('outlet-stock-grid', {
data: $(this).serialize()
});
return false;
});
");
?>



<?php // echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:block">
	<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php Yii::app()->clientScript->registerScript('someScript', "
$('#report').submit(function() {
    alert('testing');
	
	$('#outlet').text($('#OutletStock_outlet_id :selected').text());
	$('#section').text($('#OutletStock_section_id :selected').text());
	$('#item').text($('#OutletStock_inventoryitem_id :selected').text());
	
	
});
");
?>

<div id="print" style="display:none;">
<table id='daterange'>
<tr>
<td><label>Outlet:</label></td><td><label id='outlet'></label></td><td><label>Section:</label></td><td><label id='section'></label></td><td><label>Item:</label></td><td><label id='item'></label></td>
</tr>
</table>
<div id="all" style="display:none;">All Recorded Sale</div>
</div>

<?php 
$setting=SystemSettings::model()->find();
if(count($setting)>0 && $setting->store==1)
$outlet=true;
else if(count($setting)>0 && $setting->store==2)
$outlet=false;

?>
<?php $this->widget('ext.groupgridview.BootGroupGridView',array(
'id'=>'outlet-stock-grid',
'type'=>'bordered',
'dataProvider'=>$model->search(),
'mergeColumns' => array('outlet_id' , 'section_id'),
//'filter'=>$model,
'columns'=>array(
		//'id',
		//'inventoryitem_id',
		//'outlet_id',
		array('header'=>'Outlet','name'=>'outlet_id','value'=>'$data->outlet->name','visible'=>$outlet),
		array('header'=>'Section','name'=>'section_id','value'=>'$data->section->name'),
		array('header'=>'Item','name'=>'inventoryitem_id','value'=>'$data->inventoryitem->name'),       array('header'=>'Stock','name'=>'stock','value'=>'OutletStock::model()->currentstock($data->id)'),
		//'stock',
/*array(
'class'=>'bootstrap.widgets.TbButtonColumn',
),*/
),
)); ?>
