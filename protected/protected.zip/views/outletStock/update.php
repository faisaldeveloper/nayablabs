<?php
$this->breadcrumbs=array(
	'Outlet Stocks'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List OutletStock','url'=>array('index')),
	array('label'=>'Create OutletStock','url'=>array('create')),
	array('label'=>'View OutletStock','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage OutletStock','url'=>array('admin')),
	);
	?>

	<h1>Update OutletStock <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form',array('model'=>$model)); ?>