<div class="view">

		<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id),array('view','id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('inventoryitem_id')); ?>:</b>
	<?php echo CHtml::encode($data->inventoryitem_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('outlet_id')); ?>:</b>
	<?php echo CHtml::encode($data->outlet_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('stock')); ?>:</b>
	<?php echo CHtml::encode($data->stock); ?>
	<br />


</div>