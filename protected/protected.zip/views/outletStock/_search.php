<?php

if(Yii::app()->user->hasState('outlet'))
{
	$outlet_id=Yii::app()->user->getState('outlet');
	

}
if(Yii::app()->user->hasState('section'))
{
	$section_id=Yii::app()->user->getState('section');
	

}
?>
<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
'id'=>"report",
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

		<?php //echo $form->textFieldRow($model,'id',array('class'=>'span5')); ?>

		<?php //echo $form->textFieldRow($model,'inventoryitem_id',array('class'=>'span5')); ?>

		<?php //echo $form->textFieldRow($model,'outlet_id',array('class'=>'span5')); ?>

		<?php //echo $form->textFieldRow($model,'stock',array('class'=>'span5')); ?>

	<div style="float:left; padding-right:10px">
     <?php if($outlet_id==''){ ?>
    <?php echo $form->dropDownListRow($model,'outlet_id',CHtml::listData(Outlet::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Select Outlet:','ajax' => array(
'type'=>'POST', //request type
'url'=>CController::createUrl('outlet/Getsections'), //url to call.
//Style: CController::createUrl('currentController/methodToCall')
'update'=>'#OutletStock_section_id', //selector to update
'data'=>array('outlet_id'=>'js:this.value')
//leave out the data key to pass all form values through
))); 
}
		else
		{
			echo $form->hiddenField($model,'outlet_id',array('value'=>$outlet_id));
		}
?>
    </div>
        <div style="float:left; padding-right:10px">
        <?php if($section_id==''){ ?>
        <?php echo $form->dropDownListRow($model,'section_id',CHtml::listData(Section::model()->findAll(),'id','name'),array('class'=>'span3','prompt'=>'Select section:')); 
		}
		else
		{
			echo $form->hiddenField($model,'section_id',array('value'=>$section_id));
		}

		?>
        </div>
         <div style="float:left; padding-right:10px">
        <?php echo $form->dropDownListRow($model,'inventoryitem_id',CHtml::listData(Inventoryitem::model()->findAll(),'id','name'),array('class'=>'span3','prompt'=>'Select Item:')); ?>
        </div>
		<?php //echo $form->textFieldRow($model,'stock',array('class'=>'span5')); ?>

	<div style="float:left; margin-top:25px">
		<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType' => 'submit',
			'type'=>'inverse',
			'label'=>'Search',
		)); ?>
	</div>
<div style="clear:both;"></div>

<?php $this->endWidget(); ?>
