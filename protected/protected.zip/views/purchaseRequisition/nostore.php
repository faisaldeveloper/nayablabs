<?php
$this->breadcrumbs=array(
	'Purchase Requisitions'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List PurchaseRequisition','url'=>array('index')),
array('label'=>'Manage PurchaseRequisition','url'=>array('admin')),
);
?>

<!--<h1>Create PurchaseRequisition</h1>-->
<fieldset>
<legend>
<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Create Purchase Requisition:',
    )
    );

?>
</div></legend>
<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'purchase-requisition-form',
	//'type'=>'form-horizontal',
	'enableAjaxValidation'=>false,
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($model); ?>

	<?php // echo $form->textFieldRow($model,'requisition_date',array('class'=>'span5')); ?>


    
	<?php echo $form->hiddenField($model,'enter_date',array('class'=>'span5','value'=>date('Y-m-d H:i:s'))); ?>
     <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'p_r_no',array('class'=>'span2','maxlength'=>20)); ?>
    </div>
    <div style="float:left; padding-right:10px">
    <?php echo $form->textFieldRow($model,'p_o_no',array('class'=>'span2','maxlength'=>20)); ?>
     </div>
     
      <div style="float:left; padding-right:10px">
    <?php echo $form->datepickerRow(
      $model,
      'requisition_date',
     array(
    'options' => array('language' => 'es','width'=>'100px','format'=>'yyyy-mm-dd'),
    //'hint' => 'Click inside! This is a super cool date field.',
    'prepend' => '<i class="icon-calendar"></i>'
    )
    ); ?>
     </div>
     <div style="clear:both;"></div>
     <div style="float:left; padding-right:10px">
     
     <?php echo $form->dropDownListRow($model,'supplier_id',CHtml::listData(Supplier::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Supplier:')); ?>
     </div>
     <div style="float:left; padding-right:10px">
     <?php //echo $form->dropDownListRow($model,'store_id',CHtml::listData(Store::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Store:')); ?>
     </div>
    <?php $store=Store::model()->find(); ?>
	<?php echo $form->hiddenField($model,'store_id',array('class'=>'span5','value'=>$store->id)); ?>
    
    
	<?php //echo $form->textFieldRow($model,'store_id',array('class'=>'span5')); ?>
   
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'l_s_discount',array('class'=>'span2')); ?>
   </div>
    <div style="float:left; padding-right:10px">
    <?php echo $form->textFieldRow($model,'tax_overload',array('class'=>'span2')); ?>
    </div>
    <div style="clear:both;"></div>
   
    <div style="float:left; padding-right:10px">
	<?php echo $form->textAreaRow($model,'remarks',array('class'=>'span8','maxlength'=>300)); ?>
    </div>
    <div style="clear:both;"></div>
	
   
	<?php echo $form->hiddenField($model,'enter_by',array('class'=>'span3','value'=>1)); ?>

	
<div class="form-actions">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$model->isNewRecord ? 'Next' : 'Save',
		)); ?>
        <?php $this->widget('bootstrap.widgets.TbButton', array(
                        'buttonType'=>'reset',
                        'type'=>'inverse',
                        'label'=>'Reset',
                )); ?>
</div>

<?php $this->endWidget(); ?>
</fieldset>