<?php
$this->breadcrumbs=array(
	'Purchase Requisitions'=>array('index'),
	'Create',
);

$this->menu=array(
//array('label'=>'List PurchaseRequisition','url'=>array('index')),
array('label'=>'Manage PurchaseRequisition','url'=>array('admin')),
);
?>

<!--<h1>Create PurchaseRequisition</h1>-->
<fieldset>
<legend>
<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Create Purchase Requisition:',
    )
    );

?>
</div></legend>
<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>


</fieldset>

