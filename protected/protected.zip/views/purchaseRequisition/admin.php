<?php
$this->breadcrumbs=array(
	'Purchase Requisitions'=>array('index'),
	'Manage',
);

$this->menu=array(
//array('label'=>'List PurchaseRequisition','url'=>array('index')),
array('label'=>'Create PurchaseRequisition','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('purchase-requisition-grid', {
data: $(this).serialize()
});
return false;
});
");
?>

<h1></h1>
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Manage/search Purchase Requisitions:',
    )
    );

?>
<?php 
$setting=SystemSettings::model()->find();
if(count($setting)>0 && $setting->store==1)
{
$action="Storein/create";
$store=true;
}
else if(count($setting)>0 && $setting->store==2)
{
$action="Storein/nscreate";
$store=false;
}
?>

<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:block">
	<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php $this->widget('bootstrap.widgets.TbGridView',array(
'id'=>'purchase-requisition-grid',
'type'=>'bordered',
'dataProvider'=>$model->search(),
//'filter'=>$model,
'columns'=>array(
		'id',
		'requisition_date',
		'enter_date',
		'p_r_no',
		array('header'=>'Supplier','name'=>'supplier_id', 'value'=>'$data->supplier->name'),
		array('header'=>'Store','name'=>'store_id', 'value'=>'$data->store->name','visible'=>$store
		),
		array
(
    'class'=>'CButtonColumn',
    'template'=>'{email}',
    'buttons'=>array
    (
        'email' => array
        (
		     'header'=>'Detail',
            'label'=>'Update/Detail Purchase Requisition',
            'imageUrl'=>Yii::app()->request->baseUrl.'/images/detail2.png',
            'url'=>'Yii::app()->createUrl("'.$action.'", array("id"=>$data->id))',
        ),
        
    ),
),
		//'supplier_id',
		//'store_id',
		/*
		'l_s_discount',
		'remarks',
		'enter_by',
		'tax_overload',
		'p_o_no',
		*/
/*array(
'class'=>'bootstrap.widgets.TbButtonColumn',
),*/
),
)); ?>
