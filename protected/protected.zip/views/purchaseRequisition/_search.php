
<?php
if(Yii::app()->user->hasState('store'))
{
	$store_id=Yii::app()->user->getState('store');
	

}
?>
<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

		<?php //echo $form->textFieldRow($model,'id',array('class'=>'span5')); ?>

		<?php //echo $form->textFieldRow($model,'requisition_date',array('class'=>'span5')); ?>
        <div style="float:left; padding-right:10px">
    <?php echo $form->datepickerRow(
      $model,
      'requisition_date',
     array(
    'options' => array('language' => 'es','width'=>'100px','format'=>'yyyy-mm-dd'),
    //'hint' => 'Click inside! This is a super cool date field.',
    'prepend' => '<i class="icon-calendar"></i>'
    )
    ); ?>
     </div>
		<?php //echo $form->textFieldRow($model,'enter_date',array('class'=>'span5')); ?>
      <div style="float:left; padding-right:10px">
    <?php echo $form->datepickerRow(
      $model,
      'enter_date',
     array(
    'options' => array('language' => 'es','width'=>'100px','format'=>'yyyy-mm-dd'),
    //'hint' => 'Click inside! This is a super cool date field.',
    'prepend' => '<i class="icon-calendar"></i>'
    )
    ); ?>
     </div>
     <div style="clear:both;"></div>
     <div style="float:left; padding-right:10px">
		<?php echo $form->textFieldRow($model,'p_r_no',array('class'=>'span2','maxlength'=>20)); ?>
     </div>
		<?php //echo $form->textFieldRow($model,'supplier_id',array('class'=>'span5')); ?>
     <div style="float:left; padding-right:10px">
     
     <?php echo $form->dropDownListRow($model,'supplier_id',CHtml::listData(Supplier::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Supplier:')); ?>
     </div>
		<?php //echo $form->textFieldRow($model,'store_id',array('class'=>'span5')); ?>
     <div style="float:left; padding-right:10px">
      <?php if($store_id==''){ ?>
     <?php echo $form->dropDownListRow($model,'store_id',CHtml::listData(Store::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Store:')); 
	 }
		else
		{
			echo $form->hiddenField($model,'store_id',array('value'=>$store_id));
		}
	 ?>
     </div>
		<?php //echo $form->textFieldRow($model,'l_s_discount',array('class'=>'span5')); ?>

		<?php //echo $form->textFieldRow($model,'remarks',array('class'=>'span5','maxlength'=>300)); ?>

		<?php //echo $form->textFieldRow($model,'enter_by',array('class'=>'span5')); ?>

		<?php //echo $form->textFieldRow($model,'tax_overload',array('class'=>'span5')); ?>

		<?php //echo $form->textFieldRow($model,'p_o_no',array('class'=>'span5','maxlength'=>20)); ?>
	<div style="float:left; padding-right:10px; margin-top:25px">
		<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType' => 'submit',
			'type'=>'inverse',
			'label'=>'Search',
		)); ?>
	</div>
<div style="clear:both;"></div>

<?php $this->endWidget(); ?>
