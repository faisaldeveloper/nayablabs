<div class="view">

		<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id),array('view','id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('requisition_date')); ?>:</b>
	<?php echo CHtml::encode($data->requisition_date); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('enter_date')); ?>:</b>
	<?php echo CHtml::encode($data->enter_date); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('p_r_no')); ?>:</b>
	<?php echo CHtml::encode($data->p_r_no); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('supplier_id')); ?>:</b>
	<?php echo CHtml::encode($data->supplier_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('store_id')); ?>:</b>
	<?php echo CHtml::encode($data->store_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('l_s_discount')); ?>:</b>
	<?php echo CHtml::encode($data->l_s_discount); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('remarks')); ?>:</b>
	<?php echo CHtml::encode($data->remarks); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('enter_by')); ?>:</b>
	<?php echo CHtml::encode($data->enter_by); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('tax_overload')); ?>:</b>
	<?php echo CHtml::encode($data->tax_overload); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('p_o_no')); ?>:</b>
	<?php echo CHtml::encode($data->p_o_no); ?>
	<br />

	*/ ?>

</div>