<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'recipe-item-form',
	'enableAjaxValidation'=>true,
	    'clientOptions'=>array(
        'validateOnSubmit'=>true,
       // 'afterValidate'=>'js:$.yii.fix.ajaxSubmit.afterValidate'
    )
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($model); ?>
    
	<?php echo $form->hiddenField($model,'recipe_id',array('class'=>'span5','value'=>$recipe->id)); ?>
    <div style="float:left; padding-right:10px; padding-top:0px;">
    <label>Item</label>
    <input type="text" value="<?php echo $model->inventoryitem->name; ?>" disabled="disabled"/>
	<?php echo $form->hiddenField($model,'inventoryitem_id',array('class'=>'span2','value'=>$model->inventoryitem->id)); ?>
     <?php /*echo $form->dropDownListRow($model,'inventoryitem_id',CHtml::listData(Inventoryitem::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Item:','ajax'=>array(
          'type'=>'POST',
          'url'=>CController::createUrl('inventoryitem/getsaleunit'),
		  'data'=>array('id'=>'js:this.value'),
		   'success'=>"function(data){
			   $('#RecipeItem_unit_id').val(data);
			   $('#RecipeItem_unit_id').prop('disabled', true);
			  // alert(data);
		   }",
          //'update'=>'#RecipeItem_unit_id',
)));*/ ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'quantity',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
    <label>Unit</label>
    <input type="text" value="<?php echo $model->unit->name;?>" disabled="disabled" />
	<?php echo $form->hiddenField($model,'unit_id',array('class'=>'span2')); ?>
     <?php //echo $form->dropDownListRow($model,'unit_id',CHtml::listData(Unit::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Unit:')); ?>
    </div>
<div style="float:left; text-align:center; margin-top:25px;">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$model->isNewRecord ? 'Save' : 'Update',
		)); ?>
        <?php /*$this->widget('bootstrap.widgets.TbButton', array(
                        'buttonType'=>'reset',
                        'type'=>'inverse',
                        'label'=>'Reset',
                ));*/ ?>
</div>

<?php $this->endWidget(); ?>