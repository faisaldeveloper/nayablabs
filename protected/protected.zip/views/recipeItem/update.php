<?php
$this->breadcrumbs=array(
	'Recipe Items'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List RecipeItem','url'=>array('index')),
	array('label'=>'Create RecipeItem','url'=>array('create')),
	array('label'=>'View RecipeItem','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage RecipeItem','url'=>array('admin')),
	);
	?>

	

<?php echo $this->renderPartial('_form',array('model'=>$model)); ?>