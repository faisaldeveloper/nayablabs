<div style="padding-bottom:20px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Recipe:',
    )
    );

?>

<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'recipe-form',
	'enableAjaxValidation'=>true,
        'action'=>$this->createUrl('recipe/ajaxupdate'),
        'enableClientValidation'=>true,

)); ?>

<!--<p class="help-block">Fields with <span class="required">*</span> are required.</p>
-->
<?php echo $form->errorSummary($recipe); ?>

	<?php // echo $form->textFieldRow($model,'requisition_date',array('class'=>'span5')); ?>

      <div id="formResult"></div>
      
    
	  <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($recipe,'name',array('class'=>'span5','maxlength'=>30)); ?>
    </div>
   <?php echo $form->hiddenField($recipe,'id'); ?>
   <div style="float:left;  margin-top:25px;">
        <?php echo CHtml::ajaxSubmitButton('Update',CHtml::normalizeUrl(array('recipe/ajaxupdate','render'=>true)),
                 array(
                     'dataType'=>'json',
                     'type'=>'post',
                     'success'=>'function(data) {
                         $("#AjaxLoader").hide();  
                        if(data.status=="success"){
                         $("#formResult").html("form Updated successfully.");
                        // $("#recipe-form")[0].reset();
                        }
                         else{
                        $.each(data, function(key, val) {
                        $("#recipe-form #"+key+"_em_").text(val);                                                    
                        $("#recipe-form #"+key+"_em_").show();
                        });
                        }       
                    }',                    
                     'beforeSend'=>'function(){                        
                           $("#AjaxLoader").show();
                      }'
                     ),array('id'=>'mybtn','class'=>"btn btn-inverse")); ?>
</div>

</div>
    <div style="clear:both;"></div>

<?php $this->endWidget(); ?>
<hr />
<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Add Item to Recipe:',
    )
    );

?>
</div>
<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'recipe-item-form',
	'enableAjaxValidation'=>false,
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($recipe_item); ?>
    
	<?php echo $form->hiddenField($recipe_item,'recipe_id',array('class'=>'span5','value'=>$recipe->id)); ?>
    <div style="float:left; padding-right:10px">
	<?php //echo $form->textFieldRow($model,'inventoryitem_id',array('class'=>'span2')); ?>
     <?php echo $form->dropDownListRow($recipe_item,'inventoryitem_id',CHtml::listData(Inventoryitem::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Item:','ajax'=>array(
          'type'=>'POST',
          'url'=>CController::createUrl('inventoryitem/getsaleunit'),
		  'data'=>array('id'=>'js:this.value'),
		   'success'=>"function(data){
			   $('#RecipeItem_unit_id').val(data);
			   $('#RecipeItem_unit_id').prop('disabled', true);
			  // alert(data);
		   }",
          //'update'=>'#RecipeItem_unit_id',
))); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($recipe_item,'quantity',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'unit_id',array('class'=>'span2')); ?>
     <?php //echo $form->dropDownListRow($recipe_item,'unit_id',CHtml::listData(Unit::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Unit:')); ?>
    </div>
<div style="float:left; text-align:center; margin-top:25px;">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$recipe_item->isNewRecord ? 'Save' : 'Update',
		)); ?>
        <?php $this->widget('bootstrap.widgets.TbButton', array(
                        'buttonType'=>'reset',
                        'type'=>'inverse',
                        'label'=>'Reset',
                )); ?>
</div>

<?php $this->endWidget(); ?>

 <div style="clear:both;"></div>
<hr />
<div  style="padding-top:20px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Recipe Items :',
    )
    );

?>
</div>

<?php
$this->breadcrumbs=array(
	'Recipe Items'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List RecipeItem','url'=>array('index')),
array('label'=>'Create RecipeItem','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('recipe-item-grid', {
data: $(this).serialize()
});
return false;
});
");
?>



<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:none">
	<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php $this->widget('bootstrap.widgets.TbGridView',array(
'id'=>'recipe-item-grid',
'type' => 'bordered',
'dataProvider'=>$model->recipesearch($recipe->id),
//'filter'=>$model,
'columns'=>array(
		//'id',
		//'recipe_id',
		//'inventoryitem_id',
		array('header'=>'Item','name'=>'inventoryitem_id','value'=>'$data->inventoryitem->name'),
		'quantity',
		//'unit_id',
		array('header'=>'Unit','name'=>'unit_id','value'=>'$data->unit->name'),
array(
'class'=>'bootstrap.widgets.TbButtonColumn',
),
),
)); ?>
