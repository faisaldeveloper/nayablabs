<?php
$this->breadcrumbs=array(
	'Recipe Items'=>array('index'),
	$model->id,
);

$this->menu=array(
array('label'=>'List RecipeItem','url'=>array('index')),
array('label'=>'Create RecipeItem','url'=>array('create')),
array('label'=>'Update RecipeItem','url'=>array('update','id'=>$model->id)),
array('label'=>'Delete RecipeItem','url'=>'#','linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
array('label'=>'Manage RecipeItem','url'=>array('admin')),
);
?>

<h1>View RecipeItem #<?php echo $model->id; ?></h1>

<?php $this->widget('bootstrap.widgets.TbDetailView',array(
'data'=>$model,
'attributes'=>array(
		'id',
		'recipe_id',
		'inventoryitem_id',
		'quantity',
		'unit_id',
),
)); ?>
