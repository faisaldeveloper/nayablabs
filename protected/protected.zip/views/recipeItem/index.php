<?php
$this->breadcrumbs=array(
	'Recipe Items',
);

$this->menu=array(
array('label'=>'Create RecipeItem','url'=>array('create')),
array('label'=>'Manage RecipeItem','url'=>array('admin')),
);
?>

<h1>Recipe Items</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
