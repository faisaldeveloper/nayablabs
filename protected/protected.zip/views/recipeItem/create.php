<?php
$this->breadcrumbs=array(
	'Recipe Items'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List RecipeItem','url'=>array('index')),
array('label'=>'Manage RecipeItem','url'=>array('admin')),
);
?>

<h1>Create RecipeItem</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>