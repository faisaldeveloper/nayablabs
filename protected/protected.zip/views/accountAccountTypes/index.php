<?php
$this->breadcrumbs=array(
	'Account Account Types',
);

$this->menu=array(
array('label'=>'Create AccountAccountTypes','url'=>array('create')),
array('label'=>'Manage AccountAccountTypes','url'=>array('admin')),
);
?>

<h1>Account Account Types</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
