<?php
$this->breadcrumbs=array(
	'Account Account Types'=>array('index'),
	$model->id,
);

$this->menu=array(
array('label'=>'List AccountAccountTypes','url'=>array('index')),
array('label'=>'Create AccountAccountTypes','url'=>array('create')),
array('label'=>'Update AccountAccountTypes','url'=>array('update','id'=>$model->id)),
array('label'=>'Delete AccountAccountTypes','url'=>'#','linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
array('label'=>'Manage AccountAccountTypes','url'=>array('admin')),
);
?>

<h1>View AccountAccountTypes #<?php echo $model->id; ?></h1>

<?php $this->widget('bootstrap.widgets.TbDetailView',array(
'data'=>$model,
'attributes'=>array(
		'id',
		'type',
),
)); ?>
