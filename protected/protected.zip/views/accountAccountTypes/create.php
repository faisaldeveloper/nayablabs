<?php
$this->breadcrumbs=array(
	'Account Account Types'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List AccountAccountTypes','url'=>array('index')),
array('label'=>'Manage AccountAccountTypes','url'=>array('admin')),
);
?>

<h1>Create AccountAccountTypes</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>