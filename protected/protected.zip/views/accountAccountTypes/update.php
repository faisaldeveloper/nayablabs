<?php
$this->breadcrumbs=array(
	'Account Account Types'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List AccountAccountTypes','url'=>array('index')),
	array('label'=>'Create AccountAccountTypes','url'=>array('create')),
	array('label'=>'View AccountAccountTypes','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage AccountAccountTypes','url'=>array('admin')),
	);
	?>

	<h1>Update AccountAccountTypes <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form',array('model'=>$model)); ?>