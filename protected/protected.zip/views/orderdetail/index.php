<?php
$this->breadcrumbs=array(
	'Orderdetails',
);

$this->menu=array(
array('label'=>'Create orderdetail','url'=>array('create')),
array('label'=>'Manage orderdetail','url'=>array('admin')),
);
?>

<h1>Orderdetails</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
