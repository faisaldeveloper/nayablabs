<?php
$this->breadcrumbs=array(
	'Orderdetails'=>array('index'),
	$model->id,
);

$this->menu=array(
array('label'=>'List orderdetail','url'=>array('index')),
array('label'=>'Create orderdetail','url'=>array('create')),
array('label'=>'Update orderdetail','url'=>array('update','id'=>$model->id)),
array('label'=>'Delete orderdetail','url'=>'#','linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
array('label'=>'Manage orderdetail','url'=>array('admin')),
);
?>

<h1>View orderdetail #<?php echo $model->id; ?></h1>

<?php $this->widget('bootstrap.widgets.TbDetailView',array(
'data'=>$model,
'attributes'=>array(
		'id',
		'quantity',
		'menu_id',
		'item_id',
		'tableorder_id',
		'rate',
		'section_id',
),
)); ?>
