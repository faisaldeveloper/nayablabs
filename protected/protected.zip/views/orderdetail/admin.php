<script type="text/javascript">
function PrintPreview(){
	
	window.print();
}
</script>
<?php
$this->breadcrumbs=array(
	'Orderdetails'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List orderdetail','url'=>array('index')),
array('label'=>'Create orderdetail','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('orderdetail-grid', {
data: $(this).serialize()
});
return false;
});
");
?>

<h1>Item wise Sales Report</h1>

<?php Yii::app()->clientScript->registerScript('someScript', "
$('#report').submit(function() {
    //alert('testing');
	if($('#orderdetail_from').val()!= '' && $('#orderdetail_to').val()!= '')
	{
		
		$('#item').text($( '#orderdetail_item_id' ).val());
	$('#from').text($('#orderdetail_from').val());
	$('#to').text($('#orderdetail_to').val());
	}
	else
	{
		
	}
});
");
?>

<div id="print" style="display:none;">
<table id='daterange'>
<tr>
<td><label>Item:</label></td><td><label id='item'><td><label>From:</label></td><td><label id='from'></label></td><td><label>To:</label></td><td><label id='to'></label></td>
</tr>
</table>
<div id="all" style="display:none;">All Recorded Sale</div>
</div>
<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:block">
	<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php $this->widget('ext.groupgridview.BootGroupGridView',array(
'id'=>'orderdetail-grid',
'type'=>'bordered',
'responsiveTable'=>true,
'dataProvider'=>$model->search(),
//'mergeColumns' => array('item_id'),
//'filter'=>$model,
'columns'=>array(
		//'id',
		array(
            'header'=>'Sr #',
            'value'=>'$this->grid->dataProvider->pagination->currentPage * $this->grid->dataProvider->pagination->pageSize + ($row+1)',
        ),
		
		array('header'=>'Item','name'=>'item_id','value'=>'$data->item->name'),
		
		
		//array('header'=>'Date of Sale','name'=>'tableorder_id','value'=>'date("Y-m-d",strtotime($data->tableorder->date_of_tableorder))'),
		array('header'=>'Quantity','name'=>'quantity','value'=>'$data->quantity','htmlOptions'=>array('class'=>'totalsclass',),
		'footer'=>$model->pageTotalQuant($model->search())),
		//'item_id.name',
		//'quantity',
		//'menu_id',
		array('header'=>'Price','name'=>'item_id','value'=>'$data->item->rate'),
		
		array('header'=>'Total','name'=>'item_id','value'=>'$data->rate','htmlOptions'=>array('class'=>'totalsclass',),
		'footer'=>$model->pageTotal($model->search())),
		//'tableorder_id',
		//'rate',
		/*
		'section_id',
		*/
/*array(
'class'=>'bootstrap.widgets.TbButtonColumn',
),*/
),
)); ?>
