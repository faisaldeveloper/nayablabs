<?php
$this->breadcrumbs=array(
	'Orderdetails'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List orderdetail','url'=>array('index')),
array('label'=>'Manage orderdetail','url'=>array('admin')),
);
?>

<h1>Create orderdetail</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>