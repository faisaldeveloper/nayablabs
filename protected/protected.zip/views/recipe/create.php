<?php
$this->breadcrumbs=array(
	'Recipes'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List Recipe','url'=>array('index')),
array('label'=>'Manage Recipe','url'=>array('admin')),
);
?>

<fieldset>
<legend>
<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Create Recipe:',
    )
    );

?>
</div></legend>
<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
</fieldset>

<?php

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('recipe-grid', {
data: $(this).serialize()
});
return false;
});
");
?>

<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:none">
	<?php //$this->renderPartial('_search',array(
	//'model'=>$model,
//)); ?>
</div><!-- search-form -->

<?php $this->widget('bootstrap.widgets.TbGridView',array(
'id'=>'recipe-grid',
'dataProvider'=>$admin->search(),
'filter'=>$admin,
'columns'=>array(
		'id',
		'name',
array(
'class'=>'bootstrap.widgets.TbButtonColumn',
),
),
)); ?>
