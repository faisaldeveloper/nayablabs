<?php
$this->breadcrumbs=array(
	'Account Account Params'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List AccountAccountParam','url'=>array('index')),
array('label'=>'Manage AccountAccountParam','url'=>array('admin')),
);
?>

<h1>Create AccountAccountParam</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>