<?php
$this->breadcrumbs=array(
	'Account Account Params'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List AccountAccountParam','url'=>array('index')),
	array('label'=>'Create AccountAccountParam','url'=>array('create')),
	array('label'=>'View AccountAccountParam','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage AccountAccountParam','url'=>array('admin')),
	);
	?>

	<h1>Update AccountAccountParam <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form',array('model'=>$model)); ?>