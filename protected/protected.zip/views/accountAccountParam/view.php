<?php
$this->breadcrumbs=array(
	'Account Account Params'=>array('index'),
	$model->id,
);

$this->menu=array(
array('label'=>'List AccountAccountParam','url'=>array('index')),
array('label'=>'Create AccountAccountParam','url'=>array('create')),
array('label'=>'Update AccountAccountParam','url'=>array('update','id'=>$model->id)),
array('label'=>'Delete AccountAccountParam','url'=>'#','linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
array('label'=>'Manage AccountAccountParam','url'=>array('admin')),
);
?>

<h1>View AccountAccountParam #<?php echo $model->id; ?></h1>

<?php $this->widget('bootstrap.widgets.TbDetailView',array(
'data'=>$model,
'attributes'=>array(
		'id',
		'defualt_name',
		'user_name',
		'account_id',
),
)); ?>
