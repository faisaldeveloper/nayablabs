<?php
$this->breadcrumbs=array(
	'Account Account Params',
);

$this->menu=array(
array('label'=>'Create AccountAccountParam','url'=>array('create')),
array('label'=>'Manage AccountAccountParam','url'=>array('admin')),
);
?>

<h1>Account Account Params</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
