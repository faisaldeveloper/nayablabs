<?php
$this->breadcrumbs=array(
	'Account Account Params'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List AccountAccountParam','url'=>array('index')),
array('label'=>'Create AccountAccountParam','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('account-account-param-grid', {
data: $(this).serialize()
});
return false;
});
");
?>

<h1>Manage Param Accounts</h1>


<div style="float:right">
<?php
echo CHtml::ajaxSubmitButton('Create All Account',Yii::app()->createUrl('AccountAccountParam/CreateAccount'),
                    array(
                        'type'=>'POST',
                        //'data'=> 'js:{"data1": val1, "data2": val2 }',                        
                        'success'=>'js:function(string){ alert(string); }'           
                    ),array('class'=>'btn inverse',));
?>

</div>
<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:none">
	<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php $this->widget('bootstrap.widgets.TbGridView',array(
'id'=>'account-account-param-grid',
'summaryText' => '', 
'dataProvider'=>$model->search(),
//'filter'=>$model,
'columns'=>array(
		'id',
		'defualt_name',
		'user_name',
		//'account_id',
		array('header'=>'Account', 'name'=>'account_id','value'=>'$data->account_id==NULL ?"not created yet" : $data->account->name'),
array(
'class'=>'bootstrap.widgets.TbButtonColumn',
'template'=>'{update}',
),
),
)); ?>
