<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Track Store Out:',
    )
    );

?>
</div>
<?php
$this->breadcrumbs=array(
	'Storeouts'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List Storeout','url'=>array('index')),
array('label'=>'Create Storeout','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('storeout-grid', {
data: $(this).serialize()
});
return false;
});
");
?>

<?php Yii::app()->clientScript->registerScript('someScript', "
$('#report').submit(function() {
    //alert('testing');
	//if($('#Storein_from_date').val()!= '' && $('#Storein_to_date').val()!= '')
	//{
		if($('#Storeout_supplier').find('option:selected').text()!='Select Supplier:')
		{
			var supplier=$('#Storeout_supplier').find('option:selected').text();
		}
		else
		{
			var supplier='';
		}
		if($('#Storeout_outlet_id').find('option:selected').text()!='Select Outlet:')
		{
			var outlet=$('#Storeout_outlet_id').find('option:selected').text();
		}
		else
		{
			var outlet='';
		}
		if($('#Storeout_store').find('option:selected').text()!='Select Store:')
		{
			var store=$('#Storeout_store').find('option:selected').text();
		}
		else
		{
			var store='';
		}
		if($('#Storeout_inventoryitem_id').find('option:selected').text()!='Select Item:')
		{
			var item=$('#Storeout_inventoryitem_id').find('option:selected').text();
		}
		else
		{
			var item='';
		}
		if($('#Storeout_type').find('option:selected').text()!='Select Type:')
		{
			var type=$('#Storeout_type').find('option:selected').text();
		}
		else
		{
			var type='';
		}
		$('#supplier').text(supplier);
		$('#outlet').text(outlet);
		$('#store').text(store);
		$('#item').text(item);
		$('#type').text(type);
	$('#from').text($('#Storeout_from_date').val());
	$('#to').text($('#Storeout_to_date').val());
	//}
	//else
	//{
		
	//}
});
");
?>
<div id="print" style="display:none;">
<table id='daterange'>
<tr>
<th>Store:</th><td><label id='store'></label></td>
<th>Item:</th><td><label id='item'></label></td>
<th>Type:</th><td><label id='type'></label></td>

<th id="supp_th">Supp:</th><td id="supp_lbl" ><label id='supplier'></label></td>
<th id="outlet_th">Outlet:</th><td id="outlet_lbl" ><label id='outlet'></label></td>
<th>From:</th><td><label id='from'></label></td>
<th>To:</th><td><label id='to'></label></td>
</tr>
</table>
<div id="all" style="display:none;">All Recorded Sale</div>
</div>

<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:block">
	<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php /*$this->widget('bootstrap.widgets.TbGridView',array(
'id'=>'storeout-grid',
'dataProvider'=>$model->search(),
'filter'=>$model,
'columns'=>array(
		'id',
		'quantity',
		//'dos',
		'inventoryitem_id',
		'outlet_id',
		'store_id',*/
		/*
		'remarks',
		'enter_by',
		'stock_transfer_id',
		*/
/*array(
'class'=>'bootstrap.widgets.TbButtonColumn',
),
),
));*/ ?>


<?php $this->widget('ext.groupgridview.BootGroupGridView',array(
'id'=>'storeout-grid',
'type'=>'bordered',
'dataProvider'=>$model->search(),
'mergeColumns' => ('stock_transfer_id'),
//'filter'=>$model,
'columns'=>array(
       // 'stock_transfer_id',
		array('header'=>'ST id','name'=>'stock_transfer_id','value'=>'$data->stock_transfer_id'),
		//'id',
		array('header'=>'Store','name'=>'stock_transfer_id','value'=>'Store::model()->getname($data->stockTransfer->store_id)'),
		array('header'=>'Supplier','name'=>'stock_transfer_id','value'=>'Supplier::model()->getname($data->stockTransfer->supplier_id)','visible'=>$model->type==1 || !isset($model->type)),
		array('header'=>'Outlet','name'=>'stock_transfer_id','value'=>'Outlet::model()->getname($data->stockTransfer->outlet_id)','visible'=>$model->type==2 || !isset($model->type)),
		array('header'=>'Type','name'=>'stock_transfer_id','value'=>'StockTransfer::model()->get_type($data->stockTransfer->transfer_type)'),
		array('header'=>'Item','name'=>'inventoryitem_id','value'=>'$data->inventoryitem->name'),
		'quantity',
		
		//array('header'=>'Store','name'=>'pr_id','value'=>'$data->pr->store_id'),
		array('header'=>'Purch Rate','name'=>'purchrate','value'=>'$data->purchrate','visible'=>$model->type==3 || $model->type==1 || !isset($model->type)),
		array('header'=>'Sale Rate','name'=>'salerate','value'=>'$data->salerate','visible'=>$model->type==3 || $model->type==1 || !isset($model->type)),
		//'purchrate',
		//'salerate',
		//array('header'=>'Date','name'=>'pr_id','value'=>'PurchaseRequisition::model()->getprdate($data->pr->id)'),
		//'quantity',
		
		//'scheme',
		//'discount',
		/*
		'inventoryitem_id',
		'store_id',
		*/
/*array(
'class'=>'bootstrap.widgets.TbButtonColumn',
),*/
),
)); ?>
