<?php
$this->breadcrumbs=array(
	'Storeouts'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List Storeout','url'=>array('index')),
array('label'=>'Manage Storeout','url'=>array('admin')),
);
?>

<h1>Create Storeout</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>