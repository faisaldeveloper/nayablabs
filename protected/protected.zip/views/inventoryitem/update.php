<?php
$this->breadcrumbs=array(
	'Inventoryitems'=>array('index'),
	$inventory_item->name=>array('view','id'=>$inventory_item->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List Inventoryitem','url'=>array('index')),
	array('label'=>'Create Inventoryitem','url'=>array('create')),
	array('label'=>'View Inventoryitem','url'=>array('view','id'=>$inventory_item->id)),
	array('label'=>'Manage Inventoryitem','url'=>array('admin')),
	);
	?>

	<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Update Item:',
    )
    );

?>
</div>

<?php echo $this->renderPartial('_form',array('inventory_item'=>$inventory_item)); ?>