<?php
$this->breadcrumbs=array(
	'Inventoryitems'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List Inventoryitem','url'=>array('index')),
array('label'=>'Manage Inventoryitem','url'=>array('admin')),
);
?>

<h1>Create Inventoryitem</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>