<script type="text/javascript">

$(document).ready(function() {
  $(window).keydown(function(event){
    if(event.keyCode == 13) {
      event.preventDefault();
      return false;
    }
  });
});

</script>
<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'inventoryitem-form',
	'enableAjaxValidation'=>false,
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($inventory_item); ?>
     <div style="float:left; padding-right:10px">
<?php echo $form->dropDownListRow($inventory_item,'category_id',CHtml::listData(Category::model()->findAll(),'id','name'),array('class'=>'span2')); ?>
</div>
     <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($inventory_item,'name',array('class'=>'span2','maxlength'=>30)); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($inventory_item,'code',array('class'=>'span2','maxlength'=>20)); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($inventory_item,'minqty',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($inventory_item,'maxqty',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
    <?php echo $form->dropDownListRow($inventory_item,'unit_id',CHtml::listData(Unit::model()->findAll(),'id','name'),array('class'=>'span2')); ?>
    </div>
    
	<?php //echo $form->textFieldRow($model,'unit_id',array('class'=>'span2')); ?>

	<?php //echo $form->textFieldRow($model,'category_id',array('class'=>'span2')); ?>

<div style="clear:both;"></div>
<div style="float:left; padding-right:10px">
<?php echo $form->dropDownListRow($inventory_item,'purchase_unit',CHtml::listData(Unit::model()->findAll(),'id','name'),array('class'=>'span2')); ?>
</div>
	<?php //echo $form->textFieldRow($model,'purchase_unit',array('class'=>'span2')); ?>
   <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($inventory_item,'per_purchase',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
<?php echo $form->dropDownListRow($inventory_item,'sale_unit',CHtml::listData(Unit::model()->findAll(),'id','name'),array('class'=>'span2')); ?>
	<?php // echo $form->textFieldRow($model,'sale_unit',array('class'=>'span2')); ?>
    </div>
<div style="float:left; margin-top:25px">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$model->isNewRecord ? 'Create' : 'Save',
		)); ?>
</div>
<div style="clear:both;"></div>
<?php $this->endWidget(); ?>
