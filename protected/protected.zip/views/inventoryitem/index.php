<?php
$this->breadcrumbs=array(
	'Inventoryitems',
);

$this->menu=array(
array('label'=>'Create Inventoryitem','url'=>array('create')),
array('label'=>'Manage Inventoryitem','url'=>array('admin')),
);
?>

<h1>Inventoryitems</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
