<div class="view">

		<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id),array('view','id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('name')); ?>:</b>
	<?php echo CHtml::encode($data->name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('code')); ?>:</b>
	<?php echo CHtml::encode($data->code); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('minqty')); ?>:</b>
	<?php echo CHtml::encode($data->minqty); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('maxqty')); ?>:</b>
	<?php echo CHtml::encode($data->maxqty); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('unit_id')); ?>:</b>
	<?php echo CHtml::encode($data->unit_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('category_id')); ?>:</b>
	<?php echo CHtml::encode($data->category_id); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('purchase_unit')); ?>:</b>
	<?php echo CHtml::encode($data->purchase_unit); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('per_purchase')); ?>:</b>
	<?php echo CHtml::encode($data->per_purchase); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('sale_unit')); ?>:</b>
	<?php echo CHtml::encode($data->sale_unit); ?>
	<br />

	*/ ?>

</div>