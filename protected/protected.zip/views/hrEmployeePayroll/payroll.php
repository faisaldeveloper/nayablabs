<?php
$record=Yii::app()->db->createCommand("SELECT * FROM hr_employee employee, hr_employee_earning earning, hr_employee_deductions deduction WHERE employee.id=earning.employee_id AND employee.id=deduction.employee_id AND  employee.active = 1 AND ( earning.gross_pay = 0 OR earning.days = 0) ")->queryAll();
if(count($record)>0)
{
	echo date("t", strtotime(date('Y-m-d')));
	echo "Set earning for All Employee's!";
	exit;
	
}
else
{
$record=Yii::app()->db->createCommand("SELECT * FROM hr_employee employee, hr_employee_earning earning,hr_employee_deductions deduction WHERE employee.id=earning.employee_id AND employee.id=deduction.employee_id AND employee.active = 1  ")->queryAll();


}
?>
<div>
<div align="center">
<h1>PayRoll For (<?php echo date('Y-m',strtotime("-1 month"));?>)</h1>
</div>
<div>
<table border="1" >
<tr><th>Sr.</th><th>Name</th><th>F Name</th><th>NIC</th><th>Designation</th><th>Basic Salary</th><th>All Additions</th><th>Gross Salary</th><th>Days</th><th>Paid leaves</th><th>Salary</th><th>Tax.</th><th>Gratuity</th><th>Loan Installment</th><th>Insurance </th><th>Sec. Deposit</th><th>EOBI</th><th>Payable</th><th>Signature</th><th></th></tr>
<?php 
$sr=1;
$total_payable=0;
foreach ($record as $row)
{
	 $voucher_type=AccountVoucherParam::model()->find('defualt_name="type2"');
	 $employee_payroll=HrEmployeePayroll::model()->find('employee_id='.$row['employee_id'].' AND salary_month LIKE "'.date('Y-m',strtotime("-1 month")).'%"');
	
	 if(count($employee_payroll) ==0)
	 {
		 $vouchercount=AccountVoucher::model()->findAll('voucher_type='.$voucher_type->id);
		 $voucher=new AccountVoucher;
		 if(count($vouchercount)==0)
		 {
		    $voucher->number=$voucher_type->id.'0000';
		 }
		 else
		 {
			 $get=Yii::app()->db->createCommand('SELECT MAX(number) AS number FROM account_voucher WHERE voucher_type='.$voucher_type->id.';')->queryAll();
			 
			 $number=$get[0]['number'];
			 $voucher->number=$number+1;
		 }
		 $voucher->voucher_type=$voucher_type->id;
		$voucher->save();
	 }
	 else
	 {
		 
		 $voucher=AccountVoucher::model()->findByPk($employee_payroll->voucher_id);
		 
	 }
	 
	 
	echo "basic salary=".(int)$row['salary']."</br/>";
	
	echo "per_day=".$per_day_salary  = number_format(  ((int)$row['salary'])/((int)date("t", strtotime('-1 month'))),4, '.', '')."<br/>";
	
	echo "working days salary=".$salary  = number_format( ($per_day_salary)*((int)$row['days']+(int)$row['leave_days']), 4, '.', '');
	$salary_expense=$salary+number_format( $row['advance_salary']+$row['medical']+$row['Conveyance_Allowance']+$row['sp_allownces'], 4, '.', '')+number_format(($row['house_rent']+$row['over_time']+$row['bonus']+$row['leave_encashment']+$row['other_incentive']), 4, '.', '');
	
	$salary_expense_account=AccountAccountParam::model()->find('defualt_name="salary expense"');
	if($salary_expense>0)
	{
		
		$salary_expense_ledger_entry=AccountLedger::model()->find('dr_account='.$salary_expense_account->account_id.' AND cr_account='.$row['account'].' AND trans_date LIKE "'.date('Y-m').'%"');
		
		 if(count($salary_expense_ledger_entry)>0)
		{
			$salary_expense_ledger_entry->amount=$salary_expense;
			$salary_expense_ledger_entry->voucher_id=$voucher->id;
			$salary_expense_ledger_entry->trans_date=date('Y-m-d H:i:s');
			$salary_expense_ledger_entry->save();
		}
		else
		{
			$salary_expense_ledger_entry= new AccountLedger;
			 $salary_expense_ledger_entry->dr_account=$salary_expense_account->account_id;
			 $salary_expense_ledger_entry->cr_account=$row['account'];
			 $salary_expense_ledger_entry->amount=$salary_expense;
			$salary_expense_ledger_entry->voucher_id=$voucher->id;
			$salary_expense_ledger_entry->trans_date=date('Y-m-d H:i:s');
			$salary_expense_ledger_entry->save();
		}
	}
	echo "<br/>non taxable salary=".$non_taxable_salary  = number_format( $row['medical']+$row['Conveyance_Allowance']+$row['sp_allownces'], 2, '.', '');
	
	echo "<br/>taxable salary=".$taxable_salary  = number_format( $salary+($row['house_rent']+$row['over_time']+$row['bonus']+$row['leave_encashment']+$row['other_incentive']), 2, '.', '');
	
	echo $advance_salary  =  $row['advance_salary']."<br/>";
	
	echo "<br/>applicable tax amount=".$row['income_tax'].'%';
	
	echo "<br/> tax =".$tax=number_format(($row['income_tax']/100)*$taxable_salary, 2, '.', '');
	
	echo "<br/> After tax salary = ".$after_tax_salary=number_format(($non_taxable_salary+($taxable_salary-$tax)), 2, '.', '');
	echo "<br/> gratuity amoount=".$gratuity_amount=number_format((Yii::app()->params['gratuity']/100)*$after_tax_salary, 2, '.', '');
	echo "<br/> Deduction=".$deduction=$installment_loan+$row['insurance']+$row['EOBI']+$gratuity_amount+$security_deposit;
	
	echo "<br/>payable".$payable=number_format($salary_expense-$deduction, 2, '.', '');
	echo "<br/>after Deductions= ".$after_deduction=number_format($after_tax_salary-$deduction, 2, '.', '');
	
	date("t", strtotime('-1 month'));
	
	////////// Income tax ///////////
	 $tax_payable_account=AccountAccountParam::model()->find('defualt_name="tax payable"');
	 if((float)$row['income_tax'] > 0)
	 {
		 $tax_payable_ledger_entry=AccountLedger::model()->find('dr_account='.$row['account'].' AND cr_account='.$tax_payable_account->account_id.' AND trans_date LIKE "'.date('Y-m').'%"');
		 if(count($tax_payable_ledger_entry)>0)
		 {
			$tax_payable_ledger_entry->amount=$tax;
			$tax_payable_ledger_entry->voucher_id=$voucher->id;
			$tax_payable_ledger_entry->trans_date=date('Y-m-d H:i:s');
			$tax_payable_ledger_entry->save();
		 }
		 else
		 {
			 $tax_payable_ledger_entry= new AccountLedger;
			 $tax_payable_ledger_entry->dr_account=$row['account'];
			 $tax_payable_ledger_entry->cr_account=$tax_payable_account->account_id;
			 $tax_payable_ledger_entry->amount=$tax;
			$tax_payable_ledger_entry->voucher_id=$voucher->id;
			$tax_payable_ledger_entry->trans_date=date('Y-m-d H:i:s');
			$tax_payable_ledger_entry->save();
			 
		 }
		 
	 }
	 ///////// income tax end ///////
	/////////  insurance ////////
	$insurance_account=AccountAccountParam::model()->find('defualt_name="insurance"');
	if($row['insurance']>0)
	{
		 $insurance_ledger_entry=AccountLedger::model()->find('dr_account='.$row['account'].' AND cr_account='.$insurance_account->account_id.' AND trans_date LIKE "'.date('Y-m').'%"');
		if(count($insurance_ledger_entry)>0)
		{
			$insurance_ledger_entry->amount=$row['insurance'];
			$insurance_ledger_entry->voucher_id=$voucher->id;
			$insurance_ledger_entry->trans_date=date('Y-m-d H:i:s');
			$insurance_ledger_entry->save();
		}
		else
		{
			$insurance_ledger_entry= new AccountLedger;
			 $insurance_ledger_entry->dr_account=$row['account'];
			 $insurance_ledger_entry->cr_account=$insurance_account->account_id;
			 $insurance_ledger_entry->amount=$row['insurance'];
			$insurance_ledger_entry->voucher_id=$voucher->id;
			$insurance_ledger_entry->trans_date=date('Y-m-d H:i:s');
			$insurance_ledger_entry->save();
		}
	}
	//////// insurance ends /////
	
	/////// eobi trans //////
	$eobi_account=AccountAccountParam::model()->find('defualt_name="eobi"');
	if($row['EOBI']>0)
	{
		$eobi_ledger_entry=AccountLedger::model()->find('dr_account='.$row['account'].' AND cr_account='.$eobi_account->account_id.' AND trans_date LIKE "'.date('Y-m').'%"');
		if(count($eobi_ledger_entry)>0)
		{
			$eobi_ledger_entry->amount=$row['EOBI'];
			$eobi_ledger_entry->voucher_id=$voucher->id;
			$eobi_ledger_entry->trans_date=date('Y-m-d H:i:s');
			$eobi_ledger_entry->save();
		}
		else
		{
			$eobi_ledger_entry= new AccountLedger;
			 $eobi_ledger_entry->dr_account=$row['account'];
			 $eobi_ledger_entry->cr_account=$eobi_account->account_id;
			 $eobi_ledger_entry->amount=$row['EOBI'];
			$eobi_ledger_entry->voucher_id=$voucher->id;
			$eobi_ledger_entry->trans_date=date('Y-m-d H:i:s');
			$eobi_ledger_entry->save();
		}
	}
	////// eobi trans end //////
	
	////// gratuity ///////
	$gratuity_account=AccountAccountParam::model()->find('defualt_name="gratuity"');
	
		$gratuity_ledger_entry=AccountLedger::model()->find('dr_account='.$row['account'].' AND cr_account='.$gratuity_account->account_id.' AND trans_date LIKE "'.date('Y-m').'%"');
		if(count($gratuity_ledger_entry)>0)
		{
			$eobi_ledger_entry->amount=$gratuity_amount;
			$eobi_ledger_entry->voucher_id=$voucher->id;
			$eobi_ledger_entry->trans_date=date('Y-m-d H:i:s');
			$eobi_ledger_entry->save();
		}
		else
		{
			$eobi_ledger_entry= new AccountLedger;
			 $eobi_ledger_entry->dr_account=$row['account'];
			 $eobi_ledger_entry->cr_account=$gratuity_account->account_id;
			 $eobi_ledger_entry->amount=$gratuity_amount;
			$eobi_ledger_entry->voucher_id=$voucher->id;
			$eobi_ledger_entry->trans_date=date('Y-m-d H:i:s');
			$eobi_ledger_entry->save();
		}
	
	////// gratuity ends /////
	
	/////// securtiy deposit check on first payroll//////
	 ////// if first pay roll of specific employee then entered security deposit ammount will b deducted other wise 0 amount will be deducted for the months afterward
	 $payroll=HrEmployeePayroll::model()->find('employee_id=:employee_id',array(':employee_id'=>$row['employee_id']));
	 if(count($payroll) > 0)
	 {
	    $security_deposit=0;
		
	 }
	 else
	 {
	   $security_deposit=$row['security_deposit'];
	    $security_deposit_account=AccountAccountParam::model()->find('defualt_name="security deposit"');
	  if($row['security_deposit']>0)
	  {
		  $security_deposit_ledger_entry=AccountLedger::model()->find('dr_account='.$row['account'].' AND cr_account='.$security_deposit_account->account_id.' AND trans_date LIKE "'.date('Y-m').'%"');
		  if(count($security_deposit_ledger_entry)>0)
		{
			$security_deposit_ledger_entry->amount=$row['security_deposit'];
			$security_deposit_ledger_entry->voucher_id=$voucher->id;
			$security_deposit_ledger_entry->trans_date=date('Y-m-d H:i:s');
			$security_deposit_ledger_entry->save();
		}
		else
		{
			$security_deposit_ledger_entry= new AccountLedger;
			 $security_deposit_ledger_entry->dr_account=$row['account'];
			 $security_deposit_ledger_entry->cr_account=$security_deposit_account->account_id;
			 $security_deposit_ledger_entry->amount=$row['security_deposit'];
			$security_deposit_ledger_entry->voucher_id=$voucher->id;
			$security_deposit_ledger_entry->trans_date=date('Y-m-d H:i:s');
			$security_deposit_ledger_entry->save();
		}
		  
	  }
	 }
	 
	 ///////////// check end /////////////////
	 
	 ////////////loan installment ////////
	 $loan=HrLoan::model()->find('employee_id='.$row['employee_id']);
	 
	 $loan_account=AccountAccountParam::model()->find('defualt_name="Loan"');
	 if(count($loan) > 0)
	 
	 {
		$amount_left=$loan->amount_given-$loan->amount_returned;
		$loan_ledger_entry=AccountLedger::model()->find('dr_account='.$loan_account->account_id.' AND cr_account='.$row['account'].' AND trans_date LIKE "'.date('Y-m').'%"');
		echo 'dr_account='.$loan_account->account_id.' AND cr_account='.$row['account'].' AND trans_date LIKE "'.date('Y-m').'%"';
		echo "row count=".count($loan_ledger_entry);
		echo "installment loan=".$row['instalment_loan'];
		if(count($loan_ledger_entry)>0)
		{
			if($amount_left >= $row['instalment_loan'])
			{
				$loan->amount_returned = $loan->amount_returned - $loan_ledger_entry->amount;
				$loan->amount_returned= $loan->amount_returned + $row['instalment_loan'];
				//$loan->amount_left= $loan->amount_left - $row['instalment_loan'];
				$loan_ledger_entry->amount = $row['instalment_loan'];
				$loan->save();
				echo "trans update=".$loan_ledger_entry->amount;
				$loan_ledger_entry->voucher_id=$voucher->id;
				$loan_ledger_entry->save();
				$installment_loan=$row['instalment_loan'];
			}
			else if($amount_left < $row['instalment_loan'])
			{
				$loan->amount_returned = $loan->amount_returned - $loan_ledger_entry->amount;
				$loan->amount_returned= $loan->amount_returned + $amount_left;
				//$loan->amount_left= $loan->amount_left - $loan->amount_left;
				$loan_ledger_entry->amount = $loan->amount_left;
				$loan->save();
				echo "trans update=".$loan_ledger_entry->amount;
				$loan_ledger_entry->voucher_id=$voucher->id;
				$loan_ledger_entry->save();
				$installment_loan=$row['instalment_loan'];
			}
			
		}
		else
		{
			
			$loan_ledger_entry=new AccountLedger;
			$amount_left=$loan->amount_given-$loan->amount_returned;
			if($amount_left >= $row['instalment_loan'])
			{
				$loan->amount_returned = $loan->amount_returned - $loan_ledger_entry->amount;
				$loan->amount_returned= $loan->amount_returned + $row['instalment_loan'];
				//$loan->amount_left= $loan->amount_left - $row['instalment_loan'];
				$loan_ledger_entry->dr_account=$row['account'];
				$loan_ledger_entry->cr_account=$loan_account->account_id;
				$loan_ledger_entry->trans_date=date('Y-m-d H:i:s');
				$loan_ledger_entry->amount = $row['instalment_loan'];
			    $loan_ledger_entry->voucher_id=$voucher->id;
				$loan->save();
				echo "trans new=".$loan_ledger_entry->amount;
				$loan_ledger_entry->save();
				$installment_loan=$row['instalment_loan'];
			}
			else if($amount_left < $row['instalment_loan'])
			{
				$loan->amount_returned = $loan->amount_returned - $loan_ledger_entry->amount;
				$loan->amount_returned= $loan->amount_returned + $amount_left;
				//$loan->amount_left= $loan->amount_left - $loan->amount_left;
				$loan_ledger_entry->dr_account=$row['account'];
				$loan_ledger_entry->cr_account=$loan_account->account_id;
				$loan_ledger_entry->trans_date=date('Y-m-d H:i:s');
				$loan_ledger_entry->amount = $loan->amount_left;
				$loan_ledger_entry->voucher_id=$voucher->id;
				$loan->save();
				echo "trans new=".$loan_ledger_entry->amount;
				$loan_ledger_entry->save();
				$installment_loan=$row['instalment_loan'];
			}
		
		}
	 }
	 else
	 {
		 $installment_loan=0;
	 }
	 ////////// loan end////////////
	?>
    
    
    <tr>
    <td><?php echo $sr; ?></td>
    <td><?php echo $row['first_name']; ?></td>
    <td><?php echo $row['first_name'].' '.$row['last_name']; ?></td>
    <td><?php echo $row['CNIC']; ?></td>
    <td><?php $designation=HrDesignation::model()->findByPk($row['designation_id']); echo $designation->name ; ?></td>
     <td><?php echo $row['salary']; ?></td>
     <td>
	 <?php 
	 $incentives=$row['medical']+$row['house_rent']+$row['over_time']+$row['Conveyance_Allowance']+$row['bonus']+$row['other_incentive']+$row['sp_allownces'];
	 echo $incentives; 
	 ?>
     </td>
     
     <td><?php echo $row['gross_pay']; ?></td>
     <td><?php echo (int)$row['days']+(int)$row['leave_days']; ?></td>
     <td><?php echo (int)$row['leave_days'];?></td>
     <td>
	     <?php //echo $after_tax_salary;
	       echo $salary_expense;
	    ?>
     </td>
     <td><?php echo $tax;?></td>
     <td><?php echo $gratuity_amount; ?></td> 
     <td><?php echo $row['instalment_loan']; ?></td>
     
     <td>
     <?php
	 echo  $row['insurance'];
	 //echo $deduction;
	 ?>
     </td>
    
     <td><?php echo $security_deposit; ?></td>
     <td><?php echo $row['EOBI']; ?></td>
     <td><?php //echo $after_deduction;
	     echo $payable;
	 
	   ?></td>
     <td>__________</td>
    </tr>
    
    
 <?php 
 
 
 
 $employee_payroll=HrEmployeePayroll::model()->find('employee_id=:employee_id AND salary_month=:salary_month',array(':employee_id'=>$row['employee_id'],':salary_month'=>date('Y-m-d',strtotime("-1 month"))));
 if(count($employee_payroll) > 0)
 {
	 
	 $employee_payroll->employee_id=$row['employee_id'];
     $employee_payroll->basic_salary=$row['salary'];
     $employee_payroll->all_incentive=$incentives;
     $employee_payroll->gross_salary=$row['gross_pay'];
     $employee_payroll->days=$row['days'];
     $employee_payroll->salary=$after_tax_salary;
     $employee_payroll->gratuity=$gratuity_amount;
     $employee_payroll->loan_installment=$row['instalment_loan'];
     $employee_payroll->insurance=$row['insurance'];
     $employee_payroll->sec_deposit=$security_deposit;
     $employee_payroll->eobi=$row['EOBI'];
     $employee_payroll->voucher_id=$voucher->id;
     $employee_payroll->payable=$after_deduction;
 
     $employee_payroll->salary_month=date('Y-m-d',strtotime("-1 month"));
     $employee_payroll->save();
 }
 else
 {
	 
    $employee_payroll=new HrEmployeePayroll;
    $employee_payroll->employee_id=$row['employee_id'];
    $employee_payroll->basic_salary=$row['salary'];
    $employee_payroll->all_incentive=$incentives;
    $employee_payroll->gross_salary=$row['gross_pay'];
    $employee_payroll->days=$row['days'];
    $employee_payroll->salary=$after_tax_salary;
    $employee_payroll->gratuity=$gratuity_amount;
    $employee_payroll->loan_installment=$row['instalment_loan'];
    $employee_payroll->insurance=$row['insurance'];
    $employee_payroll->sec_deposit=$security_deposit;
    $employee_payroll->eobi=$row['EOBI'];
    $employee_payroll->payable=$after_deduction;
    $employee_payroll->voucher_id=$voucher->id;
    $employee_payroll->salary_month=date('Y-m-d',strtotime("-1 month"));
    $employee_payroll->save();
 }
 $sr++;
 $total_payable=$total_payable+$after_deduction;
}
 ?> 
  <tr><td colspan="16"></td><td><?php echo $total_payable;?></td><td></td></tr>
</table>
</div>
</div>