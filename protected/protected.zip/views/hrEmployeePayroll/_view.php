<div class="view">

		<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id),array('view','id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_id')); ?>:</b>
	<?php echo CHtml::encode($data->employee_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('basic_salary')); ?>:</b>
	<?php echo CHtml::encode($data->basic_salary); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('all_incentive')); ?>:</b>
	<?php echo CHtml::encode($data->all_incentive); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('gross_salary')); ?>:</b>
	<?php echo CHtml::encode($data->gross_salary); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('days')); ?>:</b>
	<?php echo CHtml::encode($data->days); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('salary')); ?>:</b>
	<?php echo CHtml::encode($data->salary); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('gratuity')); ?>:</b>
	<?php echo CHtml::encode($data->gratuity); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('loan_installment')); ?>:</b>
	<?php echo CHtml::encode($data->loan_installment); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('insurance')); ?>:</b>
	<?php echo CHtml::encode($data->insurance); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('sec_deposit')); ?>:</b>
	<?php echo CHtml::encode($data->sec_deposit); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('eobi')); ?>:</b>
	<?php echo CHtml::encode($data->eobi); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('payable')); ?>:</b>
	<?php echo CHtml::encode($data->payable); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('salary_month')); ?>:</b>
	<?php echo CHtml::encode($data->salary_month); ?>
	<br />

	*/ ?>

</div>