<?php
$this->breadcrumbs=array(
	'Hr Employee Payrolls',
);

$this->menu=array(
array('label'=>'Create HrEmployeePayroll','url'=>array('create')),
array('label'=>'Manage HrEmployeePayroll','url'=>array('admin')),
);
?>

<h1>Hr Employee Payrolls</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
