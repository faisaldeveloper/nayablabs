<?php
$this->breadcrumbs=array(
	'Hr Employee Payrolls'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List HrEmployeePayroll','url'=>array('index')),
array('label'=>'Manage HrEmployeePayroll','url'=>array('admin')),
);
?>

<h1>Create HrEmployeePayroll</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>