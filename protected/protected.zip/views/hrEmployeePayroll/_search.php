<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

		<?php echo $form->textFieldRow($model,'id',array('class'=>'span5')); ?>

		<?php echo $form->textFieldRow($model,'employee_id',array('class'=>'span5')); ?>

		<?php echo $form->textFieldRow($model,'basic_salary',array('class'=>'span5')); ?>

		<?php echo $form->textFieldRow($model,'all_incentive',array('class'=>'span5')); ?>

		<?php echo $form->textFieldRow($model,'gross_salary',array('class'=>'span5')); ?>

		<?php echo $form->textFieldRow($model,'days',array('class'=>'span5')); ?>

		<?php echo $form->textFieldRow($model,'salary',array('class'=>'span5')); ?>

		<?php echo $form->textFieldRow($model,'gratuity',array('class'=>'span5')); ?>

		<?php echo $form->textFieldRow($model,'loan_installment',array('class'=>'span5')); ?>

		<?php echo $form->textFieldRow($model,'insurance',array('class'=>'span5')); ?>

		<?php echo $form->textFieldRow($model,'sec_deposit',array('class'=>'span5')); ?>

		<?php echo $form->textFieldRow($model,'eobi',array('class'=>'span5')); ?>

		<?php echo $form->textFieldRow($model,'payable',array('class'=>'span5')); ?>

		<?php echo $form->textFieldRow($model,'salary_month',array('class'=>'span5')); ?>

	<div class="form-actions">
		<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType' => 'submit',
			'type'=>'primary',
			'label'=>'Search',
		)); ?>
	</div>

<?php $this->endWidget(); ?>
