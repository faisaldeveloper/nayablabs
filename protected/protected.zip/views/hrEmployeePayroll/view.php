<?php
$this->breadcrumbs=array(
	'Hr Employee Payrolls'=>array('index'),
	$model->id,
);

$this->menu=array(
array('label'=>'List HrEmployeePayroll','url'=>array('index')),
array('label'=>'Create HrEmployeePayroll','url'=>array('create')),
array('label'=>'Update HrEmployeePayroll','url'=>array('update','id'=>$model->id)),
array('label'=>'Delete HrEmployeePayroll','url'=>'#','linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
array('label'=>'Manage HrEmployeePayroll','url'=>array('admin')),
);
?>

<h1>View HrEmployeePayroll #<?php echo $model->id; ?></h1>

<?php $this->widget('bootstrap.widgets.TbDetailView',array(
'data'=>$model,
'attributes'=>array(
		'id',
		'employee_id',
		'basic_salary',
		'all_incentive',
		'gross_salary',
		'days',
		'salary',
		'gratuity',
		'loan_installment',
		'insurance',
		'sec_deposit',
		'eobi',
		'payable',
		'salary_month',
),
)); ?>
