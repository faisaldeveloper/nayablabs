<?php
$this->breadcrumbs=array(
	'Hr Employee Payrolls'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List HrEmployeePayroll','url'=>array('index')),
	array('label'=>'Create HrEmployeePayroll','url'=>array('create')),
	array('label'=>'View HrEmployeePayroll','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage HrEmployeePayroll','url'=>array('admin')),
	);
	?>

	<h1>Update HrEmployeePayroll <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form',array('model'=>$model)); ?>