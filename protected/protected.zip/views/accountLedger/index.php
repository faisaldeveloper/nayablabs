<?php
$this->breadcrumbs=array(
	'Account Ledgers',
);

$this->menu=array(
array('label'=>'Create AccountLedger','url'=>array('create')),
array('label'=>'Manage AccountLedger','url'=>array('admin')),
);
?>

<h1>Account Ledgers</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
