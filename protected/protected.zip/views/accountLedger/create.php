<?php
$this->breadcrumbs=array(
	'Account Ledgers'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List AccountLedger','url'=>array('index')),
array('label'=>'Manage AccountLedger','url'=>array('admin')),
);
?>

<h1>Create AccountLedger</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>