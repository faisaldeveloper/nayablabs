<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Track Store In:',
    )
    );

?>
</div>
<?php
$this->breadcrumbs=array(
	'Storeins'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List Storein','url'=>array('index')),
array('label'=>'Create Storein','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('storein-grid', {
data: $(this).serialize()
});
return false;
});
");
?>
<?php Yii::app()->clientScript->registerScript('someScript', "
$('#report').submit(function() {
    //alert('testing');
	//if($('#Storein_from_date').val()!= '' && $('#Storein_to_date').val()!= '')
	//{
		if($('#Storein_supplier').find('option:selected').text()!='Select Supplier:')
		{
			var supplier=$('#Storein_supplier').find('option:selected').text();
		}
		else
		{
			var supplier='Not Selected';
		}
		if($('#Storein_store').find('option:selected').text()!='Select Store:')
		{
			var store=$('#Storein_store').find('option:selected').text();
		}
		else
		{
			var store='Not Selected';
		}
		if($('#Storein_inventoryitem_id').find('option:selected').text()!='Select Item:')
		{
			var item=$('#Storein_inventoryitem_id').find('option:selected').text();
		}
		else
		{
			var item='Not Selected';
		}
		
	$('#supplier').text(supplier);
	$('#store').text(store);
	$('#item').text(item);
	$('#from').text($('#Storein_from_date').val());
	$('#to').text($('#Storein_to_date').val());
	//}
	//else
	//{
		
	//}
});
");
?>
<div id="print" style="display:none;">
<table id='daterange'>
<tr>
<th>Supp:</th><td><label id='supplier'></label></td>
<th>Store:</th><td><label id='store'></label></td>
<th>Item:</th><td><label id='item'></label></td>
<th>From:</th><td><label id='from'></label></td>
<th>To:</th><td><label id='to'></label></td>
</tr>
</table>
<div id="all" style="display:none;">All Recorded Sale</div>
</div>


<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:block">
	<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php 

$this->widget('ext.groupgridview.BootGroupGridView',array(
'id'=>'storein-grid',
'type'=>'bordered',
'dataProvider'=>$model->search(),
'mergeColumns' => ('pr_id'),
//'filter'=>$model,
'columns'=>array(
		//'id',
		//'pr_id',
		array('header'=>'Pr ID','name'=>'pr_id','value'=>'$data->pr_id','visible'=>true),
		array('header'=>'Store','name'=>'pr_id','value'=>'Store::model()->getname($data->pr->store_id)'),
		array('header'=>'Supplier','name'=>'pr_id','value'=>'Supplier::model()->getname($data->pr->supplier_id)'),
		array('header'=>'Date','name'=>'pr_id','value'=>'PurchaseRequisition::model()->getprdate($data->pr->id)'),
	    array('header'=>'Item','name'=>'inventoryitem_id','value'=>'$data->inventoryitem->name'),
		//'quantity',
		array('header'=>'Qty','name'=>'quantity','value'=>'$data->quantity', 'footer'=>$model->totalQty($model->provider(), $model->provider2())),
		
		 //'pr.store_id',
		 //array('header'=>'Store','name'=>'pr.store_id','value'=>'$data->pr->store_id'),
		//array('header'=>'Store','name'=>'pr_id','value'=>'$data->pr->store_id'),
		//'purchrate',
		array('header'=>'Purchase Rate','name'=>'purchrate','value'=>'$data->purchrate', 'footer'=>$model->totalPurchase($model->provider(), $model->provider2())),
		
		//'salerate',
		array('header'=>'Sale Rate','name'=>'salerate','value'=>'$data->salerate', 'footer'=>$model->totalSale($model->provider(), $model->provider2())),
		
		
		//'quantity',
		
		//'scheme',
		//'discount',
		/*
		
		'store_id',
		*/
/*array(
'class'=>'bootstrap.widgets.TbButtonColumn',
),*/
),
)); ?>
