<?php
$this->breadcrumbs=array(
	'Storeins'=>array('index'),
	$model->id,
);

$this->menu=array(
array('label'=>'List Storein','url'=>array('index')),
array('label'=>'Create Storein','url'=>array('create')),
array('label'=>'Update Storein','url'=>array('update','id'=>$model->id)),
array('label'=>'Delete Storein','url'=>'#','linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
array('label'=>'Manage Storein','url'=>array('admin')),
);
?>

<h1>View Storein #<?php echo $model->id; ?></h1>

<?php $this->widget('bootstrap.widgets.TbDetailView',array(
'data'=>$model,
'attributes'=>array(
		'id',
		'quantity',
		'purchrate',
		'salerate',
		'scheme',
		'discount',
		'inventoryitem_id',
		'store_id',
),
)); ?>
