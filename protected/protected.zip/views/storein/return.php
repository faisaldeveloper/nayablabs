<script type="text/javascript">

function stockcheck()
{
	alert("called");
	if($("#stock-value").val()=='')
	{
	 alert("Select Item First");
	 $("#stock-value").val('');
	 	
	 $("#Storein_quantity").val('');
	}
	else
	{
		alert(parseInt($("#Storein_quantity").val()));
		if(parseInt($("#Storein_quantity").val())>parseInt($("#stock-value").val()))
		{
			alert("Given Quantity is greater then Current Outlet Stock");
			$("#Storein_quantity").val('');
		}
		
	}
	
}
</script>
<div id="formResult"></div>

<div style="padding-bottom:10px;">
<?php
if(Yii::app()->user->hasState('store'))
{
	$store_id=Yii::app()->user->getState('store');
	

}
?>
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Stock Return Info:',
    )
    );

?>

</div>

<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'stock-transfer-form',
	'enableAjaxValidation'=>true,
)); ?>

<!--<p class="help-block">Fields with <span class="required">*</span> are required.</p>
-->
<?php echo $form->errorSummary($stock_transfer); ?>

     <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($stock_transfer,'s_t_no',array('class'=>'span2','maxlength'=>20)); ?>
    </div>
    <div style="float:left; padding-right:10px">
    <?php //echo $form->textFieldRow($stock_transfer,'t_o_no',array('class'=>'span2','maxlength'=>20)); ?>
     </div>
     
      <div style="float:left; padding-right:10px">
    <?php echo $form->datepickerRow(
      $stock_transfer,
      'transfer_date',
     array(
    'options' => array('language' => 'es','width'=>'100px','format'=>'yyyy-mm-dd'),
    //'hint' => 'Click inside! This is a super cool date field.',
    'prepend' => '<i class="icon-calendar"></i>'
    )
    ); ?>
     </div>
    
    
     <div style="float:left; padding-right:10px">
     <?php if($store_id==''){ ?>
     <?php echo $form->labelEx($stock_transfer,'To Store'); ?>
     <?php echo $form->dropDownList($stock_transfer,'store_id',CHtml::listData(Store::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Store:')); 
	 }
		else
		{
			echo $form->hiddenField($stock_transfer,'store_id',array('value'=>$store_id));
		}
	 
	 ?>
     </div>
     <div style="float:left; padding-right:10px">
     <?php echo $form->labelEx($stock_transfer,'From Outlet');?>
     <?php echo $form->dropDownList($stock_transfer,'outlet_id',CHtml::listData(Outlet::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Outlet:','ajax' => array(
'type'=>'POST', //request type
'url'=>CController::createUrl('outlet/Getsections'), //url to call.
//Style: CController::createUrl('currentController/methodToCall')
'update'=>'#StockTransfer_section_id', //selector to update
'data'=>array('outlet_id'=>'js:this.value')
//leave out the data key to pass all form values through
))); ?>
     </div>
    <div style="float:left; padding-right:10px">
     
     <?php echo $form->dropDownListRow($stock_transfer,'section_id',CHtml::listData(Section::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Section:')); ?>
     </div>
	<?php //echo $form->textFieldRow($model,'transfer_date',array('class'=>'span5')); ?>

	<?php //echo $form->textFieldRow($model,'enter_date',array('class'=>'span5')); ?>
    <?php echo $form->hiddenField($stock_transfer,'enter_date',array('class'=>'span5','value'=>date('Y-m-d H:i:s'))); ?>
	<?php //echo $form->textFieldRow($model,'s_t_no',array('class'=>'span5','maxlength'=>50)); ?>

	<?php //echo $form->textFieldRow($model,'supplier_id',array('class'=>'span5')); ?>

	<?php //echo $form->textFieldRow($model,'store_id',array('class'=>'span5')); ?>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textAreaRow($stock_transfer,'remarks',array('class'=>'span7','maxlength'=>300)); ?>
    </div>
   
	<?php echo $form->hiddenField($stock_transfer,'enter_by',array('class'=>'span5','value'=>1)); ?>

	<?php //echo $form->textFieldRow($model,'t_o_no',array('class'=>'span5','maxlength'=>50)); ?>

	<?php echo $form->hiddenField($stock_transfer,'transfer_type',array('class'=>'span5','value'=>2)); ?>
<?php echo $form->hiddenField($stock_transfer,'id',array('class'=>'span5')); ?>

	 <div style="float:left;  margin-top:25px;">
	<?php /*$this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'primary',
			'label'=>$purchase_requisition->isNewRecord ? 'Create' : 'Save',
		));*/ ?>
        <?php echo CHtml::ajaxSubmitButton('Update',CHtml::normalizeUrl(array('stocktransfer/ajaxupdate','render'=>true)),
                 array(
                     'dataType'=>'json',
                     'type'=>'post',
                     'success'=>'function(data) {
                         $("#AjaxLoader").hide();  
                        if(data.status=="success"){
                         $("#formResult").html("form Updated successfully.");
                        // $("#stock-transfer-form")[0].reset();
                        }
                         else{
                        $.each(data, function(key, val) {
                        $("#stock-transfer-form #"+key+"_em_").text(val);                                                    
                        $("#stock-transfer-form #"+key+"_em_").show();
                        });
                        }       
                    }',                    
                     'beforeSend'=>'function(){                        
                           $("#AjaxLoader").show();
                      }'
                     ),array('id'=>'mybtn','class'=>"btn btn-inverse")); ?>



</div>
 
<?php $this->endWidget(); ?>
<div style="clear:both"></div>
<hr>
<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Add Items to be Return:',
    )
    );

?>
</div>

<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'storein-form',
	'enableClientValidation' => true,
    'clientOptions'=> array('validateOnSubmit'=>true),
	//'enableAjaxValidation'=>false,
        //'action'=>$this->createUrl('storein/ajaxcreate'),
       // 'enableClientValidation'=>true,

)); ?>

<!--<p class="help-block">Fields with <span class="required">*</span> are required.</p>
-->
<?php echo $form->errorSummary($model); ?>
    <div style="float:left; padding-right:10px">
    <?php echo $form->dropDownListRow($model,'category',CHtml::listData(Category::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Category:','ajax' => array(
'type'=>'POST', //request type
'url'=>CController::createUrl('storein/Getitem'), //url to call.
//Style: CController::createUrl('currentController/methodToCall')
'update'=>'#Storeout_inventoryitem_id', //selector to update
'data'=>array('category_id'=>'js:this.value')
//leave out the data key to pass all form values through
))); ?>
    </div>
    
    
    
    <div style="float:left; padding-right:10px">
    <?php echo $form->dropDownListRow($model,'inventoryitem_id',CHtml::listData(Inventoryitem::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Item:','ajax' => array(
'type'=>'POST', //request type
'url'=>CController::createUrl('storein/OutletStock'), //url to call.
//Style: CController::createUrl('currentController/methodToCall')
//'update'=>'#Storein_code', //selector to update
'data'=>array('id'=>'js:this.value','store_id'=>$stock_transfer->outlet_id),
'dataType'=>'json',
'success'=>'function(data){
	//alert(data.last_purchase);
	$("#stock-value").val(data.stock);
	$("#stock").text("Stock:"+data.stock+" "+data.unit);
	$("#Storein_code").val(data.code);
	$("#Storein_purchrate").val(data.last_purchase);
	
	
}'
//leave out the data key to pass all form values through
))); ?>
    <?php //echo $form->hiddenField($model,'outlet_id',array('class'=>'span5','value'=>$store_stock->outlet_id)); ?>
    </div>
    <div style="float:left; padding-right:10px">
    <?php echo $form->textFieldRow($model,'code',array('class'=>'span2','ajax' => array(
                        'type' =>'POST',
                        'url' => CController::createUrl('storein/Getname'),
						'data'=>array('code'=>'js:this.value'),
                        //'update' => '#townlist',
                        'dataType' => 'json',
						'success'=>'function(data){
	alert(data.inventoryitem_id);
	$("#Storeout_inventoryitem_id").val(data.inventoryitem_id);
	$("#Storeout_category").val(data.category_id);
	$("#Storeout_purchrate").val(data.last_purchase);
}'
                ))); ?>
       </div>
        <div style="float:left; padding-right:10px">
       <?php echo $form->textFieldRow($model,'quantity',array('class'=>'span2','onchange'=>'calcost()','onblur'=>'stockcheck()')); ?>
       </div>
       <div style="float:left; padding-right:10px" >
       <label id="stock" style="padding-top:28px; color:#933"></label>
       <input type="hidden" id="stock-value" />
       </div>
    <?php echo $form->hiddenField($model,'store_id',array('class'=>'span5','value'=>$stock_transfer->store_id)); ?>
     <?php echo $form->hiddenField($model,'outlet_id',array('class'=>'span5','value'=>$stock_transfer->outlet_id)); ?>
    <?php echo $form->hiddenField($model,'stocktransfer_id',array('class'=>'span5','value'=>$stock_transfer->id)); ?>
    <?php echo $form->hiddenField($model,'section_id',array('class'=>'span5','value'=>$stock_transfer->section_id)); ?>
    <?php echo $form->hiddenField($model,'enter_by',array('class'=>'span5','value'=>1)); ?>
    
    <div style="float:left; text-align:center; margin-top:25px;">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$model->isNewRecord ? 'Save' : 'Update',
		)); ?>
        <?php $this->widget('bootstrap.widgets.TbButton', array(
                        'buttonType'=>'reset',
                        'type'=>'inverse',
                        'label'=>'Reset',
                )); ?>

        <?php /*echo CHtml::ajaxSubmitButton('Create',CHtml::normalizeUrl(array('storein/ajaxcreate','render'=>true)),
                 array(
                     'dataType'=>'json',
                     'type'=>'post',
                     'success'=>'function(data) {
                        /// $("#AjaxLoader").hide();  
                        if(data.status=="success"){
							
                         $("#item").html("form Updated successfully.");
                         $("#storein-form")[0].reset();
						  $.fn.yiiGridView.update("storein-grid");
						 
						
						 alert("Grid refreshed");
                        }
                         else{
                        $.each(data, function(key, val) {
                        $("#storein-form #"+key+"_em_").text(val);                                                    
                        $("#storein-form #"+key+"_em_").show();
                        });
                        }       
                    }',                    
                     'beforeSend'=>'function(){                        
                           $("#AjaxLoader").show();
                      }'
                     ),array('id'=>'mybtn','class'=>'primary'));*/ ?>


</div>
    <div style="clear:both;"></div>
	<?php //echo $form->textFieldRow($model,'inventoryitem_id',array('class'=>'span5')); ?>
   
	<?php //echo $form->textFieldRow($model,'supplier_id',array('class'=>'span5')); ?>
   
	

	<?php //echo $form->textAreaRow($model,'remarks',array('class'=>'span5','maxlength'=>200)); ?>

	<?php //echo $form->textFieldRow($model,'enter_by',array('class'=>'span5')); ?>


	<?php /* $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'primary',
			'label'=>$model->isNewRecord ? 'Create' : 'Save',
		));*/ ?>

<?php // $this->endWidget(); ?>

<?php $this->endWidget(); ?>
<hr />

<div >
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'All Added Items:',
    )
    );

?>
</div>
<?php
$grid=new Storeout;

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('storeout-grid', {
data: $(this).serialize()
});
return false;
});
");
?>



<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:none">
	<?php // $this->renderPartial('_search',array(
	//'model'=>$grid,
//)); ?>
</div><!-- search-form -->
<?php $buttons="";
$datetime=$stock_transfer->enter_date;
$dt = strtotime($datetime); 
$date=date("Y-m-d", $dt);
if($date==date('Y-m-d'))
$buttons="{update}{delete}";
//echo $buttons;
?>

<?php
$grid=new Storein('returnstoresearch');
 $this->widget('bootstrap.widgets.TbGridView',array(
'type'=>'bordered',
'id'=>'storein-grid',
'dataProvider'=>$grid->returnstoresearch($stock_transfer->id),
//'filter'=>$grid,
'columns'=>array(
		//'id',
		array(
            'header'=>'Sr#',
            'value'=>'$this->grid->dataProvider->pagination->currentPage * $this->grid->dataProvider->pagination->pageSize + ($row+1)',
        ),
		array('header'=>'Item','name'=>'inventoryitem_id','value'=>'$data->inventoryitem->name'),
		array('header'=>'Quantity','name'=>'quantity','value'=>'Storein::model()->quantity($data->id)','filter'=>false),
		//'dos',
		
		//'inventoryitem_id',
		//array('header'=>'Store','name'=>'store_id','value'=>'$data->store->name'),
		//array('header'=>'Outlet','name'=>'outlet_id','value'=>'$data->outlet->name'),
		//'outlet_id',
		//'store_id',
		/*
		'remarks',
		'enter_by',
		'stock_transfer_id',
		*/
array(
'class'=>'bootstrap.widgets.TbButtonColumn',
'template'=>$buttons,
'buttons'=>array
    (
'delete' => array
(
    'label'=>'Delete',     //Text label of the button.
    'imageUrl'=>Yii::app()->request->baseUrl.'/images/email.png',
            'url'=>'Yii::app()->createUrl("Storein/ReturnStoreDel", array("id"=>$data->id))',
)
),
),
))); ?>