<div class="view">

		<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id),array('view','id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('quantity')); ?>:</b>
	<?php echo CHtml::encode($data->quantity); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('purchrate')); ?>:</b>
	<?php echo CHtml::encode($data->purchrate); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('salerate')); ?>:</b>
	<?php echo CHtml::encode($data->salerate); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('scheme')); ?>:</b>
	<?php echo CHtml::encode($data->scheme); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('discount')); ?>:</b>
	<?php echo CHtml::encode($data->discount); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('inventoryitem_id')); ?>:</b>
	<?php echo CHtml::encode($data->inventoryitem_id); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('store_id')); ?>:</b>
	<?php echo CHtml::encode($data->store_id); ?>
	<br />

	*/ ?>

</div>