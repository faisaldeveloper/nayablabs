<?php
$this->breadcrumbs=array(
	'Storeins'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List Storein','url'=>array('index')),
	array('label'=>'Create Storein','url'=>array('create')),
	array('label'=>'View Storein','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage Storein','url'=>array('admin')),
	);
	?>

	<h1>Update Storein <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form',array('model'=>$model)); ?>