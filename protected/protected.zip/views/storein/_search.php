<?php
if(Yii::app()->user->hasState('store'))
{
	$store_id=Yii::app()->user->getState('store');
	

}
?>
<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
'id'=>'report',
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>
        <div style="float:left; padding-right:10px">
        <?php //echo $form->textFieldRow($model,'supplier',array('class'=>'span2')); ?>
        <?php echo $form->dropDownListRow($model,'supplier',CHtml::listData(Supplier::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Select Supplier:')); ?>
        </div>
        <div style="float:left; padding-right:10px">
        <?php if($store_id==''){ ?>
        <?php //echo $form->textFieldRow($model,'store',array('class'=>'span2')); ?>
        <?php echo $form->dropDownListRow($model,'store',CHtml::listData(Store::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Select Store:')); 
		}
		else
		{
			echo $form->hiddenField($model,'store',array('value'=>$store_id));
		}
		?>
        </div>
         <div style="float:left; padding-right:10px">
        <?php //echo $form->textFieldRow($model,'store',array('class'=>'span2')); ?>
        <?php echo $form->dropDownListRow($model,'inventoryitem_id',CHtml::listData(Inventoryitem::model()->findAll(),'name','name'),array('class'=>'span2','prompt'=>'Select Item:')); ?>
        </div>
        <div style="clear:both;"></div>
        <div style="float:left; padding-right:10px">
        
        <?php //echo $form->textFieldRow($model,'from_date',array('class'=>'span2')); ?>
         <?php echo $form->datepickerRow(
      $model,
      'from_date',
     array(
    'options' => array('language' => 'es','width'=>'80px','format'=>'yyyy-mm-dd'),
    //'hint' => 'Click inside! This is a super cool date field.',
    'prepend' => '<i class="icon-calendar"></i>'
    )
    ); ?>
        </div>
        <div style="float:left; padding-right:10px">
        <?php //echo $form->textFieldRow($model,'to_date',array('class'=>'span2')); ?>
         <?php echo $form->datepickerRow(
      $model,
      'to_date',
     array(
    'options' => array('language' => 'es','width'=>'80px','format'=>'yyyy-mm-dd'),
    //'hint' => 'Click inside! This is a super cool date field.',
    'prepend' => '<i class="icon-calendar"></i>'
    )
    ); ?>
        </div>
        <div style="float:left; padding-right:10px">
        <?php //echo $form->textFieldRow($model,'enter_by',array('class'=>'span2')); ?>
        </div>
		<?php //echo $form->textFieldRow($model,'id',array('class'=>'span5')); ?>

		<?php //echo $form->textFieldRow($model,'quantity',array('class'=>'span5')); ?>

		<?php //echo $form->textFieldRow($model,'purchrate',array('class'=>'span5')); ?>

		<?php //echo $form->textFieldRow($model,'salerate',array('class'=>'span5')); ?>

		<?php //echo $form->textFieldRow($model,'scheme',array('class'=>'span5','maxlength'=>10)); ?>

		<?php //echo $form->textFieldRow($model,'discount',array('class'=>'span5')); ?>

		<?php //echo $form->textFieldRow($model,'inventoryitem_id',array('class'=>'span5')); ?>

		<?php //echo $form->textFieldRow($model,'store_id',array('class'=>'span5')); ?>
<div style="clear:both;"></div>
	<div style="float:left; margin-top:25px">
		<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType' => 'submit',
			'type'=>'inverse',
			'label'=>'Search',
		)); ?>
	</div>
<div style="clear:both;"></div>
<?php $this->endWidget(); ?>
