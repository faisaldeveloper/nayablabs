<?php
$this->breadcrumbs=array(
	'Storeins',
);

$this->menu=array(
array('label'=>'Create Storein','url'=>array('create')),
array('label'=>'Manage Storein','url'=>array('admin')),
);
?>

<h1>Storeins</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
