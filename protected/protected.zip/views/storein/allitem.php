<?php
/*$this->breadcrumbs=array(
	'Storeins'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List Storein','url'=>array('index')),
array('label'=>'Create Storein','url'=>array('create')),
);*/

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('storein-grid', {
data: $(this).serialize()
});
return false;
});
");
?>

<?php

$storein=new Storein;

?>


<?php echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:none">
	<?php $this->renderPartial('_search',array(
	'model'=>$grid,
)); ?>
</div><!-- search-form -->

<?php $this->widget('bootstrap.widgets.TbGridView',array(
'id'=>'storein-grid',
'dataProvider'=>$grid->storesearch($prid),
'ajaxUpdate'=>true, 
'filter'=>$grid,
'columns'=>array(
		'id',
		'quantity',
		'purchrate',
		'salerate',
		'scheme',
		'discount',
		/*
		'inventoryitem_id',
		'store_id',
		*/
array(
'class'=>'bootstrap.widgets.TbButtonColumn',
),
),
)); ?>
