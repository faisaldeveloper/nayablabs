


<!--/////////////////-->

<div id="item"></div>

<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'storein-form',
	'enableAjaxValidation'=>true,
        'action'=>$this->createUrl('storein/ajaxcreate'),
        'enableClientValidation'=>true,

)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($model); ?>
    <div style="float:left; padding-right:10px">
    <?php echo $form->dropDownListRow($model,'category',CHtml::listData(Category::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Category:','ajax' => array(
'type'=>'POST', //request type
'url'=>CController::createUrl('storein/Getitem'), //url to call.
//Style: CController::createUrl('currentController/methodToCall')
'update'=>'#Storein_inventoryitem_id', //selector to update
'data'=>array('category_id'=>'js:this.value')
//leave out the data key to pass all form values through
))); ?>
    </div>
    
    
    
    <div style="float:left; padding-right:10px">
    <?php echo $form->dropDownListRow($model,'inventoryitem_id',CHtml::listData(Inventoryitem::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Item:','ajax' => array(
'type'=>'POST', //request type
'url'=>CController::createUrl('storein/Getcode'), //url to call.
//Style: CController::createUrl('currentController/methodToCall')
//'update'=>'#Storein_code', //selector to update
'data'=>array('id'=>'js:this.value'),
'success'=>'function(data){
	
	$("#Storein_code").val(data)
}'
//leave out the data key to pass all form values through
))); ?>
    </div>
    <div style="float:left; padding-right:10px">
    <?php echo $form->textFieldRow($model,'code',array('class'=>'span2','ajax' => array(
                        'type' =>'POST',
                        'url' => CController::createUrl('storein/Getname'),
						'data'=>array('code'=>'js:this.value'),
                        //'update' => '#townlist',
                        'dataType' => 'json',
						'success'=>'function(data){
	alert(data.inventoryitem_id);
	$("#Storein_inventoryitem_id").val(data.inventoryitem_id);
	$("#Storein_category").val(data.category_id);
}'
                ))); ?>
       </div>
        <div style="float:left; padding-right:10px">
       <?php echo $form->textFieldRow($model,'quantity',array('class'=>'span2')); ?>
       </div>
        <div style="clear:both;"></div>
     <?php //echo $form->dropDownListRow($model,'supplier_id',CHtml::listData(Supplier::model()->findAll(),'id','name'),array('class'=>'span3','prompt'=>'Select a Supplier:')); ?>
      <?php // echo $form->dropDownListRow($model,'store_id',CHtml::listData(Store::model()->findAll(),'id','name'),array('class'=>'span3','prompt'=>'Select a Store:')); ?>
	
      <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'purchrate',array('class'=>'span2')); ?>
      </div>
       <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'salerate',array('class'=>'span2')); ?>
      </div>
	<?php //echo $form->hiddenfield($model,'dop',array('value'=>date('Y-m-d H:i:s'))); ?>
      <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'discount',array('class'=>'span2')); ?>
    </div>
    <?php echo $form->hiddenField($model,'store_id',array('class'=>'span5','value'=>$purchase_requisition->store_id)); ?>
    <?php echo $form->hiddenField($model,'pr_id',array('class'=>'span5','value'=>$purchase_requisition->id)); ?>
    <div style="float:left; text-align:center; margin-top:31px;">
	<?php /*$this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'primary',
			'label'=>$purchase_requisition->isNewRecord ? 'Create' : 'Save',
		));*/ ?>
        <?php echo CHtml::ajaxSubmitButton('Create',CHtml::normalizeUrl(array('storein/ajaxcreate','render'=>true)),
                 array(
                     'dataType'=>'json',
                     'type'=>'post',
                     'success'=>'function(data) {
                        /// $("#AjaxLoader").hide();  
                        if(data.status=="success"){
							
                         $("#item").html("form Updated successfully.");
                         $("#storein-form")[0].reset();
						  $.fn.yiiGridView.update("storein-grid");
						 
						
						 alert("Grid refreshed");
                        }
                         else{
                        $.each(data, function(key, val) {
                        $("#storein-form #"+key+"_em_").text(val);                                                    
                        $("#storein-form #"+key+"_em_").show();
                        });
                        }       
                    }',                    
                     'beforeSend'=>'function(){                        
                           $("#AjaxLoader").show();
                      }'
                     ),array('id'=>'mybtn','class'=>'primary')); ?>


</div>
    <div style="clear:both;"></div>
	<?php //echo $form->textFieldRow($model,'inventoryitem_id',array('class'=>'span5')); ?>
   
	<?php //echo $form->textFieldRow($model,'supplier_id',array('class'=>'span5')); ?>
   
	

	<?php //echo $form->textAreaRow($model,'remarks',array('class'=>'span5','maxlength'=>200)); ?>

	<?php //echo $form->textFieldRow($model,'enter_by',array('class'=>'span5')); ?>


	<?php /* $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'primary',
			'label'=>$model->isNewRecord ? 'Create' : 'Save',
		));*/ ?>

<?php $this->endWidget(); ?>




