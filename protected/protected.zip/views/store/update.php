<?php
$this->breadcrumbs=array(
	'Stores'=>array('index'),
	$store->name=>array('view','id'=>$store->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List Store','url'=>array('index')),
	array('label'=>'Create Store','url'=>array('create')),
	array('label'=>'View Store','url'=>array('view','id'=>$store->id)),
	array('label'=>'Manage Store','url'=>array('admin')),
	);
	?>

	<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Update Store:',
    )
    );

?>
</div>

<?php echo $this->renderPartial('_form',array('store'=>$store)); ?>