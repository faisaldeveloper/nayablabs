<?php
$this->breadcrumbs=array(
	'Outletins'=>array('index'),
	$model->id,
);

$this->menu=array(
array('label'=>'List Outletin','url'=>array('index')),
array('label'=>'Create Outletin','url'=>array('create')),
array('label'=>'Update Outletin','url'=>array('update','id'=>$model->id)),
array('label'=>'Delete Outletin','url'=>'#','linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
array('label'=>'Manage Outletin','url'=>array('admin')),
);
?>

<h1>View Outletin #<?php echo $model->id; ?></h1>

<?php $this->widget('bootstrap.widgets.TbDetailView',array(
'data'=>$model,
'attributes'=>array(
		'id',
		'outlet_id',
		'inventoryitem_id',
		'doi',
		'quantity',
		'store_id',
		'remarks',
		'enter_by',
		'stock_transfer_id',
),
)); ?>
