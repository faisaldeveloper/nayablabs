<?php
$this->breadcrumbs=array(
	'Outletins',
);

$this->menu=array(
array('label'=>'Create Outletin','url'=>array('create')),
array('label'=>'Manage Outletin','url'=>array('admin')),
);
?>

<h1>Outletins</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
