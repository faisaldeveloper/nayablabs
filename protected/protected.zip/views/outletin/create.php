<?php
$this->breadcrumbs=array(
	'Outletins'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List Outletin','url'=>array('index')),
array('label'=>'Manage Outletin','url'=>array('admin')),
);
?>

<h1>Create Outletin</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>