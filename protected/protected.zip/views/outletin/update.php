<?php
$this->breadcrumbs=array(
	'Outletins'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List Outletin','url'=>array('index')),
	array('label'=>'Create Outletin','url'=>array('create')),
	array('label'=>'View Outletin','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage Outletin','url'=>array('admin')),
	);
	?>

	<h1>Update Outletin <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form',array('model'=>$model)); ?>