<div style="padding-bottom:10px;">
<?php 
/*echo 'user:'.Yii::app()->user->id;
echo 'store:'.Yii::app()->user->getState('store');
echo 'outlet:'.Yii::app()->user->getState('outlet');
echo 'section:'.Yii::app()->user->getState('section');*/
?>
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Track Outlet In:',
    )
    );

?>
</div>
<?php
$this->breadcrumbs=array(
	'Outletins'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List Outletin','url'=>array('index')),
array('label'=>'Create Outletin','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('outletin-grid', {
data: $(this).serialize()
});
return false;
});
");
?>



<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:block">
	<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->
<?php 
$setting=SystemSettings::model()->find();
if(count($setting)>0 && $setting->store==1)
{
$store=true;
$outlet=true;
}
else if(count($setting)>0 && $setting->store==2)
{
$store=false;
$outlet=false;
}
?>
<?php $this->widget('bootstrap.widgets.TbGridView',array(
'id'=>'outletin-grid',
'type'=>'bordered',
'dataProvider'=>$model->search(),
//'filter'=>$model,
'columns'=>array(
		'id',
		//'outlet_id',
		array('header'=>'From Store','name'=>'store_id','value'=>'Store::model()->getname($data->store_id)','visible'=>$store),
		array('header'=>'To Outlet','name'=>'outlet_id','value'=>'$data->outlet->name','visible'=>$outlet),
		array('header'=>'Section','name'=>'section_id','value'=>'$data->section->name'),
		array('header'=>'Item','name'=>'inventoryitem_id','value'=>'$data->inventoryitem->name'),
		//'inventoryitem_id',
		array('header'=>'Date Of In', 'name'=>'doi','value'=>'$data->doi'),
		//'doi',
		array('header'=>'Quantity', 'name'=>'quantity','value'=>'Outletin::model()->quantity($data->id)'),
		//'quantity',
		//'store_id',
		/*
		'remarks',
		'enter_by',
		'stock_transfer_id',
		*/
/*array(
'class'=>'bootstrap.widgets.TbButtonColumn',
),*/
),
)); ?>
