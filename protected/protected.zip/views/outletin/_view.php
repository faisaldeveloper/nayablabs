<div class="view">

		<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id),array('view','id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('outlet_id')); ?>:</b>
	<?php echo CHtml::encode($data->outlet_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('inventoryitem_id')); ?>:</b>
	<?php echo CHtml::encode($data->inventoryitem_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('doi')); ?>:</b>
	<?php echo CHtml::encode($data->doi); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('quantity')); ?>:</b>
	<?php echo CHtml::encode($data->quantity); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('store_id')); ?>:</b>
	<?php echo CHtml::encode($data->store_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('remarks')); ?>:</b>
	<?php echo CHtml::encode($data->remarks); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('enter_by')); ?>:</b>
	<?php echo CHtml::encode($data->enter_by); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('stock_transfer_id')); ?>:</b>
	<?php echo CHtml::encode($data->stock_transfer_id); ?>
	<br />

	*/ ?>

</div>