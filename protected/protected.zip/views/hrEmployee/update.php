<?php
$this->breadcrumbs=array(
	'Hr Employees'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List HrEmployee','url'=>array('index')),
	array('label'=>'Create HrEmployee','url'=>array('create')),
	array('label'=>'View HrEmployee','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage HrEmployee','url'=>array('admin')),
	);
	?>

	<h1> <?php //echo $model->id; ?></h1>
    <div style="padding-bottom:10px;">
    <?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Update Employee:',
    )
    );

?>
</div>
<?php echo $this->renderPartial('_form',array('employee' => $employee,'account'=>$account,'employee_earning'=>$employee_earning,'employee_deduction'=>$employee_deduction)); ?>