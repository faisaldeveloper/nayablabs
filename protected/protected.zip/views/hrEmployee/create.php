<?php
$this->breadcrumbs=array(
	'Hr Employees'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List HrEmployee','url'=>array('index')),
array('label'=>'Manage HrEmployee','url'=>array('admin')),
);
?>

<h1>Create HrEmployee</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>