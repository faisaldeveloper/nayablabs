

<script type="text/javascript">

function Createnew(){
	document.getElementById("hr-employee-form").reset();
	
	document.getElementById("form-create").style.display="block";
	document.getElementById("grid").style.display="none";
}

function grid(){
	
	document.getElementById("form-create").style.display="none";
	document.getElementById("grid").style.display="block";
}
function calGrossPay(myid){
	var basic_salary=parseFloat($('#HrEmployee_salary').val());
	
	if(myid=='HrEmployeeEarning_medical')
	{
		//alert($('#'+myid).val());
		var gross=parseFloat($('#'+myid).val())+parseFloat($('#HrEmployeeEarning_house_rent').val())+parseFloat($('#HrEmployeeEarning_over_time').val())+parseFloat($('#HrEmployeeEarning_Conveyance_Allowance').val())+parseFloat($('#HrEmployeeEarning_other_incentive').val())+parseFloat($('#HrEmployeeEarning_sp_allownces').val())+parseFloat($('#HrEmployeeEarning_bonus').val())+parseFloat(basic_salary);
		$('#HrEmployeeEarning_gross_pay').val(parseFloat(gross));
	}
	if(myid=='HrEmployee_salary')
	{
		//alert("salary");
		var gross=parseFloat($('#HrEmployeeEarning_house_rent').val())+parseFloat($('#HrEmployeeEarning_over_time').val())+parseFloat($('#HrEmployeeEarning_Conveyance_Allowance').val())+parseFloat($('#HrEmployeeEarning_other_incentive').val())+parseFloat($('#HrEmployeeEarning_sp_allownces').val())+parseFloat($('#HrEmployeeEarning_bonus').val())+parseFloat(basic_salary)+parseFloat($('#HrEmployeeEarning_medical').val());
		$('#HrEmployeeEarning_gross_pay').val(parseFloat(gross));
	}
	if(myid=='HrEmployeeEarning_house_rent')
	{
		//alert($('#'+myid).val());
		var gross=parseFloat($('#'+myid).val())+parseFloat($('#HrEmployeeEarning_medical').val())+parseFloat($('#HrEmployeeEarning_over_time').val())+parseFloat($('#HrEmployeeEarning_Conveyance_Allowance').val())+parseFloat($('#HrEmployeeEarning_other_incentive').val())+parseFloat($('#HrEmployeeEarning_sp_allownces').val())+parseFloat($('#HrEmployeeEarning_bonus').val())+parseFloat(basic_salary);
		$('#HrEmployeeEarning_gross_pay').val(parseFloat(gross));
	}
	if(myid=='HrEmployeeEarning_over_time')
	{
		//alert($('#'+myid).val());
		var gross=parseFloat($('#'+myid).val())+parseFloat($('#HrEmployeeEarning_house_rent').val())+parseFloat($('#HrEmployeeEarning_medical').val())+parseFloat($('#HrEmployeeEarning_Conveyance_Allowance').val())+parseFloat($('#HrEmployeeEarning_other_incentive').val())+parseFloat($('#HrEmployeeEarning_sp_allownces').val())+parseFloat($('#HrEmployeeEarning_bonus').val())+parseFloat(basic_salary);
		$('#HrEmployeeEarning_gross_pay').val(parseFloat(gross));
	}
	if(myid=='HrEmployeeEarning_Conveyance_Allowance')
	{
		//alert($('#'+myid).val());
		var gross=parseFloat($('#'+myid).val())+parseFloat($('#HrEmployeeEarning_house_rent').val())+parseFloat($('#HrEmployeeEarning_over_time').val())+parseFloat($('#HrEmployeeEarning_medical').val())+parseFloat($('#HrEmployeeEarning_other_incentive').val())+parseFloat($('#HrEmployeeEarning_sp_allownces').val())+parseFloat($('#HrEmployeeEarning_bonus').val())+parseFloat(basic_salary);
		
		$('#HrEmployeeEarning_gross_pay').val(parseFloat(gross));
	}
	if(myid=='HrEmployeeEarning_other_incentive')
	{
		//alert($('#'+myid).val());
		var gross=parseFloat($('#'+myid).val())+parseFloat($('#HrEmployeeEarning_house_rent').val())+parseFloat($('#HrEmployeeEarning_over_time').val())+parseFloat($('#HrEmployeeEarning_Conveyance_Allowance').val())+parseFloat($('#HrEmployeeEarning_medical').val())+parseFloat($('#HrEmployeeEarning_sp_allownces').val())+parseFloat($('#HrEmployeeEarning_bonus').val())+parseFloat(basic_salary);
		$('#HrEmployeeEarning_gross_pay').val(parseFloat(gross));
	}
	if(myid=='HrEmployeeEarning_sp_allownces')
	{
		//alert($('#'+myid).val());
		var gross=parseFloat($('#'+myid).val())+parseFloat($('#HrEmployeeEarning_house_rent').val())+parseFloat($('#HrEmployeeEarning_over_time').val())+parseFloat($('#HrEmployeeEarning_Conveyance_Allowance').val())+parseFloat($('#HrEmployeeEarning_other_incentive').val())+parseFloat($('#HrEmployeeEarning_medical').val())+parseFloat($('#HrEmployeeEarning_bonus').val())+parseFloat(basic_salary);
		$('#HrEmployeeEarning_gross_pay').val(parseFloat(gross));
	}
	if(myid=='HrEmployeeEarning_bonus')
	{
		//alert($('#'+myid).val());
		var gross=parseFloat($('#'+myid).val())+parseFloat($('#HrEmployeeEarning_house_rent').val())+parseFloat($('#HrEmployeeEarning_over_time').val())+parseFloat($('#HrEmployeeEarning_Conveyance_Allowance').val())+parseFloat($('#HrEmployeeEarning_other_incentive').val())+parseFloat($('#HrEmployeeEarning_sp_allownces').val())+parseFloat($('#HrEmployeeEarning_medical').val())+parseFloat(basic_salary);
		$('#HrEmployeeEarning_gross_pay').val(parseFloat(gross));
	}
}
</script>


<div style="display:none;" id="form-create">
<div style="padding-top:0px; padding-bottom:10px; float:left">
<a href="#" onclick="grid();">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Manage Employees:',
    )
    );

?>

</a>

</div>
<div style=" float:right; margin-right:738px; padding-top:0px; padding-bottom:10px;">
<a href="#" >
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Create new:',
    )
    );

?>
</a>
</div>
<div style="clear:both; padding-bottom:20px;"></div>
<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'hr-employee-form',
	'action'=>$this->createUrl('HrEmployee/admin'),
	'enableAjaxValidation'=>true,
	'enableClientValidation'=>true,
		'clientOptions'=>array(
            'validateOnSubmit'=>true,
        ),
)); ?>


<?php echo $form->errorSummary(array($employee,$account,$employee_deduction,$employee_earning)); ?>
    
    <?php //echo $form->dropDownListRow($leave_type,'designation_id',CHtml::listData(HrDesignation::model()->findAll(),'id','name'),array('class'=>'span2')); ?>
    <div style="float:left; padding-right:10px">
	 <?php echo $form->dropDownListRow($account,'account_group',CHtml::listData(AccountGroups::model()->findAll(),'id','group_name'),array('prompt'=>'Select Class:','class'=>'span2','ajax' => array(
                        'type' =>'POST',
                        'url' => CController::createUrl('AccountChartOfAccount/GetCode'),
						'data'=>array('value'=>'js:this.value'),
                        //'update' => '#townlist',
                        'dataType' => 'json',
						'success'=>'function(data){
	                     // alert("code="+data.code);
						 // $(".add-on").text(data.prepend);
						  $("#AccountChartOfAccount_account_code").val(data.prepend+data.code);
						  $("#hidden_account").val(data.prepend+data.code);
                        }'
                ))); ?>
                <?php echo $form->error($account,'account_group',array('hideErrorMessage'=>true)); ?>
    </div>
    
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($account,'account_code',array('disabled'=>true,'class'=>'span2','maxlength'=>20,'value'=>$account->account_code_2)); ?>
    <?php echo $form->hiddenField($account,'account_code',array('id'=>'hidden_account','class'=>'span2','value'=>$account->account_code_2)); ?>
    <?php echo $form->error($account,'account_code',array('hideErrorMessage'=>true)); ?>
     <?php //echo $form->error($account,'account_code',array('hideErrorMessage'=>true)); ?>
   </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee,'first_name',array('class'=>'span2','maxlength'=>20)); ?>
    <?php echo $form->error($employee,'first_name',array('hideErrorMessage'=>true)); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee,'last_name',array('class'=>'span2','maxlength'=>20)); ?>
    <?php echo $form->error($employee,'last_name',array('hideErrorMessage'=>true)); ?>
    </div>
     <div style="float:left; padding-right:10px">
    <?php echo $form->datepickerRow(
      $employee,
      'dob',
     array(
    'options' => array('language' => 'es','width'=>'100px','format'=>'yyyy-mm-dd'),
    //'hint' => 'Click inside! This is a super cool date field.',
    //'prepend' => '<i class="icon-calendar"></i>'
    )
    ); ?>
    
    <div style="clear:both;"></div>
    <?php echo $form->error($employee,'dob',array('hideErrorMessage'=>true)); ?>
     </div>
      <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee,'email',array('class'=>'span2','maxlength'=>20)); ?>
    </div>
     <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee,'contact_no',array('class'=>'span2','maxlength'=>11)); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->dropDownListRow($employee,'designation_id',CHtml::listData(HrDesignation::model()->findAll(),'id','name'),array('prompt'=>'Select Class:','class'=>'span2','ajax' => array(
                        'type' =>'POST',
                        'url' => CController::createUrl('HrDesignation/GetLeaves'),
						'data'=>array('value'=>'js:this.value'),
                        //'update' => '#townlist',
                        'dataType' => 'json',
						'beforeSend'=>'function(){$("#ajax-loader").show();}',
						'success'=>'function(data){
	                        //alert(data.medical);
							
							$("#HrEmployee_medical_leaves").val(data.medical);
							$("#HrEmployee_casual_leaves").val(data.casual);
							$("#HrEmployee_urgent_leaves").val(data.urgent);
							$("#ajax-loader").hide();
                        }'
                ))); ?>
                <?php echo $form->error($employee,'designation_id',array('hideErrorMessage'=>true)); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee,'salary',array('class'=>'span2','maxlength'=>20,'onchange'=>'calGrossPay(this.id)')); ?>
    <?php echo $form->error($employee,'salary',array('hideErrorMessage'=>true)); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee,'CNIC',array('class'=>'span3','maxlength'=>13)); ?>
    
    </div>
    <div style="clear:both;"></div>
    
    
<div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee,'medical_leaves',array('class'=>'span2','maxlength'=>2)); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee,'casual_leaves',array('class'=>'span2','maxlength'=>2)); ?>
    </div>
    <div style="float:left; padding-right:10px">
    
	<?php echo $form->textFieldrow($employee,'urgent_leaves',array('class'=>'span2','maxlength'=>2,'row'=>1)); ?>
    </div>
     <div style="float:left; padding-right:10px; margin-top:28px; display:none" id="ajax-loader">
     <img src="<?php echo Yii::app()->baseUrl;?>/images/ajax-loader.gif" />
     </div>
     <div style="float:left; padding-right:10px">
    
	<?php echo $form->textFieldrow($employee,'address',array('class'=>'span4','maxlength'=>20,'row'=>1)); ?>
    <?php echo $form->error($employee,'address',array('hideErrorMessage'=>true)); ?>
    </div>
    <div style="float:left; padding-right:10px; margin-top:7px;">
    <?php echo '<span for="label" style="margin-bottom:5px;">Active</span><br />'; ?>
    <?php echo $form->checkBox($employee,'active',array('value'=>1,'uncheckValue'=>0,'checked'=>'checked','style'=>'margin-top:7px;')); ?>
    </div>
    <div style="clear:both;"></div>
    
    
     <div style="display:block;">
      <div style="clear:both;"></div>
    <div style="padding-bottom:10px;">
    <?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Employees Earnings:',
    )
    );

?>
   </div>
   <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_earning,'leave_days',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_earning,'days',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_earning,'advance_salary',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_earning,'gross_pay',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_earning,'medical',array('class'=>'span2','onchange'=>'calGrossPay(this.id)')); ?>
    </div>
    
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_earning,'house_rent',array('class'=>'span2','onchange'=>'calGrossPay(this.id)')); ?>
    </div>
    <div style="clear:both;"></div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_earning,'over_time',array('class'=>'span2','onchange'=>'calGrossPay(this.id)')); ?>
    </div>
    
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_earning,'Conveyance_Allowance',array('class'=>'span2','onchange'=>'calGrossPay(this.id)')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_earning,'bonus',array('class'=>'span2','onchange'=>'calGrossPay(this.id)')); ?>
    </div>
     
     <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_earning,'leave_encashment',array('class'=>'span2')); ?>
    </div>
    
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_earning,'other_incentive',array('class'=>'span2','onchange'=>'calGrossPay(this.id)')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_earning,'sp_allownces',array('class'=>'span2','onchange'=>'calGrossPay(this.id)')); ?>
    </div>
   <div style="clear:both;"></div>
   </div>
    <div style="display:block;">
    <div style="padding-bottom:10px;">
    <?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Employees Earnings:',
    )
    );

?>
   </div>
   <div style="clear:both;"></div>
   <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_deduction,'income_tax',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_deduction,'instalment_loan',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_deduction,'allowed_leaves',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_deduction,'insurance',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_deduction,'security_deposit',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_deduction,'EOBI',array('class'=>'span2')); ?>
    </div>
    
    <div style="clear:both;"></div>
    </div>
<div style="float:left; margin-top:25px">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$employee->isNewRecord ? 'Create' : 'Save',
		)); ?>
</div>
<div style="clear:both;"></div>

<?php $this->endWidget(); ?>
</div>
<?php
$this->breadcrumbs=array(
	'Hr Employees'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List HrEmployee','url'=>array('index')),
array('label'=>'Create HrEmployee','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.manage').click(function(){
$('#new').toggle();
$(window).scrollTop($('#new').offset().top);
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('hr-employee-grid', {
data: $(this).serialize()
});
return false;
});
");
?>

<div id="grid">
<div style="padding-top:10px; padding-bottom:10px; float:left">
<a href="#" class="manage">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Manage Employees:',
    )
    );

?>

</a>

</div>
<div style=" float:right; margin-right:738px; padding-top:10px; padding-bottom:10px;">
<a href="#" onclick="Createnew();">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Create new:',
    )
    );

?>
</a>
</div>
<div style="clear:both"></div>
<div style="float:right; padding-bottom:10px;">
<a href="<?php echo Yii::app()->baseUrl; ?>/HrEmployeePayroll/payroll" target="_blank">
<button type="button" class="btn btn-inverse">Create Pay Roll</button>
</a>
</div>

<?php //echo CHtml::link('Manage Employees','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:none">
	<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->
<div id="new" style="display:block" >

<?php $this->widget('bootstrap.widgets.TbGridView',array(
'id'=>'hr-employee-grid',
'summaryText'=>'',
'type'=>'triped bordered condensed',
'dataProvider'=>$model->search(),
'filter'=>$model,
'columns'=>array(
        
		array(
		    
            'header'=>'Sr#',
            'value'=>'$this->grid->dataProvider->pagination->currentPage * $this->grid->dataProvider->pagination->pageSize + ($row+1)',
        ),
		array(
            'id'=>'autoId',
            'class'=>'CCheckBoxColumn',
            'selectableRows' => '50',   
        ),
       // array('header'=>'Designation','name'=>'designation_id','value'=>'$data->designation->name'),
		'first_name',
		'last_name',
		'dob',
		array('header'=>'Account','name'=>'account','value'=>'$data->account0->account_code_2'),
		'contact_no',
		/*
		'address',
		'user_id',
		'designation_id',
		'salary',
		'account',
		
		*/
		array(
		'htmlOptions'=>array('style' => 'text-align: center; width:30px;'),

 'filter'=>false,
'class' => 'bootstrap.widgets.TbToggleColumn',
'toggleAction' => 'HrEmployee/toggle',
'name' => 'active',
'header' => 'Active',
//'filter'=>array('1'=>'active','0'=>'unactive')

),
		array
(   
    'class'=>'CButtonColumn',
	'htmlOptions'=>array('width'=>'60px'),

    'template'=>'{loan}{earning}',
    'buttons'=>array
    (
       /* 'email' => array
        (
		     'header'=>'Add leaves',
            'label'=>'Add leave to this employee',
            'imageUrl'=>Yii::app()->request->baseUrl.'/images/leave.png',
            'url'=>'Yii::app()->createUrl("HrEmployeeLeavesRecord/addleave", array("id"=>$data->id))',
        ),*/
		 'loan' => array
        (
		     'header'=>'Add/update Employee Loan',
            'label'=>'Add/update Employee Loan',
            'imageUrl'=>Yii::app()->request->baseUrl.'/images/loan.png',
            'url'=>'Yii::app()->createUrl("HrLoan/create", array("id"=>$data->id))',
        ),
		'earning' => array
        (
		     'header'=>'Update Earnings & Deductions',
            'label'=>'Update Earnings & Deductions',
            'imageUrl'=>Yii::app()->request->baseUrl.'/images/earning.png',
            'url'=>'Yii::app()->createUrl("HrEmployeeEarning/Update", array("id"=>$data->id))',
        ),
		/*'deductions' => array
        (
		     'header'=>'deductions',
            'label'=>'Set Deductions',
            'imageUrl'=>Yii::app()->request->baseUrl.'/images/deduction.png',
            'url'=>'Yii::app()->createUrl("HrEmployeeDeductions/update", array("id"=>$data->id))',
        ),*/
        
    ),
),
 
array(
'class'=>'bootstrap.widgets.TbButtonColumn',
'template'=>'{update}{delete}'
),
),
)); ?>
</div>
</div>
