<?php
$this->breadcrumbs=array(
	'Hr Employees'=>array('index'),
	$model->id,
);

$this->menu=array(
array('label'=>'List HrEmployee','url'=>array('index')),
array('label'=>'Create HrEmployee','url'=>array('create')),
array('label'=>'Update HrEmployee','url'=>array('update','id'=>$model->id)),
array('label'=>'Delete HrEmployee','url'=>'#','linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
array('label'=>'Manage HrEmployee','url'=>array('admin')),
);
?>
<div>
<h1><?php echo $model->first_name.' '.$model->last_name; ?>
<div style="float:right">
<a href="<?php echo Yii::app()->baseUrl;?>/Hremployee/admin">Back To All Employees</a>
</div>
 </h1>

</div>


<?php $this->widget('bootstrap.widgets.TbDetailView',array(
'data'=>$model,
'attributes'=>array(
		//'id',
		'first_name',
		'last_name',
		'dob',
		'email',
		'contact_no',
		'address',
	   
		array('header'=>'Designation','name'=>'designation_id','value'=>$model->designation->name),
		'salary',
		'account0.account_code_2',
),
)); ?>
