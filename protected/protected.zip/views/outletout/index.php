<?php
$this->breadcrumbs=array(
	'Outletouts',
);

$this->menu=array(
array('label'=>'Create Outletout','url'=>array('create')),
array('label'=>'Manage Outletout','url'=>array('admin')),
);
?>

<h1>Outletouts</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
