<?php
$this->breadcrumbs=array(
	'Outletouts'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List Outletout','url'=>array('index')),
array('label'=>'Manage Outletout','url'=>array('admin')),
);
?>

<h1>Create Outletout</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>