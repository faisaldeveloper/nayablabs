<script type="text/javascript">
function section()
{
	alert("called");
var selectedIndex = $('#Outletout_section_id').attr('selectedIndex');
if ($("#Outletout_section_id").get(0).selectedIndex > 0) {
	//alert("selected");
    $("#Outletout_inventoryitem_id").prop("disabled", false);  
	$('#Outletout_inventoryitem_id')[0].selectedIndex = 0;
}
else
{
	//alert("not selected");
	$("#Outletout_inventoryitem_id").prop("disabled", true);
	$('#Outletout_inventoryitem_id')[0].selectedIndex = 0;
}
}
function stockcheck()
{
	//alert("called");
	/*if($("#stock-value").val()=='')
	{
	 alert("Select Item First");
	 $("#stock-value").val('');
	 	
	 $("#Outletout_quantity").val('');
	}
	else
	{
		
		if(parseInt($("#Outletout_quantity").val())>parseInt($("#stock-value").val()))
		{
			alert("Given Quantity is greater then Current store Stock");
			$("#Outletout_quantity").val('');
		}
		
	}*/
	
}
</script>
<script type="text/javascript">
function calcost(){
	//alert("called");
	var quantity=parseInt(document.getElementById("Outletout_quantity").value);
	var purchrate=parseInt(document.getElementById("Outletout_purchrate").value);
	var discount=parseFloat(document.getElementById("Outletout_discount").value);
	if((quantity>0 && document.getElementById("Outletout_quantity").value!='')  && (purchrate>0 || document.getElementById("Outletout_purchrate").value!=''))
	{
	if(document.getElementById("Outletout_quantity").value!='' && document.getElementById("Outletout_purchrate").value!='')
	{
		
		var scheme=document.getElementById("Outletout_scheme").value;
		if(scheme!='' && quantity>scheme)
		{
		var total=(quantity-parseInt(scheme))*purchrate;
		   if(document.getElementById("Outletout_discount").value!='')
		   total=total-discount;
		   
		document.getElementById("Outletout_purchase_total").value=total;
		   if(document.getElementById("Outletout_discount").value!='' && document.getElementById("Outletout_purchase_total").value!='' && discount>0 && total>0)
		   {
		   var per=parseInt((discount)*(100/total));
		   document.getElementById("Outletout_discount_per").value=per;
		   }
		}
		else
		{
			if(scheme=='')
			{
			var total=quantity*purchrate;
			if(document.getElementById("Outletout_discount").value!='')
		   total=total-discount;
			document.getElementById("Outletout_purchase_total").value=total;	
			if(document.getElementById("Outletout_discount").value!='' && document.getElementById("Outletout_purchase_total").value!='' && discount>0 && total>0)
			{
		   var per=(discount)*(100/total);
		   document.getElementById("Outletout_discount_per").value=per;
			}
			}
			else
			{
				alert("Quantity must b greater then Scheme");
				var at=parseFloat((quantity*purchrate));
				var t=parseFloat(document.getElementById("Outletout_purchase_total").value);
				var diff=parseFloat(at-t);
				var scheme=parseInt(diff/purchrate);
				document.getElementById("Outletout_scheme").value=scheme;
			}
		}
	}
	else
	{
	alert("Either quantity or purchase rate is missing");	
	}
	}
	else
	{
	if(quantity==0 && purchrate>0)	
	{
		alert("Quantity must be greater then 0");
		document.getElementById("Outletout_scheme").value='';
	}
	else if(quantity>0 && purchrate==0)
	{
		alert("Purchase Rate must be greater then 0");
		document.getElementById("Outletout_scheme").value='';
	}
	else if(quantity==0 && purchrate==0)
	{
		alert("Quantity and Purchase Rate must be greater then 0");
		document.getElementById("Outletout_scheme").value='';
	}
	}
}

function caldisper(){
	
	//alert("called");
	var total=(parseFloat(document.getElementById("Outletout_quantity").value))*(parseFloat(document.getElementById("Outletout_purchrate").value));
	//alert(total);
	
	var discount=parseFloat(document.getElementById("Outletout_discount").value);
	if(document.getElementById("Outletout_purchase_total").value!=''  && document.getElementById("Outletout_discount").value!='' && total>discount)
	{
		 
		 var discper=(discount)*(100/total);
		total=total-discount;
		// alert(total);
		 document.getElementById("Outletout_purchase_total").value=total;
		 document.getElementById("Outletout_discount_per").value=discper;
	}
	else
	{
	alert("Total is not suitable for discount:");
	document.getElementById("Outletout_discount").value='';
	document.getElementById("Outletout_discount_per").value='';	
	}
}
function caldisc(){
	
	var quantity=parseFloat(document.getElementById("Outletout_quantity").value);
	var purchrate=parseFloat(document.getElementById("Outletout_purchrate").value);
	if(document.getElementById("Outletout_scheme").value!='' && document.getElementById("Outletout_scheme").value!=0 )
	{
	var scheme=parseInt(document.getElementById("Outletout_scheme").value);
	var total=parseFloat((quantity-scheme)*purchrate);
	}
	else
	{
		var total=parseFloat(quantity*purchrate);
	}
	//var total=(parseFloat(document.getElementById("Outletout_purchase_total").value))*;
	var discper=parseFloat(document.getElementById("Outletout_discount_per").value);
	


	if(document.getElementById("Outletout_purchase_total").value!='' && total>0)
	{
		var discountval=parseFloat(((total)*(discper)/100));
		alert(discountval);
		if(total>discountval)
		{
		document.getElementById("Outletout_discount").value=discountval;
		total=parseFloat(total)-parseFloat(discountval);
		document.getElementById("Outletout_purchase_total").value=total;
		}
		else
		alert("Discount Must be less then Total:");
	}
	else
	{
	 alert("Not suitable for Total");
	}
}
function calsaletaxper()
{
if(document.getElementById("Outletout_purchase_total").value!='')	
{
var salestax=parseFloat(document.getElementById("Outletout_sales_tax").value);
var total=parseFloat(document.getElementById("Outletout_purchase_total").value)	
 var salestaxper=(salestax)*(100/total);
 document.getElementById("Outletout_sales_tax_per").value=salestaxper;
}
}
function calsaletax()
{
if(document.getElementById("Outletout_purchase_total").value!='')	
{
var salestaxper=parseFloat(document.getElementById("Outletout_sales_tax_per").value);
var total=parseFloat(document.getElementById("Outletout_purchase_total").value)	
 var salestax=parseFloat(((total)*(salestaxper)/100));
 document.getElementById("Outletout_sales_tax").value=salestax;
}
}
</script>
<div id="formResult"></div>

<div style="padding-bottom:10px;">
<?php
if(Yii::app()->user->hasState('store'))
{
	$store_id=Yii::app()->user->getState('store');
	

}
if(Yii::app()->user->hasState('outlet'))
{
	$outlet_id=Yii::app()->user->getState('outlet');
	

}
?>
<?php

echo "stock_transfer=".$stock_transfer->id;
?>
</div>




<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'outletout-form',
	'enableClientValidation' => true,
    'clientOptions'=> array('validateOnSubmit'=>true),
	'enableAjaxValidation'=>false,
        //'action'=>$this->createUrl('storein/ajaxcreate'),
        //'enableClientValidation'=>true,
		//'enableClientValidation'=>true,
    //'clientOptions'=>array('validateOnSubmit'=>true, 'validateOnType'=>false,'validateOnChange'=>false),

)); ?>

<!--<p class="help-block">Fields with <span class="required">*</span> are required.</p>
-->
<?php echo $form->errorSummary($model); ?>
    <div style="float:left; padding-right:10px">
    <?php echo $form->dropDownListRow($model,'category',CHtml::listData(Category::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Category:','ajax' => array(
'type'=>'POST', //request type
'url'=>CController::createUrl('storein/Getitem'), //url to call.
//Style: CController::createUrl('currentController/methodToCall')
'update'=>'#Storeout_inventoryitem_id', //selector to update
'data'=>array('category_id'=>'js:this.value')
//leave out the data key to pass all form values through
))); ?>
    </div>
    <?php 
	$setting=SystemSettings::model()->find();
	if(count($setting)>0 && $setting->store==2) //// nostore////
	{
	   $data=$outlet_id;	
	   $st="outlet";
	   $item_disable=true;
	}
	else
	{
		$data=$store_id;
		$st="store";
		$item_disable=false;
	}
	$item_disable
	?>
    <div style="float:left; padding-right:10px">
    <?php 
	if($setting->store==2)
	{
	echo $form->dropDownListRow($model,'section_id',CHtml::listData(Section::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Section:','onchange'=>'section()')); 
	}
	?>
    </div>
    <div style="float:left; padding-right:10px">
    
    <?php echo $form->dropDownListRow($model,'inventoryitem_id',CHtml::listData(Inventoryitem::model()->findAll(),'id','name'),array('disabled'=>$item_disable,'class'=>'span2','prompt'=>'Item:','ajax' => array(
'type'=>'POST', //request type
'url'=>CController::createUrl('storein/Getcode'), //url to call.
//Style: CController::createUrl('currentController/methodToCall')
//'update'=>'#Storein_code', //selector to update
'data'=>array('id'=>'js:this.value','store_id'=>$data,'st'=>$st,'section_id'=>'js:$( "#Outletout_section_id" ).val()'),
'dataType'=>'json',
'success'=>'function(data){
	//alert(data);
	$("#stock-value").val(data.stock);
	$("#stock").text("Stock:"+data.stock+" "+data.unit);
	$("#Outletout_code").val(data.code);
	$("#Outletout_purchrate").val(data.last_purchase);
	
	
}'
//leave out the data key to pass all form values through
))); ?>
    <?php //echo $form->hiddenField($model,'outlet_id',array('class'=>'span5','value'=>$store_stock->outlet_id)); ?>
     <?php echo $form->error($model,'inventoryitem_id',array('hideErrorMessage'=>true)); ?>
    </div>
    <div style="float:left; padding-right:10px">
    <?php echo $form->textFieldRow($model,'code',array('class'=>'span2','ajax' => array(
                        'type' =>'POST',
                        'url' => CController::createUrl('storein/Getname'),
						'data'=>array('code'=>'js:this.value'),
                        //'update' => '#townlist',
                        'dataType' => 'json',
						'success'=>'function(data){
	alert(data.inventoryitem_id);
	$("#Storeout_inventoryitem_id").val(data.inventoryitem_id);
	$("#Storeout_category").val(data.category_id);
	$("#Storeout_purchrate").val(data.last_purchase);

}'
                ))); ?>
       </div>
        <div style="float:left; padding-right:10px">
       <?php echo $form->textFieldRow($model,'quantity',array('class'=>'span2','onchange'=>'calcost()','onblur'=>'stockcheck()')); ?>
       <?php echo $form->error($model,'quantity',array('hideErrorMessage'=>true)); ?>
       </div>
        <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'purchrate',array('class'=>'span2','onchange'=>'calcost()')); ?>
    <?php echo $form->error($model,'purchrate',array('hideErrorMessage'=>true)); ?>
      </div>
       
       <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'scheme',array('class'=>'span2','onchange'=>'calcost()')); ?>
      </div>
        
     <?php //echo $form->dropDownListRow($model,'supplier_id',CHtml::listData(Supplier::model()->findAll(),'id','name'),array('class'=>'span3','prompt'=>'Select a Supplier:')); ?>
      <?php // echo $form->dropDownListRow($model,'store_id',CHtml::listData(Store::model()->findAll(),'id','name'),array('class'=>'span3','prompt'=>'Select a Store:')); ?>
	
     <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'salerate',array('class'=>'span2')); ?>
     <?php echo $form->error($model,'salerate',array('hideErrorMessage'=>true)); ?>
      </div>
      
	<?php //echo $form->hiddenfield($model,'dop',array('value'=>date('Y-m-d H:i:s'))); ?>
      <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'discount',array('class'=>'span2','onchange'=>'caldisper()')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'discount_per',array('class'=>'span2','onchange'=>'caldisc()')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'sales_tax',array('class'=>'span2','onchange'=>'calsaletaxper()')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'sales_tax_per',array('class'=>'span2','onchange'=>'calsaletax()')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'net_purchase_rate',array('class'=>'span2')); ?>
    </div>
     <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'purchase_total',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'sales_total',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px" >
       <label id="stock" style="padding-top:28px; color:#933"></label>
       <input type="hidden" id="stock-value" />
       </div>
    <?php //echo $form->hiddenField($model,'store_id',array('class'=>'span5','value'=>$stock_transfer->store_id)); ?>
    <?php echo $form->hiddenField($model,'outlet_id',array('class'=>'span5','value'=>$outlet_id)); ?>
    <?php echo $form->hiddenField($model,'inventoryitem_id',array('class'=>'span5','value'=>$model->inventoryitem_id)); ?>
     <?php echo $form->hiddenField($model,'section_id',array('class'=>'span5','value'=>$model->section_id)); ?>
    <?php echo $form->hiddenField($model,'stock_transfer_id',array('class'=>'span5','value'=>$stock_transfer->id)); ?>
    <?php echo $form->hiddenField($model,'enter_by',array('class'=>'span5','value'=>Yii::app()->user->id)); ?>
    <div style="float:left; text-align:center; margin-top:25px;">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$model->isNewRecord ? 'Save' : 'Update',
		)); ?>
        <?php $this->widget('bootstrap.widgets.TbButton', array(
                        'buttonType'=>'reset',
                        'type'=>'inverse',
                        'label'=>'Reset',
                )); ?>

        <?php /*echo CHtml::ajaxSubmitButton('Create',CHtml::normalizeUrl(array('storein/ajaxcreate','render'=>true)),
                 array(
                     'dataType'=>'json',
                     'type'=>'post',
                     'success'=>'function(data) {
                        /// $("#AjaxLoader").hide();  
                        if(data.status=="success"){
							
                         $("#item").html("form Updated successfully.");
                         $("#storein-form")[0].reset();
						  $.fn.yiiGridView.update("storein-grid");
						 
						
						 alert("Grid refreshed");
                        }
                         else{
                        $.each(data, function(key, val) {
                        $("#storein-form #"+key+"_em_").text(val);                                                    
                        $("#storein-form #"+key+"_em_").show();
                        });
                        }       
                    }',                    
                     'beforeSend'=>'function(){                        
                           $("#AjaxLoader").show();
                      }'
                     ),array('id'=>'mybtn','class'=>'primary'));*/ ?>


</div>
    <div style="clear:both;"></div>
	<?php //echo $form->textFieldRow($model,'inventoryitem_id',array('class'=>'span5')); ?>
   
	<?php //echo $form->textFieldRow($model,'supplier_id',array('class'=>'span5')); ?>
   
	

	<?php //echo $form->textAreaRow($model,'remarks',array('class'=>'span5','maxlength'=>200)); ?>

	<?php //echo $form->textFieldRow($model,'enter_by',array('class'=>'span5')); ?>


	<?php /* $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'primary',
			'label'=>$model->isNewRecord ? 'Create' : 'Save',
		));*/ ?>

<?php // $this->endWidget(); ?>
</div>

<?php $this->endWidget(); ?>
