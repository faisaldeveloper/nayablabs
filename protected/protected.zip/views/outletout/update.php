<?php
$this->breadcrumbs=array(
	'Outletouts'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List Outletout','url'=>array('index')),
	array('label'=>'Create Outletout','url'=>array('create')),
	array('label'=>'View Outletout','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage Outletout','url'=>array('admin')),
	);
	?>

	<h1>Update Outletout <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form',array('model'=>$model,'stock_transfer'=>$stock_transfer)); ?>