<?php
$this->breadcrumbs=array(
	'Outletouts'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List Outletout','url'=>array('index')),
array('label'=>'Create Outletout','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('outletout-grid', {
data: $(this).serialize()
});
return false;
});
");
?>

<div style="padding-bottom:10px;">
<?php 
/*echo 'user:'.Yii::app()->user->id;
echo 'store:'.Yii::app()->user->getState('store');
echo 'outlet:'.Yii::app()->user->getState('outlet');
echo 'section:'.Yii::app()->user->getState('section');*/
?>
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Track Outlet Out:',
    )
    );

?>
</div>


<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:block">
	<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->
<?php 
$setting=SystemSettings::model()->find();
if(count($setting)>0 && $setting->store==1)
{

$outlet=true;
}
else if(count($setting)>0 && $setting->store==2)
{

$outlet=false;
}
?>
<?php $this->widget('bootstrap.widgets.TbGridView',array(
'id'=>'outletout-grid',
'type'=>'bordered',
'dataProvider'=>$model->adminsearch(),
//'filter'=>$model,
'columns'=>array(
		'id',
		array('header'=>'Out Type','name'=>'stock_transfer_id','value'=>'StockTransfer::model()->get_type($data->stocktransfer->transfer_type)'),
		array('header'=>'From Outlet','name'=>'outlet_id','value'=>'Outlet::model()->getname($data->outlet_id)','visible'=>$outlet),
		array('header'=>'From Section','name'=>'section_id','value'=>'$data->section->name'),
		array('header'=>'Item','name'=>'inventoryitem_id','value'=>'$data->inventoryitem->name'),
		'out_date',
		array('header'=>'Quantity','name'=>'quantity','value'=>'Outletout::model()->calquantity($data->id)'),
		//'outlet_id',
		//'inventoryitem_id',
		//'quantity',
		//'remarks',
		//'enter_by',
/*array(
'class'=>'bootstrap.widgets.TbButtonColumn',
),*/
),
)); ?>
