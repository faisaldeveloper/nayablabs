<?php
$this->breadcrumbs=array(
	'Hr Employee Earnings'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List HrEmployeeEarning','url'=>array('index')),
	array('label'=>'Create HrEmployeeEarning','url'=>array('create')),
	array('label'=>'View HrEmployeeEarning','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage HrEmployeeEarning','url'=>array('admin')),
	);
	?>

	<h1>Update Employee Earning (<?php echo $employee->first_name.' '.$employee->last_name; ?>)</h1> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<?php echo "<b>Last Update Date: </b>".$model->last_update_date;?>
<?php echo $this->renderPartial('_form',array('model'=>$model,'employee'=>$employee,'employee_leaves'=>$employee_leaves,'employee_deductions'=>$employee_deductions)); ?>