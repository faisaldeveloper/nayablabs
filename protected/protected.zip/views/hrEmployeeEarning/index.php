<?php
$this->breadcrumbs=array(
	'Hr Employee Earnings',
);

$this->menu=array(
array('label'=>'Create HrEmployeeEarning','url'=>array('create')),
array('label'=>'Manage HrEmployeeEarning','url'=>array('admin')),
);
?>

<h1>Hr Employee Earnings</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
