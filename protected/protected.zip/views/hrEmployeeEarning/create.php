<?php
$this->breadcrumbs=array(
	'Hr Employee Earnings'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List HrEmployeeEarning','url'=>array('index')),
array('label'=>'Manage HrEmployeeEarning','url'=>array('admin')),
);
?>

<h1>Create HrEmployeeEarning</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>