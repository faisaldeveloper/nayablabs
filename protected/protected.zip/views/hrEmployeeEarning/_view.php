<div class="view">

		<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id),array('view','id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('leave_days')); ?>:</b>
	<?php echo CHtml::encode($data->leave_days); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('days')); ?>:</b>
	<?php echo CHtml::encode($data->days); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('advance_salary')); ?>:</b>
	<?php echo CHtml::encode($data->advance_salary); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('gross_pay')); ?>:</b>
	<?php echo CHtml::encode($data->gross_pay); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('medical')); ?>:</b>
	<?php echo CHtml::encode($data->medical); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('house_rent')); ?>:</b>
	<?php echo CHtml::encode($data->house_rent); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('over_time')); ?>:</b>
	<?php echo CHtml::encode($data->over_time); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_id')); ?>:</b>
	<?php echo CHtml::encode($data->employee_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Conveyance_Allowance')); ?>:</b>
	<?php echo CHtml::encode($data->Conveyance_Allowance); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('bonus')); ?>:</b>
	<?php echo CHtml::encode($data->bonus); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('leave_encashment')); ?>:</b>
	<?php echo CHtml::encode($data->leave_encashment); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('other_incentive')); ?>:</b>
	<?php echo CHtml::encode($data->other_incentive); ?>
	<br />

	*/ ?>

</div>