<?php
$this->breadcrumbs=array(
	'Hr Employee Earnings'=>array('index'),
	$model->id,
);

$this->menu=array(
array('label'=>'List HrEmployeeEarning','url'=>array('index')),
array('label'=>'Create HrEmployeeEarning','url'=>array('create')),
array('label'=>'Update HrEmployeeEarning','url'=>array('update','id'=>$model->id)),
array('label'=>'Delete HrEmployeeEarning','url'=>'#','linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
array('label'=>'Manage HrEmployeeEarning','url'=>array('admin')),
);
?>

<h1>View HrEmployeeEarning #<?php echo $model->id; ?></h1>

<?php $this->widget('bootstrap.widgets.TbDetailView',array(
'data'=>$model,
'attributes'=>array(
		'leave_days',
		'days',
		'advance_salary',
		'gross_pay',
		'medical',
		'house_rent',
		'over_time',
		'employee_id',
		'Conveyance_Allowance',
		'bonus',
		'leave_encashment',
		'other_incentive',
		'id',
),
)); ?>
