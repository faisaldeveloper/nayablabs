<?php $m=HrEmployeeLeaves::model()->find('employee_id=:employee_id AND name=:name',array(':employee_id'=>$employee->id,':name'=>'medical')); ?>
<?php $c=HrEmployeeLeaves::model()->find('employee_id=:employee_id AND name=:name',array(':employee_id'=>$employee->id,':name'=>'casual')); ?>
<?php $u=HrEmployeeLeaves::model()->find('employee_id=:employee_id AND name=:name',array(':employee_id'=>$employee->id,':name'=>'urgent')); ?>

<script type="text/javascript" >
function calGrossPay(id){
	var basic_salary=<?php echo $employee->salary; ?>
	
	if(id=='HrEmployeeEarning_medical')
	{
		//alert($('#'+id).val());
		var gross=parseFloat($('#'+id).val())+parseFloat($('#HrEmployeeEarning_house_rent').val())+parseFloat($('#HrEmployeeEarning_over_time').val())+parseFloat($('#HrEmployeeEarning_Conveyance_Allowance').val())+parseFloat($('#HrEmployeeEarning_other_incentive').val())+parseFloat($('#HrEmployeeEarning_sp_allownces').val())+parseFloat($('#HrEmployeeEarning_bonus').val())+parseFloat(basic_salary);
		$('#HrEmployeeEarning_gross_pay').val(parseFloat(gross));
	}
	if(id=='HrEmployeeEarning_house_rent')
	{
		//alert($('#'+id).val());
		var gross=parseFloat($('#'+id).val())+parseFloat($('#HrEmployeeEarning_medical').val())+parseFloat($('#HrEmployeeEarning_over_time').val())+parseFloat($('#HrEmployeeEarning_Conveyance_Allowance').val())+parseFloat($('#HrEmployeeEarning_other_incentive').val())+parseFloat($('#HrEmployeeEarning_sp_allownces').val())+parseFloat($('#HrEmployeeEarning_bonus').val())+parseFloat(basic_salary);
		$('#HrEmployeeEarning_gross_pay').val(parseFloat(gross));
	}
	if(id=='HrEmployeeEarning_over_time')
	{
		//alert($('#'+id).val());
		var gross=parseFloat($('#'+id).val())+parseFloat($('#HrEmployeeEarning_house_rent').val())+parseFloat($('#HrEmployeeEarning_medical').val())+parseFloat($('#HrEmployeeEarning_Conveyance_Allowance').val())+parseFloat($('#HrEmployeeEarning_other_incentive').val())+parseFloat($('#HrEmployeeEarning_sp_allownces').val())+parseFloat($('#HrEmployeeEarning_bonus').val())+parseFloat(basic_salary);
		$('#HrEmployeeEarning_gross_pay').val(parseFloat(gross));
	}
	if(id=='HrEmployeeEarning_Conveyance_Allowance')
	{
		//alert($('#'+id).val());
		var gross=parseFloat($('#'+id).val())+parseFloat($('#HrEmployeeEarning_house_rent').val())+parseFloat($('#HrEmployeeEarning_over_time').val())+parseFloat($('#HrEmployeeEarning_medical').val())+parseFloat($('#HrEmployeeEarning_other_incentive').val())+parseFloat($('#HrEmployeeEarning_sp_allownces').val())+parseFloat($('#HrEmployeeEarning_bonus').val())+parseFloat(basic_salary);
		
		$('#HrEmployeeEarning_gross_pay').val(parseFloat(gross));
	}
	if(id=='HrEmployeeEarning_other_incentive')
	{
		//alert($('#'+id).val());
		var gross=parseFloat($('#'+id).val())+parseFloat($('#HrEmployeeEarning_house_rent').val())+parseFloat($('#HrEmployeeEarning_over_time').val())+parseFloat($('#HrEmployeeEarning_Conveyance_Allowance').val())+parseFloat($('#HrEmployeeEarning_medical').val())+parseFloat($('#HrEmployeeEarning_sp_allownces').val())+parseFloat($('#HrEmployeeEarning_bonus').val())+parseFloat(basic_salary);
		$('#HrEmployeeEarning_gross_pay').val(parseFloat(gross));
	}
	if(id=='HrEmployeeEarning_sp_allownces')
	{
		//alert($('#'+id).val());
		var gross=parseFloat($('#'+id).val())+parseFloat($('#HrEmployeeEarning_house_rent').val())+parseFloat($('#HrEmployeeEarning_over_time').val())+parseFloat($('#HrEmployeeEarning_Conveyance_Allowance').val())+parseFloat($('#HrEmployeeEarning_other_incentive').val())+parseFloat($('#HrEmployeeEarning_medical').val())+parseFloat($('#HrEmployeeEarning_bonus').val())+parseFloat(basic_salary);
		$('#HrEmployeeEarning_gross_pay').val(parseFloat(gross));
	}
	if(id=='HrEmployeeEarning_bonus')
	{
		//alert($('#'+id).val());
		var gross=parseFloat($('#'+id).val())+parseFloat($('#HrEmployeeEarning_house_rent').val())+parseFloat($('#HrEmployeeEarning_over_time').val())+parseFloat($('#HrEmployeeEarning_Conveyance_Allowance').val())+parseFloat($('#HrEmployeeEarning_other_incentive').val())+parseFloat($('#HrEmployeeEarning_sp_allownces').val())+parseFloat($('#HrEmployeeEarning_medical').val())+parseFloat(basic_salary);
		$('#HrEmployeeEarning_gross_pay').val(parseFloat(gross));
	}
}
function leaves(available,type)
{
//alert(available+type);

var medical=0;
var casual=0;
var urgent=0;
var total=0;
if($("#HrEmployeeEarning_medical_leave").val()!='' && type=='m')
{
	//alert("type m");
	if($("#HrEmployeeEarning_medical_leave").val()<=available)
	{
    medical=parseInt($("#HrEmployeeEarning_medical_leave").val());
	if($("#HrEmployeeEarning_casual_leave").val()!='')
	casual=parseInt($("#HrEmployeeEarning_casual_leave").val());
	if($("#HrEmployeeEarning_urgent_leave").val()!='')
	urgent=parseInt($("#HrEmployeeEarning_urgent_leave").val());
	total=medical+casual+urgent;
	}
	else
	{
	alert("leaves not available");
	if($("#HrEmployeeEarning_casual_leave").val()!='')
	casual=parseInt($("#HrEmployeeEarning_casual_leave").val());
	if($("#HrEmployeeEarning_urgent_leave").val()!='')
	urgent=parseInt($("#HrEmployeeEarning_urgent_leave").val());
	total=medical+casual+urgent;
	$("#HrEmployeeEarning_medical_leave").val(0);
	}
}
if($("#HrEmployeeEarning_casual_leave").val()!='' && type=='c')
{
	if($("#HrEmployeeEarning_casual_leave").val()<=available)
	{
    casual=parseInt($("#HrEmployeeEarning_casual_leave").val());
	if($("#HrEmployeeEarning_medical_leave").val()!='')
	medical=parseInt($("#HrEmployeeEarning_medical_leave").val());
	if($("#HrEmployeeEarning_urgent_leave").val()!='')
	urgent=parseInt($("#HrEmployeeEarning_urgent_leave").val());
	total=medical+casual+urgent;
	}
    else
	{
    alert("Casual leaves not available");
	if($("#HrEmployeeEarning_medical_leave").val()!='')
	medical=parseInt($("#HrEmployeeEarning_medical_leave").val());
	if($("#HrEmployeeEarning_urgent_leave").val()!='')
	urgent=parseInt($("#HrEmployeeEarning_urgent_leave").val());
	total=medical+casual+urgent;
	$("#HrEmployeeEarning_casual_leave").val(0);
	}
}
if($("#HrEmployeeEarning_urgent_leave").val()!='' && type=='u')
{
	if($("#HrEmployeeEarning_urgent_leave").val()<=available)
	{
    urgent=parseInt($("#HrEmployeeEarning_urgent_leave").val());
	if($("#HrEmployeeEarning_medical_leave").val()!='')
	medical=parseInt($("#HrEmployeeEarning_medical_leave").val());
	if($("#HrEmployeeEarning_casual_leave").val()!='')
	casual=parseInt($("#HrEmployeeEarning_casual_leave").val());
	total=medical+casual+urgent;
	
	}
    else
	{
    alert("Urgent leaves not available");
	if($("#HrEmployeeEarning_medical_leave").val()!='')
	medical=parseInt($("#HrEmployeeEarning_medical_leave").val());
	if($("#HrEmployeeEarning_casual_leave").val()!='')
	casual=parseInt($("#HrEmployeeEarning_casual_leave").val());
	total=medical+casual+urgent;
	$("#HrEmployeeEarning_urgent_leave").val(0);
	}
}
//var total=medical+casual+urgent;
$("#HrEmployeeEarning_leave_days").val(total);
$("#l").val(total);
}
</script>
<div class="span6" >
<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'hr-employee-earning-form',
	'enableAjaxValidation'=>false,
	'enableClientValidation'=>true,
		'clientOptions'=>array(
            'validateOnSubmit'=>true,
        ),
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($model); ?>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'medical_leave',array('class'=>'span2','onchange'=>'leaves('.$m->available.',"m");')); ?>
    <?php echo $form->error($model,'medical_leave',array('hideErrorMessage'=>true)); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'casual_leave',array('class'=>'span2','onchange'=>'leaves('.$c->available.',"c");')); ?>
    <?php echo $form->error($model,'casual_leave',array('hideErrorMessage'=>true)); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'urgent_leave',array('class'=>'span2','onchange'=>'leaves('.$u->available.',"u");')); ?>
    <?php echo $form->error($model,'urgent_leave',array('hideErrorMessage'=>true)); ?>
    </div>
    <div style="clear:both;"></div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->hiddenField($model,'leave_days',array('class'=>'span2')); ?>
    <label>Leaves</label>
    <input id="l" type="text" value="0" disabled="disabled" style="width:126px;" />
     <?php echo $form->error($model,'leave_days',array('hideErrorMessage'=>true)); ?>
    </div>
    
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'days',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'advance_salary',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
    <?php  $gross_pay=$employee->salary + $model->medical + $model->house_rent + $model->over_time+$model->Conveyance_Allowance+$model->bonus+$model->other_incentive+$model->sp_allownces; ?>
	<?php echo $form->textFieldRow($model,'gross_pay',array('class'=>'span2','value'=>$gross_pay)); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'medical',array('class'=>'span2','onchange'=>'calGrossPay(this.id)')); ?>
    </div>
    
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'house_rent',array('class'=>'span2','onchange'=>'calGrossPay(this.id)')); ?>
    </div>
    <div style="clear:both;"></div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'over_time',array('class'=>'span2','onchange'=>'calGrossPay(this.id)')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->hiddenField($model,'employee_id',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'Conveyance_Allowance',array('class'=>'span2','onchange'=>'calGrossPay(this.id)')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'bonus',array('class'=>'span2','onchange'=>'calGrossPay(this.id)')); ?>
    </div>
     
     <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'leave_encashment',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'other_incentive',array('class'=>'span2','onchange'=>'calGrossPay(this.id)')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'sp_allownces',array('class'=>'span2','onchange'=>'calGrossPay(this.id)')); ?>
    </div>
    
</div>
<div class="span5" >
<table class="table table-bordered" style="margin-top:36px">
<tr style="background-color:#CCC"><th>Leave</th><th>Availed</th><th>Available</th></tr>
  <?php 
  $total_availed_annual=0;
  $total_available_annual=0;
  foreach($employee_leaves as $row)
  {
	  ?>
      <tr>
      <td><?php echo $row->name; ?></td>
      <td><?php echo $row->avail; ?></td>
      <td><?php echo $row->available; ?></td>
      </tr>
      <?php
	  $total_available_annual=$total_available_annual+$row->available;
	  $total_availed_annual=$total_availed_annual+$row->avail;
  }
	  ?>
      <tr>
      <td></td>
      <td>Total:<?php echo $total_availed_annual;?></td>
      <td>Total:<?php echo $total_available_annual;?></td>
      </tr>
</table>
<a href="<?php echo Yii::app()->baseUrl;?>/HrEmployee/admin">Back to Employees &nbsp;<img src="<?php echo Yii::app()->baseUrl;?>/images/backlink.png" height="13px" width="13px" /></a>
</div>

<div class="span12">
 <h1>Update Employee Deductions</h1>
 <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_deductions,'income_tax',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_deductions,'instalment_loan',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_deductions,'allowed_leaves',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_deductions,'insurance',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_deductions,'security_deposit',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($employee_deductions,'EOBI',array('class'=>'span2')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->hiddenField($employee_deductions,'employee_id',array('class'=>'span2')); ?>
   </div>
   <div style="clear:both;"></div>
<div class="form-actions">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$employee->isNewRecord ? 'Create' : 'Save',
		)); ?>
</div>


<?php $this->endWidget(); ?>
</div>