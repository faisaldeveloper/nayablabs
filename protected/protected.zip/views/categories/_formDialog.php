<script>
$(document).ready(function(){

$( "#closeemployeetypeDialog" ).button({
            icons: {
                primary: "ui-icon-plusthick"
            },
           //text: false
        });
		


});
</script>

<div class="form" id="employeetypeDialogForm">
 
<?php $form=$this->beginWidget('CActiveForm', array(
    'id'=>'employeetypes-form',
    'enableAjaxValidation'=>true,
	'enableClientValidation'=>true,
    'clientOptions'=>array('validateOnSubmit'=>true, 'validateOnType'=>false,'validateOnChange'=>false),
)); 
//I have enableAjaxValidation set to true so i can validate on the fly the
?>
 <div id="employeetype_error_div">
    <p class="note">Fields with <span class="required">*</span> are required.</p>
 </div>
<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($model); ?>

		<?php echo $form->labelEx($model,'alias'); ?>
        <?php echo $form->textField($model,'alias',array('size'=>60,'maxlength'=>180)); ?>
        <?php echo $form->error($model,'alias'); ?>
        <?php echo $form->labelEx($model,'name'); ?>
        <?php echo $form->textField($model,'name',array('size'=>60,'maxlength'=>180)); ?>
        <?php echo $form->error($model,'name'); ?>
        <?php echo $form->labelEx($model,'code'); ?>
        <?php echo $form->textField($model,'code',array('size'=>60,'maxlength'=>180)); ?>
        <?php echo $form->error($model,'code'); ?>

	<?php echo CHtml::ajaxSubmitButton('Create Employee Type',CHtml::normalizeUrl(array('categories/addnew','render'=>false)),
					array(
					'success'=>'js: function(data) {
						
						var data2 = $.parseJSON(data);
						
						if(data2.er>0){
						$("#employeetype_error_div").html("<div style=\"color:red\">"+data2.msg+"<br></div>");
						}else{
						$("#User_password").append(data2.msg);
						//$("#Drivers_employeetype_id").trigger("liszt:updated");
						
                        $("#categoriesDialog").dialog("close");
						}
                    }'
					
					),array('id'=>'closeemployeetypeDialog')); ?>
                    
                    
<?php $this->endWidget(); ?>

 
</div>