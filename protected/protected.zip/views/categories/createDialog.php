<?php 
$this->beginWidget('zii.widgets.jui.CJuiDialog',array(
                'id'=>'categoriesDialog',
                'options'=>array(
                    'title'=>'Create Categories Type',
                    'autoOpen'=>true,
                    'modal'=>'true',
                    'width'=>'auto',
                    'height'=>'auto',
                ),
                ));
echo $this->renderPartial('_formDialog', array('model'=>$model)); ?>
<?php $this->endWidget('zii.widgets.jui.CJuiDialog');?>