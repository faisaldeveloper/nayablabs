<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'categories-form',
	'enableAjaxValidation'=>false,
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($model);
?>

	<?php echo $form->textFieldRow($model,'alias',array('class'=>'span5','maxlength'=>10)); ?>

	<?php echo $form->textFieldRow($model,'name',array('class'=>'span5','maxlength'=>50)); ?>

	<?php echo $form->textFieldRow($model,'code',array('class'=>'span5','maxlength'=>10)); ?>


<div class="<?php echo $class;?>" style="display:none">

<input type="submit" value="<?php echo $model->isNewRecord ? 'Create' : 'Save'?>" 
name="button" id="categorybutton" class="btn btn-primary" >



</div>

<?php $this->endWidget(); ?>
