
<h1>Create CPV (Cash Payment Voucher) </h1>

<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'account-voucher-form',
	//'action' => Yii::app()->createUrl('AccountVoucher/jv').'/'.$jv->id,
	'enableAjaxValidation'=>false,
	'enableClientValidation'=>true,
		'clientOptions'=>array(
            'validateOnSubmit'=>true,
        ),
)); ?>


<?php echo $form->errorSummary(array($voucher,$ledger)); ?>

	<?php // echo $form->textFieldRow($jv,'voucher_type',array('class'=>'span5')); ?>

	<?php // echo $form->textFieldRow($jv,'number',array('class'=>'span5','maxlength'=>10)); ?>
    <div style="float:left; padding-right:10px">
 <?php echo $form->dropDownListRow($voucher,'account_type_dr',CHtml::listData(AccountAccounttypes::model()->findAll(),'id','type'),array('prompt'=>'Select Type:','class'=>'span2','ajax' => array(
                        'type' =>'POST',
                        'url' => CController::createUrl('AccountAccountTypes/GetAccounts'),
						'data'=>array('value'=>'js:this.value'),
                        'update' => '#AccountLedger_dr_account',
                        
                ))); ?>
</div>
<div style="float:left; padding-right:10px">
<?php echo $form->dropDownListRow($ledger,'dr_account',array(),array('class'=>'span2')); ?>
<?php echo $form->error($ledger,'dr_account',array('hideErrorMessage'=>true)); ?>
</div>

<div style="clear:both"></div>
<div style="float:left; padding-right:10px">
<?php  echo $form->textFieldRow($ledger,'amount',array('class'=>'span2')); ?>
<?php echo $form->error($ledger,'amount',array('hideErrorMessage'=>true)); ?>
</div>

<div style="clear:both"></div>
<div style="float:left; padding-right:10px">
<?php echo $form->datepickerRow(
      $voucher,
      'date',
     array(
    'options' => array('language' => 'es','width'=>'100px','format'=>'yyyy-mm-dd'),
    //'hint' => 'Click inside! This is a super cool date field.',
   'prepend' => '<i class="icon-calendar"></i>'
    )
    ); ?>
</div>
<div style="clear:both"></div>
<div style="float:left; padding-right:10px">
<?php  echo $form->textAreaRow($ledger,'remarks',array('class'=>'span5')); ?>
</div>
<div style="float:left; padding-right:10px">
<?php  echo $form->textAreaRow($ledger,'narration',array('class'=>'span5')); ?>
</div>
<div style="clear:both"></div>
<div class="form-actions">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$voucher->isNewRecord ? 'Create Voucher' : 'Save',
		)); ?>
</div>

<?php $this->endWidget(); ?>
