<?php
$this->breadcrumbs=array(
	'Account Vouchers',
);

$this->menu=array(
array('label'=>'Create AccountVoucher','url'=>array('create')),
array('label'=>'Manage AccountVoucher','url'=>array('admin')),
);
?>

<h1>Account Vouchers</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
