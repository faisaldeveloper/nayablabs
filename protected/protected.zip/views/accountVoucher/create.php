<?php
$this->breadcrumbs=array(
	'Account Vouchers'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List AccountVoucher','url'=>array('index')),
array('label'=>'Manage AccountVoucher','url'=>array('admin')),
);
?>

<h1>Create AccountVoucher</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>