<script type="text/javascript">
window.onload=function(){
	//alert(document.referrer);
	//alert("current url="+document.URL);
	if(document.referrer=='<?php echo Yii::app()->baseUrl;?>/AccountVoucher/Voucher' || document.referrer=='<?php echo Yii::app()->baseUrl;?>/AccountVoucher/jv/'+<?php echo $id;?> || document.URL== '<?php echo Yii::app()->baseUrl;?>/AccountVoucher/voucher')
	{
		//alert("do nothing");
		}
	else
	{
	window.location = "<?php echo Yii::app()->baseUrl;?>/index.php/AccountVoucher/break";
	}
	};

 
</script>

<h1>Create Jv (Journal Voucher) </h1>

<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'account-voucher-form',
	'action' => Yii::app()->createUrl('AccountVoucher/jv').'/'.$jv->id,
	'enableAjaxValidation'=>false,
	'enableClientValidation'=>true,
		'clientOptions'=>array(
            'validateOnSubmit'=>true,
        ),
)); ?>


<?php echo $form->errorSummary(array($jv,$ledger)); ?>

	<?php // echo $form->textFieldRow($jv,'voucher_type',array('class'=>'span5')); ?>

	<?php // echo $form->textFieldRow($jv,'number',array('class'=>'span5','maxlength'=>10)); ?>
    <div style="float:left; padding-right:10px">
 <?php echo $form->dropDownListRow($jv,'account_type_dr',CHtml::listData(AccountAccounttypes::model()->findAll(),'id','type'),array('prompt'=>'Select Type:','class'=>'span2','ajax' => array(
                        'type' =>'POST',
                        'url' => CController::createUrl('AccountAccountTypes/GetAccounts'),
						'data'=>array('value'=>'js:this.value'),
                        'update' => '#AccountLedger_dr_account',
                        
                ))); ?>
</div>
<div style="float:left; padding-right:10px">
<?php echo $form->dropDownListRow($ledger,'dr_account',array(),array('class'=>'span2')); ?>
<?php echo $form->error($ledger,'dr_account',array('hideErrorMessage'=>true)); ?>
</div>
<div style="clear:both"></div>
<div style="float:left; padding-right:10px">
 <?php echo $form->dropDownListRow($jv,'account_type_cr',CHtml::listData(AccountAccounttypes::model()->findAll(),'id','type'),array('prompt'=>'Select Type:','class'=>'span2','ajax' => array(
                        'type' =>'POST',
                        'url' => CController::createUrl('AccountAccountTypes/GetAccounts'),
						'data'=>array('value'=>'js:this.value'),
                        'update' => '#AccountLedger_cr_account',
                        
                ))); ?>
</div>
<div style="float:left; padding-right:10px">
<?php echo $form->dropDownListRow($ledger,'cr_account',array(),array('class'=>'span2')); ?>
<?php echo $form->error($ledger,'cr_account',array('hideErrorMessage'=>true)); ?>
</div>
<div style="clear:both"></div>
<div style="float:left; padding-right:10px">
<?php  echo $form->textFieldRow($ledger,'amount',array('class'=>'span2')); ?>
<?php echo $form->error($ledger,'amount',array('hideErrorMessage'=>true)); ?>
</div>

<div style="float:left; padding-right:10px">
<?php echo $form->datepickerRow(
      $jv,
      'date',
     array(
    'options' => array('language' => 'es','width'=>'100px','format'=>'yyyy-mm-dd'),
    //'hint' => 'Click inside! This is a super cool date field.',
   'prepend' => '<i class="icon-calendar"></i>'
    )
    ); ?>
</div>
<div style="clear:both"></div>
<div style="float:left; padding-right:10px">
<?php  echo $form->textAreaRow($ledger,'remarks',array('class'=>'span5')); ?>
</div>
<div style="float:left; padding-right:10px">
<?php  echo $form->textAreaRow($ledger,'narration',array('class'=>'span5')); ?>
</div>
<div style="clear:both"></div>
<div class="form-actions">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$ledger->isNewRecord ? 'Add to Voucher' : 'Save',
		)); ?>
</div>

<?php $this->endWidget(); ?>
<?php
$this->breadcrumbs=array(
	'Account Ledgers'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List AccountLedger','url'=>array('index')),
array('label'=>'Create AccountLedger','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('account-ledger-grid', {
data: $(this).serialize()
});
return false;
});
");
?>
<div style="float:left">
<h1>Voucher Transactions</h1>
</div>
<!--<div style="float:right; padding-top:10px;">
<button type="button" class="btn btn-inverse" >Complete Voucher</button>
</div>-->
<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>

<?php $this->widget('bootstrap.widgets.TbGridView',array(
'id'=>'account-ledger-grid',
'summaryText'=>'',
'type'=>'triped bordered condensed',
'dataProvider'=>$model->vouchersearch($jv->id),

//'filter'=>$model,
'columns'=>array(
		//'id',
		//'account_id',
		//'debit_credit',
		array('header'=>'Debit To','name'=>'dr_account','value'=>'$data->draccount->account_name'),
		array('header'=>'Credit To','name'=>'cr_account','value'=>'$data->craccount->account_name'),
		'amount',
		'trans_date',
array(
'class'=>'bootstrap.widgets.TbButtonColumn',
'template'=>'{update}',
),
),
)); 
	


	?>
    
