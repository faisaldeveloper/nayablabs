<?php
$this->breadcrumbs=array(
	'Hr Employee Leaves'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List HrEmployeeLeaves','url'=>array('index')),
array('label'=>'Manage HrEmployeeLeaves','url'=>array('admin')),
);
?>

<h1>Create HrEmployeeLeaves</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>