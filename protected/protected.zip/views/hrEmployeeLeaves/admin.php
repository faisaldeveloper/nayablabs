<?php
$this->breadcrumbs=array(
	'Hr Employee Leaves'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List HrEmployeeLeaves','url'=>array('index')),
array('label'=>'Create HrEmployeeLeaves','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('hr-employee-leaves-grid', {
data: $(this).serialize()
});
return false;
});
");
?>

<h1>Manage Hr Employee Leaves</h1>



<?php echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:none">
	<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php $this->widget('ext.groupgridview.BootGroupGridView',array(
'id'=>'hr-employee-leaves-grid',
'type'=>'striped bordered condensed',
'dataProvider'=>$model->search(),
'filter'=>$model,
'mergeColumns' => ('employee_id'),
'columns'=>array(
		array(
            'header'=>'Sr#',
            'value'=>'$this->grid->dataProvider->pagination->currentPage * $this->grid->dataProvider->pagination->pageSize + ($row+1)',
        ),

		array('header'=>'Emp Name', 'name'=>'employee_id','value'=>'$data->employee->first_name'),
		//'leaves_type_id',
		array('header'=>'Leave Type','name'=>'name','value'=>'$data->name'),
		//'name',
		 array(
        'class' => 'editable.EditableColumn',
        'name' => 'avail',
        'headerHtmlOptions' => array('style' => 'width: 110px'),
        'editable' => array( //editable section
        //'apply' => '$data->user_status != 4', //can't edit deleted users
        'url' => $this->createUrl('HrEmployeeLeaves/UpdateLeave'),
        'placement' => 'right',
          )
          ),
		//'avail',
		 array(
        'class' => 'editable.EditableColumn',
        'name' => 'available',
        'headerHtmlOptions' => array('style' => 'width: 110px'),
        'editable' => array( //editable section
        //'apply' => '$data->user_status != 4', //can't edit deleted users
        'url' => $this->createUrl('HrEmployeeLeaves/UpdateLeave'),
        'placement' => 'right',
          )
          ),
		//'available',
/*array(
'class'=>'bootstrap.widgets.TbButtonColumn',
),*/
),
)); ?>
