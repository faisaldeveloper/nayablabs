<?php
$this->breadcrumbs=array(
	'Hr Employee Leaves',
);

$this->menu=array(
array('label'=>'Create HrEmployeeLeaves','url'=>array('create')),
array('label'=>'Manage HrEmployeeLeaves','url'=>array('admin')),
);
?>

<h1>Hr Employee Leaves</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
