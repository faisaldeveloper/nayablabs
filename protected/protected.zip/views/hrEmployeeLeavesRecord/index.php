<?php
$this->breadcrumbs=array(
	'Hr Employee Leaves Records',
);

$this->menu=array(
array('label'=>'Create HrEmployeeLeavesRecord','url'=>array('create')),
array('label'=>'Manage HrEmployeeLeavesRecord','url'=>array('admin')),
);
?>

<h1>Hr Employee Leaves Records</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
