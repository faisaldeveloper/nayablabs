<?php
$this->breadcrumbs=array(
	'Hr Employee Leaves Records'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List HrEmployeeLeavesRecord','url'=>array('index')),
	array('label'=>'Create HrEmployeeLeavesRecord','url'=>array('create')),
	array('label'=>'View HrEmployeeLeavesRecord','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage HrEmployeeLeavesRecord','url'=>array('admin')),
	);
	?>

	<h1>Update HrEmployeeLeavesRecord <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form',array('model'=>$model)); ?>