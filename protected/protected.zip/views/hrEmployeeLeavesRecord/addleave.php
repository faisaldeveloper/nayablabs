<div class="span5">
<div style="padding-bottom:25px;">
<?php
    
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Create new Leave',
    )
    );

?>
</div>
<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'hr-employee-leaves-record-form',
	'enableAjaxValidation'=>false,
)); ?>



<?php echo $form->errorSummary($model); ?>

	<?php echo $form->textFieldRow($model,'employee_id',array('class'=>'span3','value'=>$employee->first_name.' '.$employee->last_name,'disabled'=>true)); ?>

	
     <?php echo $form->dropDownListRow($model,'employee_leave_id',CHtml::listData(HrEmployeeLeaves::model()->findAll('employee_id='.$employee->id),'id','name'),array('class'=>'span3')); ?>
     <?php echo $form->textFieldRow($model,'leaves',array('class'=>'span3')); ?>
	<?php //echo $form->textFieldRow($model,'leave_date',array('class'=>'span5')); ?>
    <?php echo $form->datepickerRow(
      $model,
      'leave_date',
     array(
    'options' => array('language' => 'es','width'=>'100px','format'=>'yyyy-mm-dd'),
    //'hint' => 'Click inside! This is a super cool date field.',
   // 'prepend' => '<i class="icon-calendar"></i>'
    )
    ); ?>
<div class="form-actions">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$model->isNewRecord ? 'Create' : 'Save',
		)); ?>
</div>

<?php $this->endWidget(); ?>
</div>
<div class="span5">
<div style="padding-bottom:25px;">
<?php
    
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => $employee->first_name.' '.$employee->last_name.' '.'Annual leaves chart',
    )
    );

?>
</div>
<table class="table table-bordered">
<th>Leave</th><th>Avail</th><th>Available</th>
  <?php 
  $total_availed_annual=0;
  $total_available_annual=0;
  foreach($employee_leaves as $row)
  {
	  ?>
      <tr>
      <td><?php echo $row->name; ?></td>
      <td><?php echo $row->avail; ?></td>
      <td><?php echo $row->available; ?></td>
      </tr>
      <?php
	  $total_available_annual=$total_available_annual+$row->available;
	  $total_availed_annual=$total_availed_annual+$row->avail;
  }
	  ?>
      <tr>
      <td></td>
      <td>Total:<?php echo $total_availed_annual;?></td>
      <td>Total:<?php echo $total_available_annual;?></td>
      </tr>
</table>
<a href="<?php echo Yii::app()->baseUrl;?>/HrEmployee/admin">Back to Employees &nbsp;<img src="<?php echo Yii::app()->baseUrl;?>/images/backlink.png" height="13px" width="13px" /></a>
<div style="padding-bottom:25px; padding-top:25px;">
<?php
    //$date
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => $employee->first_name.' '.$employee->last_name.' '.'Current Month leaves chart',
    )
    );

?>
</div>
<table class="table table-bordered">
<th>Leave</th><th>Avail</th>
  <?php 
  $date=date('Y-m-d');
 //echo substr($date,0,-3);
  $total_availed_month=0;
  
  foreach($employee_leaves as $row)
  {
	  
	  $leave_record=Yii::app()->db->createCommand("SELECT SUM( `leaves` ) AS leaves_sum, employee_id, employee_leave_id, leave_date
FROM hr_employee_leaves_record
WHERE leave_date LIKE '".substr($date,0,-3)."%'
AND employee_id =".$employee->id."
AND `employee_leave_id` =".$row->id)->queryAll();
     
	  ?>
      
      <tr>
      <td><?php echo $row->name; ?></td>
      <td><?php if($leave_record[0]['leaves_sum']!=NULL) echo $leave_record[0]['leaves_sum']; else echo "0"; ?></td>
      
      </tr>
      <?php
	  if($leave_record[0]['leaves_sum']!=NULL) 
	  $result= $leave_record[0]['leaves_sum'];
	  else 
	  $result=0;
	  $total_availed_month=$total_availed_month + $result;
  }
	  ?>
      <tr>
      <td></td>
      <td>Total:<?php echo $total_availed_month; ?></td>
      
      </tr>
</table>
</div>
<div class="span12">
<?php
$this->breadcrumbs=array(
	'Hr Employee Leaves Records'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List HrEmployeeLeavesRecord','url'=>array('index')),
array('label'=>'Create HrEmployeeLeavesRecord','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('hr-employee-leaves-record-grid', {
data: $(this).serialize()
});
return false;
});
");
?>

<div style="padding-bottom:25px; padding-top:25px;">
<?php
    //$date
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Manage'.' '.$employee->first_name.' '.$employee->last_name.' '.'leaves Record',
    )
    );

?>
</div>


<?php $this->widget('ext.groupgridview.BootGroupGridView',array(
'id'=>'hr-employee-leaves-record-grid',
'type'=>'striped bordered condensed',
'dataProvider'=>$admin->employee_search($employee->id),
'mergeColumns' =>array ('employee_leave_id','leave_date'),

'filter'=>$admin,
'columns'=>array(
		'id',
		//'employee_id',
		'leave_date',
		array('header'=>'Leave Type','name'=>'employee_leave_id','value'=>'$data->employeeLeave->name'),
		'leaves',
		//'employee_leave_id',
		
array(
'class'=>'bootstrap.widgets.TbButtonColumn',
),
),
)); ?>

</div>