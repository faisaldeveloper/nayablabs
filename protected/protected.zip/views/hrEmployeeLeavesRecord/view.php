<?php
$this->breadcrumbs=array(
	'Hr Employee Leaves Records'=>array('index'),
	$model->id,
);

$this->menu=array(
array('label'=>'List HrEmployeeLeavesRecord','url'=>array('index')),
array('label'=>'Create HrEmployeeLeavesRecord','url'=>array('create')),
array('label'=>'Update HrEmployeeLeavesRecord','url'=>array('update','id'=>$model->id)),
array('label'=>'Delete HrEmployeeLeavesRecord','url'=>'#','linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
array('label'=>'Manage HrEmployeeLeavesRecord','url'=>array('admin')),
);
?>

<h1>View HrEmployeeLeavesRecord #<?php echo $model->id; ?></h1>

<?php $this->widget('bootstrap.widgets.TbDetailView',array(
'data'=>$model,
'attributes'=>array(
		'id',
		'employee_id',
		'employee_leave_id',
		'leave_date',
),
)); ?>
