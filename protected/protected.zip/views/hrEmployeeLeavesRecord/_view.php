<div class="view">

		<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id),array('view','id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_id')); ?>:</b>
	<?php echo CHtml::encode($data->employee_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_leave_id')); ?>:</b>
	<?php echo CHtml::encode($data->employee_leave_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('leave_date')); ?>:</b>
	<?php echo CHtml::encode($data->leave_date); ?>
	<br />


</div>