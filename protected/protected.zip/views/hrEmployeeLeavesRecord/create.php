<?php
$this->breadcrumbs=array(
	'Hr Employee Leaves Records'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List HrEmployeeLeavesRecord','url'=>array('index')),
array('label'=>'Manage HrEmployeeLeavesRecord','url'=>array('admin')),
);
?>

<h1>Create HrEmployeeLeavesRecord</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>