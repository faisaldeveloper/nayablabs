<div class="view">

		<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id),array('view','id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('account_code')); ?>:</b>
	<?php echo CHtml::encode($data->account_code); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('account_code_2')); ?>:</b>
	<?php echo CHtml::encode($data->account_code_2); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('account_name')); ?>:</b>
	<?php echo CHtml::encode($data->account_name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('account_group')); ?>:</b>
	<?php echo CHtml::encode($data->account_group); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('account_tags')); ?>:</b>
	<?php echo CHtml::encode($data->account_tags); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('account_status')); ?>:</b>
	<?php echo CHtml::encode($data->account_status); ?>
	<br />


</div>