<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'account-chart-of-account-form',
	
	'enableAjaxValidation'=>false,
	'enableClientValidation'=>true,
		'clientOptions'=>array(
            'validateOnSubmit'=>true,
        ),
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($model); ?>
    <div style="float:left; padding-right:10px">
	 <?php echo $form->dropDownListRow($model,'account_group',CHtml::listData(AccountGroups::model()->findAll(),'id','group_name'),array('prompt'=>'Select Class:','class'=>'span3','ajax' => array(
                        'type' =>'POST',
                        'url' => CController::createUrl('AccountChartOfAccount/GetCode'),
						'data'=>array('value'=>'js:this.value'),
                        //'update' => '#townlist',
                        'dataType' => 'json',
						'success'=>'function(data){
	                     // alert("code="+data.code);
						  $(".add-on").text(data.prepend);
						  $("#AccountChartOfAccount_account_code").val(data.code);
                        }'
                ))); ?>
    </div>
    
   <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'account_code',array('prepend'=>$prepend,'class'=>'span1','maxlength'=>20)); ?>
     <?php //echo $form->error($account,'account_code',array('hideErrorMessage'=>true)); ?>
   </div>
   
   
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'account_name',array('class'=>'span5','maxlength'=>30)); ?>
    </div>
    <div style="clear:both;"></div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->dropDownListRow($model,'account_type',CHtml::listData(AccountAccountTypes::model()->findAll(),'id','type'),array('prompt'=>'Select Type:','class'=>'span3')); ?>
    </div>
   <div style="float:left; padding-right:10px">
	<?php echo $form->dropDownListRow($model,'account_status',array('1'=>'activate','2'=>'un-activate'),array('class'=>'span3')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'account_tags',array('class'=>'span2')); ?>
    </div>
    
<div style="float:left; margin-top:25px">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$model->isNewRecord ? 'Create' : 'Save',
		)); ?>
</div>
<div style="clear:both;"></div>

<?php $this->endWidget(); ?>