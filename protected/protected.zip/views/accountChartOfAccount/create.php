<?php
$this->breadcrumbs=array(
	'Account Chart Of Accounts'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List AccountChartOfAccount','url'=>array('index')),
array('label'=>'Manage AccountChartOfAccount','url'=>array('admin')),
);
?>

<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Create New Account:',
    )
    );

?>
</div>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>