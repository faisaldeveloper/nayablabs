<?php
$this->breadcrumbs=array(
	'Account Chart Of Accounts',
);

$this->menu=array(
array('label'=>'Create AccountChartOfAccount','url'=>array('create')),
array('label'=>'Manage AccountChartOfAccount','url'=>array('admin')),
);
?>

<h1>Account Chart Of Accounts</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
