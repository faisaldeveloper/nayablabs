<?php
$this->breadcrumbs=array(
	'Account Chart Of Accounts'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List AccountChartOfAccount','url'=>array('index')),
	array('label'=>'Create AccountChartOfAccount','url'=>array('create')),
	array('label'=>'View AccountChartOfAccount','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage AccountChartOfAccount','url'=>array('admin')),
	);
	?>

	<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Update Account:',
    )
    );

?>
</div>
<?php echo $this->renderPartial('_form',array('model'=>$model,'prepend'=>$prepend)); ?>