<?php
$this->breadcrumbs=array(
	'Account Chart Of Accounts'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List AccountChartOfAccount','url'=>array('index')),
array('label'=>'Create AccountChartOfAccount','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('account-chart-of-account-grid', {
data: $(this).serialize()
});
return false;
});
");
?>
<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Create Account:',
    )
    );

?>
</div>

<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'account-chart-of-account-form',
	'action'=>$this->createUrl('AccountChartOfAccount/admin'),
	'enableAjaxValidation'=>false,
	'enableClientValidation'=>true,
		'clientOptions'=>array(
            'validateOnSubmit'=>true,
        ),
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($account); ?>
    <div style="float:left; padding-right:10px">
	 <?php echo $form->dropDownListRow($account,'account_group',CHtml::listData(AccountGroups::model()->findAll(),'id','group_name'),array('prompt'=>'Select Class:','class'=>'span3','ajax' => array(
                        'type' =>'POST',
                        'url' => CController::createUrl('AccountChartOfAccount/GetCode'),
						'data'=>array('value'=>'js:this.value'),
                        //'update' => '#townlist',
                        'dataType' => 'json',
						'success'=>'function(data){
	                     // alert("code="+data.code);
						  $(".add-on").text(data.prepend);
						  $("#AccountChartOfAccount_account_code").val(data.code);
                        }'
                ))); ?>
    </div>
    
   <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($account,'account_code',array('prepend'=>$prepend,'class'=>'span1','maxlength'=>20)); ?>
     <?php //echo $form->error($account,'account_code',array('hideErrorMessage'=>true)); ?>
   </div>
   
   
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($account,'account_name',array('class'=>'span5','maxlength'=>30)); ?>
    </div>
    <div style="clear:both;"></div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->dropDownListRow($account,'account_type',CHtml::listData(AccountAccountTypes::model()->findAll(),'id','type'),array('prompt'=>'Select Type:','class'=>'span3')); ?>
    </div>
   <div style="float:left; padding-right:10px">
	<?php echo $form->dropDownListRow($account,'account_status',array('1'=>'activate','2'=>'un-activate'),array('class'=>'span3')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($account,'account_tags',array('class'=>'span2')); ?>
    </div>
    
<div style="float:left; margin-top:25px">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$account->isNewRecord ? 'Create' : 'Save',
		)); ?>
</div>
<div style="clear:both;"></div>

<?php $this->endWidget(); ?>



<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Manage Account Chart Of Accounts:',
    )
    );

?>
</div>

<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:none">
	<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php $this->widget('bootstrap.widgets.TbGridView',array(
'id'=>'account-chart-of-account-grid',
'dataProvider'=>$model->search(),
'type'=>'bordered',

//'filter'=>$model,
'columns'=>array(
		array(
            'header'=>'Sr#',
            'value'=>'$this->grid->dataProvider->pagination->currentPage * $this->grid->dataProvider->pagination->pageSize + ($row+1)',
        ),
		//'account_code',
		'account_code_2',
		'account_name',
		array('header'=>'Group','name'=>'account_group','value'=>'$data->accountGroup->group_name'),
		'account_tags',
		/*
		'account_status',
		*/
array(
'class'=>'bootstrap.widgets.TbButtonColumn',
),
),
)); ?>
