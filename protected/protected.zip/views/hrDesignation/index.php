<?php
$this->breadcrumbs=array(
	'Hr Designations',
);

$this->menu=array(
array('label'=>'Create HrDesignation','url'=>array('create')),
array('label'=>'Manage HrDesignation','url'=>array('admin')),
);
?>

<h1>Hr Designations</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
