<?php
$this->breadcrumbs=array(
	'Hr Designations'=>array('index'),
	$model->name,
);

$this->menu=array(
array('label'=>'List HrDesignation','url'=>array('index')),
array('label'=>'Create HrDesignation','url'=>array('create')),
array('label'=>'Update HrDesignation','url'=>array('update','id'=>$model->id)),
array('label'=>'Delete HrDesignation','url'=>'#','linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
array('label'=>'Manage HrDesignation','url'=>array('admin')),
);
?>

<h1>View HrDesignation #<?php echo $model->id; ?></h1>

<?php $this->widget('bootstrap.widgets.TbDetailView',array(
'data'=>$model,
'attributes'=>array(
		'id',
		'name',
),
)); ?>
