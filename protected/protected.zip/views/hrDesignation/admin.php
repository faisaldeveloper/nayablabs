
<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Create new Designation:',
    )
    );

?>
</div>
<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'account-classes-form',
	'action'=>$this->createUrl('HrDesignation/admin'),
	'enableAjaxValidation'=>false,
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($designation); ?>
    
    
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($designation,'name',array('class'=>'span2','maxlength'=>20)); ?>
    </div>
<div style="float:left; margin-top:25px">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$designation->isNewRecord ? 'Create' : 'Save',
		)); ?>
</div>
<div style="clear:both;"></div>

<?php $this->endWidget(); ?>
<?php
$this->breadcrumbs=array(
	'Hr Designations'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List HrDesignation','url'=>array('index')),
array('label'=>'Create HrDesignation','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('hr-designation-grid', {
data: $(this).serialize()
});
return false;
});
");
?>


<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Manage Designations:',
    )
    );

?>
</div>
<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:none">
	<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php $this->widget('bootstrap.widgets.TbGridView',array(
'id'=>'hr-designation-grid',
'type'=>'triped bordered condensed',
'dataProvider'=>$model->search(),
//'filter'=>$model,
'columns'=>array(
		array(
            'header'=>'Sr#',
            'value'=>'$this->grid->dataProvider->pagination->currentPage * $this->grid->dataProvider->pagination->pageSize + ($row+1)',
        ),
		'name',
array(
'class'=>'bootstrap.widgets.TbButtonColumn',
'template'=>'{update}{delete}',
),
),
)); ?>
