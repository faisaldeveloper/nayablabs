<?php
$this->breadcrumbs=array(
	'Hr Designations'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List HrDesignation','url'=>array('index')),
array('label'=>'Manage HrDesignation','url'=>array('admin')),
);
?>

<h1>Create HrDesignation</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>