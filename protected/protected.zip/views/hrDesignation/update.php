<?php
$this->breadcrumbs=array(
	'Hr Designations'=>array('index'),
	$model->name=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List HrDesignation','url'=>array('index')),
	array('label'=>'Create HrDesignation','url'=>array('create')),
	array('label'=>'View HrDesignation','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage HrDesignation','url'=>array('admin')),
	);
	?>

	<h1>Update Designation <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form',array('model'=>$model)); ?>