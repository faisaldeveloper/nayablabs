<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'hr-loan-form',
	'enableAjaxValidation'=>false,
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($model); ?>
    <div style="float:left; padding-right:10px">
	<?php echo $form->hiddenField($model,'employee_id',array('class'=>'span5' ,'value'=>$employee->id)); ?>
    
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'amount_given',array('class'=>'span3')); ?>
    </div>
     <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'amount_returned',array('class'=>'span3')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'amount_left',array('class'=>'span3')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php //echo $form->textFieldRow($model,'date',array('class'=>'span5')); ?>
    <?php echo $form->datepickerRow(
      $model,
      'issue_date',
     array(
    'options' => array('language' => 'es','width'=>'100px','format'=>'yyyy-mm-dd'),
    //'hint' => 'Click inside! This is a super cool date field.',
    //'prepend' => '<i class="icon-calendar"></i>'
    )
    ); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php //echo $form->textFieldRow($model,'return_date',array('class'=>'span5')); ?>
    <?php echo $form->datepickerRow(
      $model,
      'return_date',
     array(
    'options' => array('language' => 'es','width'=>'100px','format'=>'yyyy-mm-dd'),
    //'hint' => 'Click inside! This is a super cool date field.',
    //'prepend' => '<i class="icon-calendar"></i>'
    )
    ); ?>
    </div>
    <div style="clear:both"></div>
<div class="form-actions">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$model->isNewRecord ? 'Create' : 'Save',
		)); ?>
</div>

<?php $this->endWidget(); ?>
