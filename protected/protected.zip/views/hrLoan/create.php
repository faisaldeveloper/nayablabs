<?php
$this->breadcrumbs=array(
	'Hr Loans'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List HrLoan','url'=>array('index')),
array('label'=>'Manage HrLoan','url'=>array('admin')),
);
?>

<div style="float:left"><h1><?php echo $employee->first_name.' '.$employee->last_name; ?> Loan Detail</h1></div>
<div style="float:right; padding-top:25px; padding-right:30px"><a href="<?php echo Yii::app()->baseUrl;?>/HrEmployee/admin">Back to Employees &nbsp;<img src="<?php echo Yii::app()->baseUrl;?>/images/backlink.png" height="13px" width="13px" /></a></div>
<div style="clear:both"></div>
<?php echo $this->renderPartial('_form', array('model'=>$model,'employee'=>$employee)); ?>