<?php
$this->breadcrumbs=array(
	'Hr Loans'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List HrLoan','url'=>array('index')),
	array('label'=>'Create HrLoan','url'=>array('create')),
	array('label'=>'View HrLoan','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage HrLoan','url'=>array('admin')),
	);
	?>

	<h1>Update HrLoan <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form',array('model'=>$model)); ?>