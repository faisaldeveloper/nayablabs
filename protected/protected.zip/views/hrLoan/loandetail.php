<div style="float:left"><h1><?php echo $employee->first_name.' '.$employee->last_name; ?> Loan Detail</h1></div>
<div style="float:right; padding-top:25px; padding-right:30px"><a href="<?php echo Yii::app()->baseUrl;?>/HrEmployee/admin">Back to Employees &nbsp;<img src="<?php echo Yii::app()->baseUrl;?>/images/backlink.png" height="13px" width="13px" /></a></div>
<div style="clear:both"></div>

<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'hr-loan-form',
	'enableAjaxValidation'=>false,
)); ?>



<?php echo $form->errorSummary($model); ?>
    <div style="float:left; padding-right:10px">
	<?php echo $form->hiddenField($model,'employee_id',array('class'=>'span5' ,'value'=>$employee->id)); ?>
    
    </div>
    
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'amount_given',array('class'=>'span3','disabled'=>true)); ?>
    </div>
     <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'amount_returned',array('class'=>'span3','disabled'=>true)); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'amount_left',array('class'=>'span3','value'=>$model->amount_given-$model->amount_returned,'disabled'=>true)); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'issue_date',array('class'=>'span3','disabled'=>true)); ?>
   
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'return_date',array('class'=>'span3','disabled'=>true)); ?>
   
    </div>
    <div style="clear:both"></div>

<?php $this->endWidget(); ?>
