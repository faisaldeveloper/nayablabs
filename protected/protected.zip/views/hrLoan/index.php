<?php
$this->breadcrumbs=array(
	'Hr Loans',
);

$this->menu=array(
array('label'=>'Create HrLoan','url'=>array('create')),
array('label'=>'Manage HrLoan','url'=>array('admin')),
);
?>

<h1>Hr Loans</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
