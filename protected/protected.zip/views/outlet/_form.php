<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'outlet-form',
	'enableAjaxValidation'=>false,
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($outlet); ?>
     <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($outlet,'name',array('class'=>'span2','maxlength'=>30)); ?>
     </div>
<div style="float:left; margin-top:25px">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$outlet->isNewRecord ? 'Create' : 'Save',
		)); ?>
</div>
<div style="clear:both;"></div>
<?php $this->endWidget(); ?>
