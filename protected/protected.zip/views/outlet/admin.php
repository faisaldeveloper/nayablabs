<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Create Outlet:',
    )
    );

?>
</div>
<?php echo $this->renderPartial('_form', array('outlet'=>$outlet)); ?>
<?php
$this->breadcrumbs=array(
	'Outlets'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List Outlet','url'=>array('index')),
array('label'=>'Create Outlet','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('outlet-grid', {
data: $(this).serialize()
});
return false;
});
");
?>


<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:none">
	<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->
<div >
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Manage Outlets:',
    )
    );

?>
</div>
<?php $this->widget('bootstrap.widgets.TbGridView',array(
'id'=>'outlet-grid',
'type'=>'bordered',
'dataProvider'=>$model->search(),
'filter'=>$model,
'columns'=>array(
		//'id',
		array(
            'header'=>'Sr#',
            'value'=>'$this->grid->dataProvider->pagination->currentPage * $this->grid->dataProvider->pagination->pageSize + ($row+1)',
        ),
		'name',
array(
'class'=>'bootstrap.widgets.TbButtonColumn',
),
),
)); ?>
