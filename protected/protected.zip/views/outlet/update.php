<?php
$this->breadcrumbs=array(
	'Outlets'=>array('index'),
	$outlet->name=>array('view','id'=>$outlet->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List Outlet','url'=>array('index')),
	array('label'=>'Create Outlet','url'=>array('create')),
	array('label'=>'View Outlet','url'=>array('view','id'=>$outlet->id)),
	array('label'=>'Manage Outlet','url'=>array('admin')),
	);
	?>

	<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Update Outlet:',
    )
    );

?>
</div>

<?php echo $this->renderPartial('_form',array('outlet'=>$outlet)); ?>