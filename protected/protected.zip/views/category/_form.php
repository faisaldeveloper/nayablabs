<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'category-form',
	'action'=>$this->createUrl('category/admin'),
	'enableAjaxValidation'=>false,
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($category); ?>
   <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($category,'name',array('class'=>'span2','maxlength'=>30)); ?>
</div>
   <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($category,'code',array('class'=>'span2','maxlength'=>10)); ?>
   </div>
<div style="float:left; margin-top:25px">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$category->isNewRecord ? 'Create' : 'Save',
		)); ?>
</div>
<div style="clear:both;"></div>
<?php $this->endWidget(); ?>