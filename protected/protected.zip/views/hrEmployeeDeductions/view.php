<?php
$this->breadcrumbs=array(
	'Hr Employee Deductions'=>array('index'),
	$model->id,
);

$this->menu=array(
array('label'=>'List HrEmployeeDeductions','url'=>array('index')),
array('label'=>'Create HrEmployeeDeductions','url'=>array('create')),
array('label'=>'Update HrEmployeeDeductions','url'=>array('update','id'=>$model->id)),
array('label'=>'Delete HrEmployeeDeductions','url'=>'#','linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
array('label'=>'Manage HrEmployeeDeductions','url'=>array('admin')),
);
?>

<h1>View HrEmployeeDeductions #<?php echo $model->id; ?></h1>

<?php $this->widget('bootstrap.widgets.TbDetailView',array(
'data'=>$model,
'attributes'=>array(
		'id',
		'income_tax',
		'instalment_loan',
		'allowed_leaves',
		'insurance',
		'security_deposit',
		'EOBI',
		'employee_id',
),
)); ?>
