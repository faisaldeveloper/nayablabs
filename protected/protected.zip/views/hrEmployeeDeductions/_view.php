<div class="view">

		<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id),array('view','id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('income_tax')); ?>:</b>
	<?php echo CHtml::encode($data->income_tax); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('instalment_loan')); ?>:</b>
	<?php echo CHtml::encode($data->instalment_loan); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('allowed_leaves')); ?>:</b>
	<?php echo CHtml::encode($data->allowed_leaves); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('insurance')); ?>:</b>
	<?php echo CHtml::encode($data->insurance); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('security_deposit')); ?>:</b>
	<?php echo CHtml::encode($data->security_deposit); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('EOBI')); ?>:</b>
	<?php echo CHtml::encode($data->EOBI); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_id')); ?>:</b>
	<?php echo CHtml::encode($data->employee_id); ?>
	<br />

	*/ ?>

</div>