<?php
$this->breadcrumbs=array(
	'Hr Employee Deductions'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List HrEmployeeDeductions','url'=>array('index')),
array('label'=>'Manage HrEmployeeDeductions','url'=>array('admin')),
);
?>

<h1>Create HrEmployeeDeductions</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>