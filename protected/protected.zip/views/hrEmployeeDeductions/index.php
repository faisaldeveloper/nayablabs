<?php
$this->breadcrumbs=array(
	'Hr Employee Deductions',
);

$this->menu=array(
array('label'=>'Create HrEmployeeDeductions','url'=>array('create')),
array('label'=>'Manage HrEmployeeDeductions','url'=>array('admin')),
);
?>

<h1>Hr Employee Deductions</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
