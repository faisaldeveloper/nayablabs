<?php
$this->breadcrumbs=array(
	'Hr Employee Deductions'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List HrEmployeeDeductions','url'=>array('index')),
	array('label'=>'Create HrEmployeeDeductions','url'=>array('create')),
	array('label'=>'View HrEmployeeDeductions','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage HrEmployeeDeductions','url'=>array('admin')),
	);
	?>

	<h1>Update Employee Deductions (<?php echo $employee->first_name.' '.$employee->last_name; ?>)</h1>

<?php echo $this->renderPartial('_form',array('model'=>$model)); ?>