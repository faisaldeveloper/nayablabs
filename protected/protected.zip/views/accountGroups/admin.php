<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Create Account Group:',
    )
    );

?>
</div>

<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'accountgroups-form',
	'action'=>$this->createUrl('AccountGroups/admin'),
	'enableAjaxValidation'=>false,
	'enableClientValidation'=>true,
		'clientOptions'=>array(
            'validateOnSubmit'=>true,
        ),
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($group); ?>
<div style="float:left; padding-right:10px">
   <?php echo $form->dropDownListRow($group,'class',CHtml::listData(AccountClasses::model()->findAll(),'id','class_name'),array('prompt'=>'Select Class:','class'=>'span2','ajax' => array(
                        'type' =>'POST',
                        'url' => CController::createUrl('AccountGroups/GetCode'),
						'data'=>array('value'=>'js:this.value'),
                        //'update' => '#townlist',
                        'dataType' => 'json',
						'success'=>'function(data){
	                     // alert("code="+data.code);
						  $(".add-on").text(data.prepend);
						  $("#AccountGroups_code").val(data.code);
                        }'
                ))); ?>
	<?php //echo $form->textFieldRow($classes,'class_type',array('class'=>'span5')); ?>
    </div>
   <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($group,'group_name',array('class'=>'span2','maxlength'=>30)); ?>
</div>
<div style="float:left; padding-right:10px">
	<?php echo $form->dropDownListRow($group,'sub_group_of',CHtml::listData(AccountGroups::model()->findAll(),'id','group_name'),array('class'=>'span2','prompt'=>'Select Group:')); ?>
</div>
   <div style="float:left; padding-right:10px">
     
	<?php echo $form->textFieldRow($group,'code',array('prepend' => $prepend,'class'=>'span1','maxlength'=>2)); ?>
    
    </div>
<div style="float:left; margin-top:25px">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$group->isNewRecord ? 'Create' : 'Save',
		)); ?>
</div>
<div style="clear:both;"></div>
<?php $this->endWidget(); ?>
<?php
$this->breadcrumbs=array(
	'Account Groups'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List AccountGroups','url'=>array('index')),
array('label'=>'Create AccountGroups','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('account-groups-grid', {
data: $(this).serialize()
});
return false;
});
");
?>



<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:none">
	<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->
<div>
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Manage Account Groups:',
    )
    );

?>
</div>
<?php $this->widget('bootstrap.widgets.TbGridView',array(
'id'=>'account-groups-grid',
'type'=>'bordered',
'dataProvider'=>$model->search(),
//'filter'=>$model,
'columns'=>array(
		 array(
            'header'=>'Sr#',
            'value'=>'$this->grid->dataProvider->pagination->currentPage * $this->grid->dataProvider->pagination->pageSize + ($row+1)',
        ),
		'group_name',
		//'sub_group_of',
		'full_code',
		array('header'=>'Class','name'=>'class','value'=>'$data->class0->class_name'),
array(
'class'=>'bootstrap.widgets.TbButtonColumn',
'template'=>'{update}{delete}'
),
),
)); ?>
