<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'account-groups-form',
	'enableAjaxValidation'=>false,
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($model); ?>
    
    
    
   <?php echo $form->dropDownListRow($model,'class',CHtml::listData(AccountClasses::model()->findAll(),'id','class_name'),array('prompt'=>'Select Type:','class'=>'span2','ajax' => array(
                        'type' =>'POST',
                        'url' => CController::createUrl('AccountGroups/GetCode'),
						'data'=>array('value'=>'js:this.value'),
                        //'update' => '#townlist',
                        'dataType' => 'json',
						'success'=>'function(data){
	                     // alert("code="+data.code);
						  $(".add-on").text(data.prepend);
						  $("#AccountGroups_code").val(data.code);
                        }'
                ))); ?>
	<?php //echo $form->textFieldRow($classes,'class_type',array('class'=>'span5')); ?>
    
    
	<?php echo $form->textFieldRow($model,'group_name',array('class'=>'span2','maxlength'=>20)); ?>

	<?php echo $form->dropDownListRow($model,'sub_group_of',CHtml::listData(AccountGroups::model()->findAll(),'id','group_name'),array('class'=>'span2','prompt'=>'Select Group:')); ?>
    <?php echo $form->textFieldRow($model,'code',array('prepend' => $prepend,'class'=>'span1','maxlength'=>2)); ?>

	<?php //echo $form->textFieldRow($model,'class',array('class'=>'span5')); ?>

<div class="form-actions">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$model->isNewRecord ? 'Create' : 'Save',
		)); ?>
</div>

<?php $this->endWidget(); ?>
