<?php
$this->breadcrumbs=array(
	'Account Groups'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List AccountGroups','url'=>array('index')),
array('label'=>'Manage AccountGroups','url'=>array('admin')),
);
?>

<h1>Create AccountGroups</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>