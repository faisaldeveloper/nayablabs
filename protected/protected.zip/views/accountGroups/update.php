<?php
$this->breadcrumbs=array(
	'Account Groups'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List AccountGroups','url'=>array('index')),
	array('label'=>'Create AccountGroups','url'=>array('create')),
	array('label'=>'View AccountGroups','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage AccountGroups','url'=>array('admin')),
	);
	?>

	<h1>Update AccountGroups <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form',array('model'=>$model,'prepend'=>$prepend)); ?>