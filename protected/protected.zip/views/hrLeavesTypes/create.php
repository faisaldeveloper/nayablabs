<?php
$this->breadcrumbs=array(
	'Hr Leaves Types'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List HrLeavesTypes','url'=>array('index')),
array('label'=>'Manage HrLeavesTypes','url'=>array('admin')),
);
?>

<h1>Create HrLeavesTypes</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>