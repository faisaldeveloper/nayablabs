<div class="view">

		<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id),array('view','id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('name')); ?>:</b>
	<?php echo CHtml::encode($data->name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('designation_id')); ?>:</b>
	<?php echo CHtml::encode($data->designation_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('sick_leaves')); ?>:</b>
	<?php echo CHtml::encode($data->sick_leaves); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('casual_leaves')); ?>:</b>
	<?php echo CHtml::encode($data->casual_leaves); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('urgent_leaves')); ?>:</b>
	<?php echo CHtml::encode($data->urgent_leaves); ?>
	<br />


</div>