<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'hr-leaves-types-form',
	'enableAjaxValidation'=>false,
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($model); ?>

	<?php //echo $form->textFieldRow($model,'name',array('class'=>'span5','maxlength'=>20)); ?>

	<?php echo $form->dropDownListRow($model,'designation_id',CHtml::listData(HrDesignation::model()->findAll(),'id','name'),array('class'=>'span2')); ?>

	<?php echo $form->textFieldRow($model,'sick_leaves',array('class'=>'span2')); ?>

	<?php echo $form->textFieldRow($model,'casual_leaves',array('class'=>'span2')); ?>

	<?php echo $form->textFieldRow($model,'urgent_leaves',array('class'=>'span2')); ?>

<div class="form-actions">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$model->isNewRecord ? 'Create' : 'Save',
		)); ?>
</div>

<?php $this->endWidget(); ?>
