<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Create new Leave Type:',
    )
    );

?>
</div>

<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'account-classes-form',
	'action'=>$this->createUrl('HrLeavesTypes/admin'),
	'enableAjaxValidation'=>false,
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($leave_type); ?>
    <div style="float:left; padding-right:10px">
    <?php echo $form->dropDownListRow($leave_type,'designation_id',CHtml::listData(HrDesignation::model()->findAll(),'id','name'),array('class'=>'span2')); ?>
    </div>
    
    
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($leave_type,'sick_leaves',array('class'=>'span2','maxlength'=>20)); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($leave_type,'casual_leaves',array('class'=>'span2','maxlength'=>20)); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($leave_type,'urgent_leaves',array('class'=>'span2','maxlength'=>20)); ?>
    </div>
<div style="float:left; margin-top:25px">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$leave_type->isNewRecord ? 'Create' : 'Save',
		)); ?>
</div>
<div style="clear:both;"></div>

<?php $this->endWidget(); ?>
<?php
$this->breadcrumbs=array(
	'Hr Leaves Types'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List HrLeavesTypes','url'=>array('index')),
array('label'=>'Create HrLeavesTypes','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('hr-leaves-types-grid', {
data: $(this).serialize()
});
return false;
});
");
?>



<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:none">
	<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->
<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Manage Leave Types:',
    )
    );

?>
</div>
<?php $this->widget('bootstrap.widgets.TbGridView',array(
'id'=>'hr-leaves-types-grid',
'type'=>'triped bordered condensed',
'dataProvider'=>$model->search(),
//'filter'=>$model,
'columns'=>array(
		array(
            'header'=>'Sr#',
            'value'=>'$this->grid->dataProvider->pagination->currentPage * $this->grid->dataProvider->pagination->pageSize + ($row+1)',
        ),

		
		array('header'=>'Designation','name'=>'designation_id','value'=>'$data->designation->name'),
		'sick_leaves',
		'casual_leaves',
		'urgent_leaves',
array(
'class'=>'bootstrap.widgets.TbButtonColumn',
'template'=>'{update}{delete}',
),
),
)); ?>
