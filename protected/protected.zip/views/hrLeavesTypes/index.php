<?php
$this->breadcrumbs=array(
	'Hr Leaves Types',
);

$this->menu=array(
array('label'=>'Create HrLeavesTypes','url'=>array('create')),
array('label'=>'Manage HrLeavesTypes','url'=>array('admin')),
);
?>

<h1>Hr Leaves Types</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
