<?php
$this->breadcrumbs=array(
	'Hr Leaves Types'=>array('index'),
	$model->name=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List HrLeavesTypes','url'=>array('index')),
	array('label'=>'Create HrLeavesTypes','url'=>array('create')),
	array('label'=>'View HrLeavesTypes','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage HrLeavesTypes','url'=>array('admin')),
	);
	?>

	<h1>Update HrLeavesTypes <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form',array('model'=>$model)); ?>