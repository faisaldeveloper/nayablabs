<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'account-classes-form',
	'enableAjaxValidation'=>false,
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($model); ?>

    
    <?php echo $form->dropDownListRow($model,'class_type',CHtml::listData(AccountClassTypes::model()->findAll(),'id','class_type'),array('prompt'=>'Select Type:','class'=>'span2','ajax' => array(
                        'type' =>'POST',
                        'url' => CController::createUrl('AccountClasses/GetCode'),
						'data'=>array('value'=>'js:this.value'),
                        //'update' => '#townlist',
                        'dataType' => 'json',
						'success'=>'function(data){
	                     // alert("code="+data.code);
						  $(".add-on").text(data.prepend);
						  $("#AccountClasses_code").val(data.code);
                        }'
                ))); ?>
	<?php //echo $form->textFieldRow($classes,'class_type',array('class'=>'span5')); ?>
    
	<?php echo $form->textFieldRow($model,'class_name',array('class'=>'span2','maxlength'=>20)); ?>

	<?php //echo $form->textFieldRow($model,'class_type',array('class'=>'span5')); ?>
  
     
	<?php echo $form->textFieldRow($model,'code',array('prepend' => $prepend,'class'=>'span1','maxlength'=>2)); ?>
    
<div class="form-actions">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$model->isNewRecord ? 'Create' : 'Save',
		)); ?>
</div>

<?php $this->endWidget(); ?>
