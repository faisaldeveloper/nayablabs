
<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Create Account Class:',
    )
    );

?>
</div>
<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'account-classes-form',
	'action'=>$this->createUrl('AccountClasses/admin'),
	'enableAjaxValidation'=>false,
	'enableClientValidation'=>true,
		'clientOptions'=>array(
            'validateOnSubmit'=>true,
        ),

)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($classes); ?>
    
    <div style="float:left; padding-right:10px">
    <?php echo $form->dropDownListRow($classes,'class_type',CHtml::listData(AccountClassTypes::model()->findAll(),'id','class_type'),array('prompt'=>'Select Type:','class'=>'span2','ajax' => array(
                        'type' =>'POST',
                        'url' => CController::createUrl('AccountClasses/GetCode'),
						'data'=>array('value'=>'js:this.value'),
                        //'update' => '#townlist',
                        'dataType' => 'json',
						'success'=>'function(data){
	                     // alert("code="+data.code);
						  $(".add-on").text(data.prepend);
						  $("#AccountClasses_code").val(data.code);
                        }'
                ))); ?>
	<?php //echo $form->textFieldRow($classes,'class_type',array('class'=>'span5')); ?>
    </div>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($classes,'class_name',array('class'=>'span2','maxlength'=>20)); ?>
    </div>
     <div style="float:left; padding-right:10px">
     
	<?php echo $form->textFieldRow($classes,'code',array('prepend' => $prepend,'class'=>'span1','maxlength'=>2)); ?>
    </div>
<div style="float:left; margin-top:25px">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$classes->isNewRecord ? 'Create' : 'Save',
		)); ?>
</div>
<div style="clear:both;"></div>

<?php $this->endWidget(); ?>

<?php
$this->breadcrumbs=array(
	'Account Classes'=>array('index'),
	'Manage',
);

$this->menu=array(
array('label'=>'List AccountClasses','url'=>array('index')),
array('label'=>'Create AccountClasses','url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('account-classes-grid', {
data: $(this).serialize()
});
return false;
});
");
?>

<div >
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Manage Account Classes:',
    )
    );

?>
</div>

<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:none">
	<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php $this->widget('bootstrap.widgets.TbGridView',array(
'id'=>'account-classes-grid',
'dataProvider'=>$model->search(),
'type'=>'bordered',
//'filter'=>$model,
'columns'=>array(
		array(
            'header'=>'Sr#',
            'value'=>'$this->grid->dataProvider->pagination->currentPage * $this->grid->dataProvider->pagination->pageSize + ($row+1)',
        ),
		'class_name',
		array('header'=>'Class Type','name'=>'class_type','value'=>'$data->classType->class_type'),
		array('header'=>'Code','name'=>'code', 'value'=>'$data->class_type.sprintf("%02d", $data->code)'),
array(
'class'=>'bootstrap.widgets.TbButtonColumn',
'template'=>'{update}{delete}',
),
),
)); ?>
