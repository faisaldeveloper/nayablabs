<?php
$this->breadcrumbs=array(
	'Account Classes',
);

$this->menu=array(
array('label'=>'Create AccountClasses','url'=>array('create')),
array('label'=>'Manage AccountClasses','url'=>array('admin')),
);
?>

<h1>Account Classes</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
