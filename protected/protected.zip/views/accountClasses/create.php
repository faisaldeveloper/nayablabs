<?php
$this->breadcrumbs=array(
	'Account Classes'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List AccountClasses','url'=>array('index')),
array('label'=>'Manage AccountClasses','url'=>array('admin')),
);
?>

<h1>Create AccountClasses</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>