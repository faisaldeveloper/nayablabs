<?php
$this->breadcrumbs=array(
	'Account Classes'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List AccountClasses','url'=>array('index')),
	array('label'=>'Create AccountClasses','url'=>array('create')),
	array('label'=>'View AccountClasses','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage AccountClasses','url'=>array('admin')),
	);
	?>

	<h1>Update AccountClasses <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form',array('model'=>$model,'prepend'=>$prepend)); ?>