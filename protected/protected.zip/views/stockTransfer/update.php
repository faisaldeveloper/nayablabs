<?php
$this->breadcrumbs=array(
	'Stock Transfers'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List StockTransfer','url'=>array('index')),
	array('label'=>'Create StockTransfer','url'=>array('create')),
	array('label'=>'View StockTransfer','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage StockTransfer','url'=>array('admin')),
	);
	?>

	<h1>Update StockTransfer <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form',array('model'=>$model)); ?>