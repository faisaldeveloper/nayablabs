<div class="view">

		<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id),array('view','id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('transfer_date')); ?>:</b>
	<?php echo CHtml::encode($data->transfer_date); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('enter_date')); ?>:</b>
	<?php echo CHtml::encode($data->enter_date); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('s_t_no')); ?>:</b>
	<?php echo CHtml::encode($data->s_t_no); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('supplier_id')); ?>:</b>
	<?php echo CHtml::encode($data->supplier_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('store_id')); ?>:</b>
	<?php echo CHtml::encode($data->store_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('remarks')); ?>:</b>
	<?php echo CHtml::encode($data->remarks); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('enter_by')); ?>:</b>
	<?php echo CHtml::encode($data->enter_by); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('t_o_no')); ?>:</b>
	<?php echo CHtml::encode($data->t_o_no); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('transfer_type')); ?>:</b>
	<?php echo CHtml::encode($data->transfer_type); ?>
	<br />

	*/ ?>

</div>