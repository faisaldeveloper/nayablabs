<?php
$this->breadcrumbs=array(
	'Stock Transfers'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List StockTransfer','url'=>array('index')),
array('label'=>'Manage StockTransfer','url'=>array('admin')),
);
?>

<h1>Create StockTransfer</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>