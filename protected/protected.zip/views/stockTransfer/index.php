<?php
$this->breadcrumbs=array(
	'Stock Transfers',
);

$this->menu=array(
array('label'=>'Create StockTransfer','url'=>array('create')),
array('label'=>'Manage StockTransfer','url'=>array('admin')),
);
?>

<h1>Stock Transfers</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
