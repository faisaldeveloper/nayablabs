<?php
$this->breadcrumbs=array(
	'Stock Transfers'=>array('index'),
	'Manage',
);
$flag=false;
$store=true;
$outlet=false;
if($id=='1')
{
$url="Storeout/stockrefund"; $label="Store Return"; $flag=true; $outlet=false;
}
else if($id=='2')
{
$url="Storeout/StockTransfer"; $label="Stock Transfer"; $outlet=true;
}
else if($id=='3')
{
$url="Storeout/StockSale"; $label="Stock Sale"; $outlet=false;
}
else if($id=='4')
{
$url="Storeout/ReturnStore";  $label="Outlet Return"; $outlet=true;
}
else if($id=='5')
{
$url="Storeout/StoreToStore";  $label="Store To Store"; $outlet=false; $col=true;
}
else if($id=='6')
{
$url="Outletout/refund";  $label="Outlet Return"; $outlet=false; $col=false; $flag=true; $store=false; $create_url="stocktransfer/stockrefund";
}
else if($id=='7')
{
$url="Outletout/sale";
$label="Outlet Sale";	$outlet=false; $col=false; $flag=true; $store=false; $create_url="stocktransfer/stocksale"; $buyer_name=true; $flag=false;
	
}
$this->menu=array(
//array('label'=>'List Store Return','url'=>array('index')),
array('label'=>'Create '.$label,'url'=>array($setting->store==1? $url: $create_url)),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
$('.search-form').toggle();
return false;
});
$('.search-form form').submit(function(){
$.fn.yiiGridView.update('stock-transfer-grid', {
data: $(this).serialize()
});
return false;
});
");
?>

<h1></h1>
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Manage/search '.$label.':',
    )
    );

?>



<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); ?>
<div class="search-form" style="display:block">
	<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php 

$this->widget('bootstrap.widgets.TbGridView',array(
'id'=>'stock-transfer-grid',
'type'=>'bordered',
'dataProvider'=>$model->search($id),
//'filter'=>$model,
'columns'=>array(
		'id',
		'transfer_date',
		'enter_date',
		's_t_no',
		array('header'=>'Supplier','name'=>'supplier_id','value'=>'$data->supplier->name','visible'=>$flag),
		
		//'supplier_id',
		array('header'=>'Store','name'=>'store_id','value'=>'$data->store->name','visible'=>$store),
		array('header'=>'To Store','name'=>'tostore_id','value'=>'$data->store->name','visible'=>$col),
		array('header'=>'Outlet','name'=>'outlet_id','value'=>'$data->outlet->name','visible'=>$outlet),
		array('header'=>'Sale To','name'=>'buyer_name','value'=>'$data->buyer_name','visible'=>$buyer_name),
		array
(
    'class'=>'CButtonColumn',
    'template'=>'{email}',
    'buttons'=>array
    (
        'email' => array
        (
		     'header'=>'Detail',
            'label'=>'Update/Detail Store Return',
            'imageUrl'=>Yii::app()->request->baseUrl.'/images/detail2.png',
            'url'=>'Yii::app()->createUrl("'.$url.'/", array("id"=>$data->id))',
        ),
        
    ),
),
		//'store_id',
		/*
		'remarks',
		'enter_by',
		't_o_no',
		'transfer_type',
		*/
/*array(
'class'=>'bootstrap.widgets.TbButtonColumn',
),*/
),
)); ?>
