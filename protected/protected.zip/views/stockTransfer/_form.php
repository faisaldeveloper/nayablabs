<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'stock-transfer-form',
	'enableAjaxValidation'=>false,
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($model); ?>

	<?php echo $form->textFieldRow($model,'transfer_date',array('class'=>'span5')); ?>

	<?php echo $form->textFieldRow($model,'enter_date',array('class'=>'span5')); ?>

	<?php echo $form->textFieldRow($model,'s_t_no',array('class'=>'span5','maxlength'=>50)); ?>

	<?php echo $form->textFieldRow($model,'supplier_id',array('class'=>'span5')); ?>

	<?php echo $form->textFieldRow($model,'store_id',array('class'=>'span5')); ?>

	<?php echo $form->textFieldRow($model,'remarks',array('class'=>'span5','maxlength'=>300)); ?>

	<?php echo $form->textFieldRow($model,'enter_by',array('class'=>'span5')); ?>

	<?php echo $form->textFieldRow($model,'t_o_no',array('class'=>'span5','maxlength'=>50)); ?>

	<?php echo $form->textFieldRow($model,'transfer_type',array('class'=>'span5')); ?>

<div class="form-actions">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'primary',
			'label'=>$model->isNewRecord ? 'Create' : 'Save',
		)); ?>
</div>

<?php $this->endWidget(); ?>
