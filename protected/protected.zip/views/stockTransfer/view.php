<?php
$this->breadcrumbs=array(
	'Stock Transfers'=>array('index'),
	$model->id,
);

$this->menu=array(
array('label'=>'List StockTransfer','url'=>array('index')),
array('label'=>'Create StockTransfer','url'=>array('create')),
array('label'=>'Update StockTransfer','url'=>array('update','id'=>$model->id)),
array('label'=>'Delete StockTransfer','url'=>'#','linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
array('label'=>'Manage StockTransfer','url'=>array('admin')),
);
?>

<h1>View StockTransfer #<?php echo $model->id; ?></h1>

<?php $this->widget('bootstrap.widgets.TbDetailView',array(
'data'=>$model,
'attributes'=>array(
		'id',
		'transfer_date',
		'enter_date',
		's_t_no',
		'supplier_id',
		'store_id',
		'remarks',
		'enter_by',
		't_o_no',
		'transfer_type',
),
)); ?>
