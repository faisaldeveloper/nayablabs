<?php
$this->breadcrumbs=array(
	//'Stock Sale'=>array('index'),
	'Manage',
);

$this->menu=array(
///array('label'=>'List Stock Sale','url'=>array('index')),
array('label'=>'Manage Stock Sale','url'=>array('StockTransfer/admin/7')),
);
?>
<?php
if(Yii::app()->user->hasState('store'))
{
	$store_id=Yii::app()->user->getState('store');
	

}
?>
<fieldset>
<legend>
<div style="padding-bottom:10px;">
<?php
    $this->widget(
    'bootstrap.widgets.TbLabel',
    array(
    'type' => 'inverse',
    // 'success', 'warning', 'important', 'info' or 'inverse'
    'label' => 'Create Stock Sale:',
    )
    );

?>
</div>
</legend>
<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'stock-transfer-form',
	'enableAjaxValidation'=>false,
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($model); ?>

     <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'s_t_no',array('class'=>'span2','maxlength'=>20)); ?>
    </div>
    <div style="float:left; padding-right:10px">
    <?php echo $form->textFieldRow($model,'t_o_no',array('class'=>'span2','maxlength'=>20)); ?>
     </div>
     
      <div style="float:left; padding-right:10px">
    <?php echo $form->datepickerRow(
      $model,
      'transfer_date',
     array(
    'options' => array('language' => 'es','width'=>'100px','format'=>'yyyy-mm-dd'),
    //'hint' => 'Click inside! This is a super cool date field.',
    'prepend' => '<i class="icon-calendar"></i>'
    )
    ); ?>
     </div>
    <div style="clear:both;"></div>
    
     <div style="float:left; padding-right:10px">
     <?php if($store_id==''){ ?>
     <?php echo $form->dropDownListRow($model,'store_id',CHtml::listData(Store::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Store:')); 
	 
	 }
		else
		{
			echo $form->hiddenField($model,'store_id',array('value'=>$store_id));
		}
	 ?>
     </div>
     <div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'buyer_name',array('class'=>'span2','maxlength'=>20)); ?>
    </div>
    <div style="float:left; padding-right:10px">
    <?php echo $form->textFieldRow($model,'buyer_contact',array('class'=>'span2','maxlength'=>20)); ?>
     </div>
     <div style="clear:both;"></div>
	<?php //echo $form->textFieldRow($model,'transfer_date',array('class'=>'span5')); ?>
     <div style="float:left; padding-right:10px">
    <?php echo $form->textAreaRow($model,'buyer_address',array('class'=>'span7','maxlength'=>20)); ?>
     </div>
     <div style="clear:both;"></div>
	<?php //echo $form->textFieldRow($model,'enter_date',array('class'=>'span5')); ?>
    <?php echo $form->hiddenField($model,'enter_date',array('class'=>'span5','value'=>date('Y-m-d H:i:s'))); ?>
	<?php //echo $form->textFieldRow($model,'s_t_no',array('class'=>'span5','maxlength'=>50)); ?>

	<?php //echo $form->textFieldRow($model,'supplier_id',array('class'=>'span5')); ?>

	<?php //echo $form->textFieldRow($model,'store_id',array('class'=>'span5')); ?>
    <div style="float:left; padding-right:10px">
	<?php echo $form->textAreaRow($model,'remarks',array('class'=>'span7','maxlength'=>300)); ?>
    </div>
    <div style="clear:both;"></div>
	<?php echo $form->hiddenField($model,'enter_by',array('class'=>'span5','value'=>Yii::app()->user->id)); ?>

	<?php //echo $form->textFieldRow($model,'t_o_no',array('class'=>'span5','maxlength'=>50)); ?>

	<?php echo $form->hiddenField($model,'transfer_type',array('class'=>'span5','value'=>7)); ?>

<div class="form-actions">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$model->isNewRecord ? 'Next' : 'Save',
		)); ?>
        <?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'reset',
			'type'=>'inverse',
			'label'=>'Reset',
		)); ?>
</div>

<?php $this->endWidget(); ?>
</fieldset>