<?php
$this->breadcrumbs=array(
	'Account Class Types'=>array('index'),
	'Create',
);

$this->menu=array(
array('label'=>'List AccountClassTypes','url'=>array('index')),
array('label'=>'Manage AccountClassTypes','url'=>array('admin')),
);
?>

<h1>Create AccountClassTypes</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>