<?php
$this->breadcrumbs=array(
	'Account Class Types',
);

$this->menu=array(
array('label'=>'Create AccountClassTypes','url'=>array('create')),
array('label'=>'Manage AccountClassTypes','url'=>array('admin')),
);
?>

<h1>Account Class Types</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
)); ?>
