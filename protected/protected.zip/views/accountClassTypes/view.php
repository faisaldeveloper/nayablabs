<?php
$this->breadcrumbs=array(
	'Account Class Types'=>array('index'),
	$model->id,
);

$this->menu=array(
array('label'=>'List AccountClassTypes','url'=>array('index')),
array('label'=>'Create AccountClassTypes','url'=>array('create')),
array('label'=>'Update AccountClassTypes','url'=>array('update','id'=>$model->id)),
array('label'=>'Delete AccountClassTypes','url'=>'#','linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
array('label'=>'Manage AccountClassTypes','url'=>array('admin')),
);
?>

<h1>View AccountClassTypes #<?php echo $model->id; ?></h1>

<?php $this->widget('bootstrap.widgets.TbDetailView',array(
'data'=>$model,
'attributes'=>array(
		'id',
		'class_type',
),
)); ?>
