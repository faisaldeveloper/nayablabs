<?php
$this->breadcrumbs=array(
	'Account Class Types'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

	$this->menu=array(
	array('label'=>'List AccountClassTypes','url'=>array('index')),
	array('label'=>'Create AccountClassTypes','url'=>array('create')),
	array('label'=>'View AccountClassTypes','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage AccountClassTypes','url'=>array('admin')),
	);
	?>

	<h1>Update AccountClassTypes <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form',array('model'=>$model)); ?>