<script type="text/javascript">
function chk(){
	//alert($("#Item_type :selected").text());
	if($( "#Item_type" ).val()==1)
	{
		//alert('item');
	document.getElementById('item').style.display='block';
	document.getElementById('recipe').style.display='none';
	$('#recipe').find('option:first').attr('selected', 'selected');
	}
	else if($( "#Item_type" ).val()==2) 
	{
		//alert('recipe');
		document.getElementById('item').style.display='none';
	document.getElementById('recipe').style.display='block';
	$('#item').find('option:first').attr('selected', 'selected');
	}
	else if($("#Item_type :selected").text()=='select type:') 
	{
		
	$('#recipe').find('option:first').attr('selected', 'selected');
	$('#item').find('option:first').attr('selected', 'selected');
	document.getElementById('item').style.display='none';
	document.getElementById('recipe').style.display='none';
	}
}


</script>
<?php
if(Yii::app()->user->hasState('outlet'))
{
	$outlet_id=Yii::app()->user->getState('outlet');
	

}
?>
<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'item-form',
	'enableAjaxValidation'=>false,
	
	'htmlOptions' => array('enctype' => 'multipart/form-data'),
)); ?>

<p class="help-block">Fields with <span class="required">*</span> are required.</p>

<?php echo $form->errorSummary($model); ?>

	<?php //echo $form->textFieldRow($model,'menu_id',array('class'=>'span5')); ?>
    <?php //$list = CHtml::listData(Menu::model()->findAll(),'id', 'name'); ?>
 <?php //echo $form->dropDownListRow($model, 'menu_id',$list,array('options' => array('3'=>array('selected'=>true),'disabled'=>'true','class'=>'span2'))
//); ?>

<div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'name',array('class'=>'span2','maxlength'=>150)); ?>
</div>
<div style="float:left; padding-right:10px">
<?php echo $form->labelEx($model, 'image'); ?>
<?php echo $form->fileField($model, 'image'); ?>
<?php echo $form->error($model, 'image'); ?>

</div>
<?php 
if($model->image!=NULL)
$image="block";
?>

<div style="margin-top:34px;">
<img style="display:<?php echo $image;?>" width="44px" height="44px" src="<?php echo Yii::app()->baseUrl.'/submenuimages/'.$model->image;?>"  />
</div>
<div style="clear:both;"></div>
<div style="float:left; padding-right:10px">
	<?php echo $form->textFieldRow($model,'rate',array('class'=>'span2')); ?>

</div>
<?php echo $form->hiddenField($model,'menu_id',array('value'=>$id,'class'=>'span2','maxlength'=>150)); ?>
<?php 
$warehouse_display='';
//echo count($setting);
if($setting->warehouse==0)
{
$warehouse_display="none";
}
else if($setting->warehouse==1)
{
$warehouse_display="block";
}
?>
<div style="display:<?php echo $warehouse_display;?>;" >
<div style="float:left; padding-right:10px">
<?php if($outlet_id==''){ ?>
<?php echo $form->dropDownListRow($model,'outlet_id',CHtml::listData(Outlet::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Outlet:',)); ?>
<?php } 
else
echo $form->hiddenField($model,'outlet_id',array('value'=>$outlet_id));
?>
<?php 

//echo $form->hiddenField($model,'outlet_id',array());

?>
</div>
<div style="clear:both;"></div>

<div style="float:left; padding-right:10px">
</div>
<div style="float:left; padding-right:10px">

<?php //echo $form->hiddenField($model,'menu_id',array('value'=>$id,'class'=>'span2','maxlength'=>150)); ?>
<?php echo $form->dropDownListRow($model,'section_id',CHtml::listData(Section::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Section:',)); ?>

</div>
<?php
//echo $model->item_type;
$item_display="none";
$recipe_display="none";
if($model->item_type>0)
{
	if($model->item_type==1)
	{
    $item_display="block";
	}
	if($model->item_type==2)
	{
	 $recipe_display="block";	
	}
$selected=array($model->item_type=>array('selected'=>true));
}
?>
<div style="float:left; padding-right:10px">
	<?php echo $form->dropDownListRow($model,'type',array('1'=>'Item','2'=>'Recipe'),array('options'=>$selected,'class'=>'span2','prompt'=>'select type:','onChange'=>'chk()')); ?>
</div>


<div style="float:left; padding-right:10px; display:<?php echo $item_display ;?>;" id="item">
	<?php echo $form->dropDownListRow($model,'inventoryitem_id',CHtml::listData(Inventoryitem::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Item:',)); ?>
</div>
<div style="float:left; padding-right:10px; display:<?php echo $recipe_display ;?>;" id="recipe">
	<?php echo $form->dropDownListRow($model,'recipe_id',CHtml::listData(Recipe::model()->findAll(),'id','name'),array('class'=>'span2','prompt'=>'Recipe:',)); ?>
</div></div>
<div style="clear:both;"></div>
<?php
if(Yii::app()->controller->action->id=='update')
$note="block";
else
$note="none";
?>
<div style="display:<?php echo $note; ?>" >
Note: Uploading new Image will replace the existing image!
</div>
<div class="form-actions">
	<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'inverse',
			'label'=>$model->isNewRecord ? 'Create' : 'Save',
		)); ?>
</div>
<div style="clear:both;"></div>
<?php $this->endWidget(); ?>
